package testing_services;
public class Testing_Services {
public static void main(String[] args) {
 Testing_SplashScreen ts=  new Testing_SplashScreen();
 ts.setVisible(true);
 try{
 for(int loading =0;loading<=100; loading++){
  Thread.sleep(45);
  ts.load.setText(Integer.toString(loading)+"%");
  ts.jProgressBar1.setValue(loading);
  if(loading==100){
  ts.setVisible(false);
  new Start_Frame().show();
  }
  }
  }catch(Exception ex){
System.out.println(ex.getMessage());
 }  
    }
    }
