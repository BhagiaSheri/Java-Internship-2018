package sharingmsgapp;
public class MsgApp_SplashScreen extends javax.swing.JFrame {
    public MsgApp_SplashScreen() {
        initComponents();

    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        SplashScreenPanel = new javax.swing.JPanel();
        imgPanel = new javax.swing.JPanel();
        background_gif = new javax.swing.JLabel();
        loading = new javax.swing.JLabel();
        fbLabel = new javax.swing.JLabel();
        backgroundLabel = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        getContentPane().setLayout(null);

        SplashScreenPanel.setBackground(new java.awt.Color(0, 0, 0));
        SplashScreenPanel.setLayout(null);

        imgPanel.setLayout(null);

        background_gif.setIcon(new javax.swing.ImageIcon(getClass().getResource("/sharingmsgapp/social media.gif"))); // NOI18N
        imgPanel.add(background_gif);
        background_gif.setBounds(0, -10, 850, 600);

        loading.setBackground(new java.awt.Color(255, 255, 255));
        loading.setIcon(new javax.swing.ImageIcon(getClass().getResource("/sharingmsgapp/fbB.gif"))); // NOI18N
        imgPanel.add(loading);
        loading.setBounds(280, 180, 320, 290);

        fbLabel.setBackground(new java.awt.Color(255, 255, 255));
        fbLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/sharingmsgapp/facebook.gif"))); // NOI18N
        imgPanel.add(fbLabel);
        fbLabel.setBounds(180, 10, 500, 140);

        backgroundLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/sharingmsgapp/gmail back.gif"))); // NOI18N
        imgPanel.add(backgroundLabel);
        backgroundLabel.setBounds(30, 0, 790, 560);

        SplashScreenPanel.add(imgPanel);
        imgPanel.setBounds(40, 40, 850, 560);

        getContentPane().add(SplashScreenPanel);
        SplashScreenPanel.setBounds(0, 0, 920, 670);

        setSize(new java.awt.Dimension(924, 632));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(MsgApp_SplashScreen.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(MsgApp_SplashScreen.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(MsgApp_SplashScreen.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(MsgApp_SplashScreen.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new MsgApp_SplashScreen().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    public javax.swing.JPanel SplashScreenPanel;
    public javax.swing.JLabel backgroundLabel;
    public javax.swing.JLabel background_gif;
    public javax.swing.JLabel fbLabel;
    public javax.swing.JPanel imgPanel;
    public javax.swing.JLabel loading;
    // End of variables declaration//GEN-END:variables
}
