package sharingmsgapp;
import java.awt.Color;
public class SharingMsgApp {
public static void main(String[] args) {
MsgApp_SplashScreen msg=  new MsgApp_SplashScreen();
 msg.setVisible(true);
 msg.loading.setVisible(false);
 msg.backgroundLabel.setVisible(false);
 msg.fbLabel.setVisible(false);
 try{
 for(int loading =0;loading<=100; loading++){
  Thread.sleep(100);
  if(loading>=30 && loading<60){
 msg.background_gif.setVisible(false);
// msg.LoaderBar.setForeground(new Color(0,153,153));
 msg.SplashScreenPanel.setBackground(Color.BLUE);
 msg.imgPanel.setBackground(Color.WHITE);
  msg.fbLabel.setVisible(true);
  msg.loading.setVisible(true);
  }
  if(loading>=60){
  msg.fbLabel.setVisible(false);
  msg.loading.setVisible(false);
//  msg.LoaderBar.setForeground(new Color(0,0,102));
  msg.SplashScreenPanel.setBackground(new Color(204,0,0));
  msg.backgroundLabel.setVisible(true);
  }
  if(loading==100){
  msg.setVisible(false);
  new AppMainFrame().show();
  }
  }
  }catch(Exception ex){
System.out.println(ex.getMessage());
 }
      
    }
    
}
