package multipledownloader;
public class MultipleDownloader {


    public static void main(String[] args) {
       new DownloaderMainFrame().show();
    }
}
    

