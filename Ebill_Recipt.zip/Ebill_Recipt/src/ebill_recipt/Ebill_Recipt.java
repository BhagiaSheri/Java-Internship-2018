package ebill_recipt;
public class Ebill_Recipt {
    public static void main(String[] args) {
    new Main_Frame().show();
    }
    }
