package shoppingapp;

import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.sql.*;
import java.io.*;
import java.util.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import net.proteanit.sql.DbUtils;

public class Add_Products extends javax.swing.JFrame {

    Connection conn;
    Statement st;
    PreparedStatement ps;
    ResultSet rs;
    String r_id,pro_name, category, subCategory;
    String q1;
    double price;
    String imgPath = null;

    /**
     * Creates new form MainCompanyFrame
     */
    public Add_Products() {
        initComponents();
        this.P_idTextField.disable();
        try {
            Class.forName("oracle.jdbc.driver.OracleDriver");
            conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "BHAGIA SHERI", "123456789");
            if (conn != null) {
                System.out.println("Connection Succesfullly!");
            }
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
        tableData();
    }

    public ImageIcon ResizeImage(String ImagePath, byte[] pic) {

        ImageIcon MyImage = null;
        if (ImagePath != null) {
            MyImage = new ImageIcon(ImagePath);
        } else {
            MyImage = new ImageIcon(pic);
        }
        Image img = MyImage.getImage();
        Image newImg = img.getScaledInstance(img_label.getWidth(), img_label.getHeight(), Image.SCALE_AREA_AVERAGING);
        ImageIcon image = new ImageIcon(newImg);
        return image;

    }

    public void validationForInsertion() throws SQLException {

        pro_name = productName.getText();
        category = this.categoryComobox.getSelectedItem().toString();
        price = Double.parseDouble(this.pricetxt.getText());
        st = conn.createStatement();
        String query = "Select products from shoping_products where products='" + pro_name + "'";
        rs = st.executeQuery(query);
        if (rs.next()) {
            JOptionPane.showMessageDialog(null, "PRODUCT ALREADY EXIST !!!");
        } else {
            addProducts();
        }
    }

    public void addProducts() {
        pro_name = productName.getText();
        category = this.categoryComobox.getSelectedItem().toString();
        subCategory = this.subCategory_Comobox.getSelectedItem().toString();
        price = Double.parseDouble(this.pricetxt.getText());

        if (imgPath != null) {

            try {
                InputStream img = new FileInputStream(new File(imgPath));
                if (category.equalsIgnoreCase("electronics")) {
                    q1 = "insert into shoping_products(P_ID,PRODUCTS,ELECTRONICS,SUB_CATEGORY,PRICE,PRODUCT_IMG)values(SHOPING_PRODUCTS_SEQUENCE.NEXTVAL,?,?,?,?,?)";
                }
                if (category.equalsIgnoreCase("furniture & home-decor")) {
                    q1 = "insert into shoping_products(P_ID,PRODUCTS,FURNITURE,SUB_CATEGORY,PRICE,PRODUCT_IMG)values(SHOPING_PRODUCTS_SEQUENCE.NEXTVAL,?,?,?,?,?)";
                }
                if (category.equalsIgnoreCase("bikes")) {
                    q1 = "insert into shoping_products(P_ID,PRODUCTS,BIKES,SUB_CATEGORY,PRICE,PRODUCT_IMG)values(SHOPING_PRODUCTS_SEQUENCE.NEXTVAL,?,?,?,?,?)";
                }
                if (category.equalsIgnoreCase("mobiles")) {
                    q1 = "insert into shoping_products(P_ID,PRODUCTS,MOBILES,SUB_CATEGORY,PRICE,PRODUCT_IMG)values(SHOPING_PRODUCTS_SEQUENCE.NEXTVAL,?,?,?,?,?)";
                }
                ps = conn.prepareStatement(q1);
                ps.setString(1, pro_name);
                ps.setString(2, "1");
                ps.setString(3, subCategory);
                ps.setDouble(4, price);
                ps.setBlob(5, img);
                imgpath.setText(imgPath);
                int row = ps.executeUpdate();
                System.out.println("product name  " + pro_name + " category " + category + "Sub Category" + subCategory + " img path " + img);
                if (row > 0) {
                    System.out.println("DATA INSERTED !");
                    tableData();
                    JOptionPane.showMessageDialog(null, "Data Inserted !");
                } else {
                    System.out.println("DATA NOT INSERTED !");
                }

            } catch (Exception ex) {
                System.out.println(ex.getMessage());
            }
        } else {
            JOptionPane.showMessageDialog(null, "IMAGE IS NOT SELECTED !!!");
        }
        imgPath = null;
        productName.setText("");
        categoryComobox.setSelectedIndex(0);
        subCategory_Comobox.setSelectedIndex(0);
        pricetxt.setText("");
       imgpath.setText("");
       img_label.setIcon(null);
    }
 public void tableData(){
    JTableHeader jh = products_table.getTableHeader();
    jh.setBackground(Color. WHITE);
    jh.setForeground(Color.BLACK);
    jh.setFont(new Font ("Times New Roman", Font.PLAIN , 14));
     products_table.setBackground(new Color(0,0,0,0));
    ((DefaultTableCellRenderer)products_table.getDefaultRenderer(Object.class)).setBackground(new Color(0,0,0,0));
   products_table.setGridColor(Color.GRAY);
   jScrollPane2.setBackground(new Color(0,0,0,0));
  jScrollPane2.setOpaque(false);
  products_table.setOpaque(false);
 ((DefaultTableCellRenderer)products_table.getDefaultRenderer(Object.class)).setOpaque(true);
 jScrollPane2.getViewport().setOpaque(false);
  products_table.setShowGrid(true);
    try{
   Statement   stm = conn.createStatement();
          rs = stm.executeQuery("select * from shoping_Products ORDER BY P_ID"); 
         products_table.setModel(DbUtils.resultSetToTableModel(rs));
    }catch(Exception e){
     System.out.println(e.getMessage());
    }
    }
 
 public void updateRow() throws ParseException{
      
  if(products_table.getSelectedRowCount()==0){
  JOptionPane.showMessageDialog(null,"SELECT ANY ROW FIRST !");
  }
  else if(products_table.getSelectedRowCount()==1){
  img_label.setIcon(null);
  DefaultTableModel model = (DefaultTableModel)products_table.getModel();
  int selectedRowIndex = products_table.getSelectedRow();
  P_idTextField.setText(model.getValueAt(selectedRowIndex, 0).toString());
  productName.setText(model.getValueAt(selectedRowIndex, 1).toString());
  categoryComobox.setSelectedIndex(0);
  subCategory_Comobox.setSelectedItem(model.getValueAt(selectedRowIndex, 6).toString());
  pricetxt.setText(model.getValueAt(selectedRowIndex, 7).toString());
  imgpath.setText(model.getValueAt(selectedRowIndex, 8).toString());
  updateProductImage();
  }
 else{
  JOptionPane.showMessageDialog(null, "ONE ROW CAN BE UPDATED AT A TIME !");
  }
  }
  
  public void deleteRow(){
  if(products_table.getSelectedRowCount()==0){
  JOptionPane.showMessageDialog(null,"SELECT ANY ROW FIRST !");
  }
  else if(products_table.getSelectedRowCount()==1){
  DefaultTableModel model = (DefaultTableModel)products_table.getModel();
  int selectedRowIndex = products_table.getSelectedRow();
  r_id = model.getValueAt(selectedRowIndex, 0).toString();
   try {
         Statement st=conn.createStatement();
          String query="DELETE FROM SHOPING_PRODUCTS WHERE P_ID='"+r_id+"'" ;
         int row=st.executeUpdate(query);
           if(row>0){
              System.out.println("DATA DELETED !");
              tableData();
           }
          else{
          System.out.println("DATA NOT DELETED !");
          }
          }
     catch (Exception ex) {
     System.out.println(ex.getMessage());
     }
  }
  else{
  JOptionPane.showMessageDialog(null, "ONE ROW CAN BE DELETED AT A TIME !");
  }
  }
  
  public void updateProductImage(){
     System.out.println("updateProductImage method is Called !");
        try {
             DefaultTableModel model = (DefaultTableModel)products_table.getModel();
            int selectedRowIndex = products_table.getSelectedRow();
            r_id = model.getValueAt(selectedRowIndex, 0).toString();
            st = conn.createStatement();
            String query1 = "SELECT PRODUCT_IMG  FROM SHOPING_PRODUCTS WHERE P_ID='"+r_id+"'";
            ResultSet  rs1 = st.executeQuery(query1);
              if (rs1.next()) {
                System.out.println("Inside if");
                byte[] img = rs1.getBytes("PRODUCT_IMG");
                ImageIcon image = new ImageIcon(img);
                Image icon = image.getImage();
                Image myImg = icon.getScaledInstance(img_label.getHeight(), img_label.getWidth(), Image.SCALE_SMOOTH);
                ImageIcon newImage = new ImageIcon(myImg);
                img_label.setIcon(newImage);
               }
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
    }
  
  public void saveRow(){
      r_id =P_idTextField.getText();
      pro_name = productName.getText();
      category = this.categoryComobox.getSelectedItem().toString();
      subCategory = this.subCategory_Comobox.getSelectedItem().toString();
      price = Double.parseDouble(this.pricetxt.getText());
        DefaultTableModel model = (DefaultTableModel)products_table.getModel();
            int selectedRowIndex = products_table.getSelectedRow();
            r_id = model.getValueAt(selectedRowIndex, 0).toString();
  if(imgPath !=null){
    try{
        InputStream img = new FileInputStream(new File(imgPath));
         if (category.equalsIgnoreCase("electronics")) {
           q1 = "update shoping_products set products=? , electronics= ? , sub_category=?, price=?,product_img=? WHERE P_ID="+r_id+"";
             }
         if (category.equalsIgnoreCase("furniture & home-decor")) {
           q1 = "update shoping_products set products=? , furniture= ? , sub_category=?, price=?,product_img=? WHERE P_ID="+r_id+"";
             }
         if (category.equalsIgnoreCase("bikes")) {
           q1 = "update shoping_products set products=? , bikes= ? , sub_category=?, price=?,product_img=? WHERE P_ID="+r_id+"";
             }
         if (category.equalsIgnoreCase("mobiles")) {
           q1 = "update shoping_products set products=? , mobiles= ? , sub_category=?, price=?,product_img=? WHERE P_ID="+r_id+"";
             }
       
         PreparedStatement  ps = conn.prepareStatement(q1);
         ps.setString(1, pro_name);
         ps.setString(2,"1");
         ps.setString(3,subCategory );
         ps.setString(4, Double.toString(price));
         ps.setBlob(5, img);
         imgpath.setText(imgPath);
          int rows=  ps.executeUpdate();
           if(rows>0){
              System.out.println("DATA UPDATED !");  
             tableData();
           }
          else{
           System.out.println("DATA NOT UPDATED !");
           }
        }catch(Exception e){
           System.out.println(e.getMessage());
        }   
}else{
        try{
         if (category.equalsIgnoreCase("electronics")) {
           q1 = "update shoping_products set products=? , electronics= ? , sub_category=?, price=? WHERE P_ID="+r_id+"";
             }
         if (category.equalsIgnoreCase("furniture & home-decor")) {
           q1 = "update shoping_products set products=? , furniture= ? , sub_category=?, price=? WHERE P_ID="+r_id+"";
             }
         if (category.equalsIgnoreCase("bikes")) {
           q1 = "update shoping_products set products=? , bikes= ? , sub_category=?, price=? WHERE P_ID="+r_id+"";
             }
         if (category.equalsIgnoreCase("mobiles")) {
           q1 = "update shoping_products set products=? , mobiles= ? , sub_category=?, price=? WHERE P_ID="+r_id+"";
             }
       
         PreparedStatement  ps = conn.prepareStatement(q1);
         ps.setString(1, pro_name);
         ps.setString(2,"1");
         ps.setString(3,subCategory );
         ps.setString(4, Double.toString(price));
          int rows=  ps.executeUpdate();
           if(rows>0){
              System.out.println("DATA UPDATED !");  
             tableData();
           }
          else{
           System.out.println("DATA NOT UPDATED !");
           }
        }catch(Exception e){
           System.out.println(e.getMessage());
        }   
}
        imgPath = null;
        productName.setText("");
        categoryComobox.setSelectedIndex(0);
        subCategory_Comobox.setSelectedIndex(0);
        pricetxt.setText("");
       imgpath.setText("");
       img_label.setIcon(null);
   }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        pricetxt = new javax.swing.JTextField();
        img_label = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        imgpath = new javax.swing.JLabel();
        categoryComobox = new javax.swing.JComboBox();
        productName = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        subCategory_Comobox = new javax.swing.JComboBox();
        jLabel7 = new javax.swing.JLabel();
        P_idTextField = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        new_button = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        products_table = new javax.swing.JTable();
        jLabel10 = new javax.swing.JLabel();
        save_botton = new javax.swing.JButton();
        update_button = new javax.swing.JButton();
        delete_button = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        jButton3 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(102, 102, 102));
        getContentPane().setLayout(null);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setBorder(javax.swing.BorderFactory.createEtchedBorder(new java.awt.Color(204, 204, 204), new java.awt.Color(204, 204, 204)));
        jPanel1.setLayout(null);

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));
        jPanel2.setBorder(javax.swing.BorderFactory.createEtchedBorder(new java.awt.Color(153, 153, 153), new java.awt.Color(153, 153, 153)));
        jPanel2.setLayout(null);

        jLabel2.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel2.setText("PRODUCT NAME:");
        jPanel2.add(jLabel2);
        jLabel2.setBounds(40, 80, 120, 17);

        jLabel6.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel6.setText("PRODUCT CATEGORY:");
        jPanel2.add(jLabel6);
        jLabel6.setBounds(40, 130, 160, 17);

        pricetxt.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jPanel2.add(pricetxt);
        pricetxt.setBounds(230, 230, 200, 30);

        img_label.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 3, true));
        jPanel2.add(img_label);
        img_label.setBounds(560, 10, 220, 260);

        jButton1.setBackground(new java.awt.Color(0, 51, 255));
        jButton1.setFont(new java.awt.Font("Times New Roman", 3, 18)); // NOI18N
        jButton1.setForeground(new java.awt.Color(255, 255, 255));
        jButton1.setText("UPLOAD IMAGE");
        jButton1.setBorder(null);
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel2.add(jButton1);
        jButton1.setBounds(560, 280, 220, 30);

        imgpath.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        imgpath.setForeground(new java.awt.Color(0, 51, 255));
        imgpath.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        imgpath.setText("IMAGE PATH");
        imgpath.setBorder(javax.swing.BorderFactory.createEtchedBorder(new java.awt.Color(153, 153, 153), new java.awt.Color(102, 102, 102)));
        jPanel2.add(imgpath);
        imgpath.setBounds(560, 320, 220, 30);

        categoryComobox.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        categoryComobox.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "PRODUCT CATEGORY", "BIKES", "ELECTRONICS", "FURNITURE & HOME-DECOR", "MOBILES" }));
        jPanel2.add(categoryComobox);
        categoryComobox.setBounds(230, 130, 190, 25);

        productName.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jPanel2.add(productName);
        productName.setBounds(230, 80, 190, 30);

        jLabel4.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel4.setText("PRICE:");
        jPanel2.add(jLabel4);
        jLabel4.setBounds(40, 230, 70, 20);

        subCategory_Comobox.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        subCategory_Comobox.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "SELECT SUB-CATEGORY", "PHONES", "TABLETS", "COMPUTER ACCESSORIES", "HOME ELECTRICAL", "MOTOR-CYCLES", "BICYCLES", "SOFA & CHAIRS", "BEDS AND WARDROBES", "TABLES AND DINING", " " }));
        jPanel2.add(subCategory_Comobox);
        subCategory_Comobox.setBounds(230, 180, 190, 25);

        jLabel7.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel7.setText("SUB CATEGORY:");
        jPanel2.add(jLabel7);
        jLabel7.setBounds(40, 180, 130, 17);

        P_idTextField.setEditable(false);
        P_idTextField.setBackground(new java.awt.Color(255, 255, 204));
        P_idTextField.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        P_idTextField.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jPanel2.add(P_idTextField);
        P_idTextField.setBounds(230, 30, 190, 30);

        jLabel1.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel1.setText("PRODUCT ID:");
        jPanel2.add(jLabel1);
        jLabel1.setBounds(40, 30, 140, 20);

        new_button.setBackground(new java.awt.Color(0, 51, 255));
        new_button.setFont(new java.awt.Font("Times New Roman", 3, 18)); // NOI18N
        new_button.setForeground(new java.awt.Color(255, 255, 255));
        new_button.setText("SAVE");
        new_button.setBorder(null);
        new_button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                new_buttonActionPerformed(evt);
            }
        });
        jPanel2.add(new_button);
        new_button.setBounds(240, 280, 160, 60);

        jPanel1.add(jPanel2);
        jPanel2.setBounds(160, 50, 830, 380);

        products_table.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 153, 153), 2));
        products_table.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        products_table.setForeground(new java.awt.Color(0, 0, 102));
        products_table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        products_table.setSelectionBackground(new java.awt.Color(153, 153, 255));
        jScrollPane2.setViewportView(products_table);

        jPanel1.add(jScrollPane2);
        jScrollPane2.setBounds(160, 430, 830, 270);

        jLabel10.setBackground(new java.awt.Color(153, 153, 153));
        jLabel10.setFont(new java.awt.Font("Times New Roman", 1, 20)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(153, 153, 153));
        jLabel10.setText("Add Products:");
        jPanel1.add(jLabel10);
        jLabel10.setBounds(160, 20, 170, 30);

        save_botton.setBackground(new java.awt.Color(0, 51, 255));
        save_botton.setFont(new java.awt.Font("Times New Roman", 3, 18)); // NOI18N
        save_botton.setForeground(new java.awt.Color(255, 255, 255));
        save_botton.setText("UPDATE");
        save_botton.setBorder(null);
        save_botton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                save_bottonActionPerformed(evt);
            }
        });
        jPanel1.add(save_botton);
        save_botton.setBounds(1000, 520, 150, 60);

        update_button.setBackground(new java.awt.Color(0, 51, 255));
        update_button.setFont(new java.awt.Font("Times New Roman", 3, 18)); // NOI18N
        update_button.setForeground(new java.awt.Color(255, 255, 255));
        update_button.setText("SHOW ROW");
        update_button.setBorder(null);
        update_button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                update_buttonActionPerformed(evt);
            }
        });
        jPanel1.add(update_button);
        update_button.setBounds(1000, 450, 150, 60);

        delete_button.setBackground(new java.awt.Color(0, 51, 255));
        delete_button.setFont(new java.awt.Font("Times New Roman", 3, 18)); // NOI18N
        delete_button.setForeground(new java.awt.Color(255, 255, 255));
        delete_button.setText("DELETE");
        delete_button.setBorder(null);
        delete_button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                delete_buttonActionPerformed(evt);
            }
        });
        jPanel1.add(delete_button);
        delete_button.setBounds(1000, 590, 150, 60);

        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/shoppingapp/logo2.gif"))); // NOI18N
        jPanel1.add(jLabel3);
        jLabel3.setBounds(990, 110, 210, 260);

        jButton3.setBackground(new java.awt.Color(255, 255, 255));
        jButton3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/shoppingapp/back (1).png"))); // NOI18N
        jButton3.setBorder(null);
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton3);
        jButton3.setBounds(10, 10, 30, 50);

        getContentPane().add(jPanel1);
        jPanel1.setBounds(0, 0, 1600, 910);

        setSize(new java.awt.Dimension(1617, 804));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void new_buttonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_new_buttonActionPerformed
        if (pricetxt.getText().equals("") || productName.getText().equals("") || categoryComobox.getSelectedIndex() == 0 || subCategory_Comobox.getSelectedIndex() == 0 || img_label.getIcon() == null) {
            JOptionPane.showMessageDialog(null, "FILL ALL FIELDS !");
        } else {
            try {
                validationForInsertion();
            } catch (Exception ex) {
                System.out.println(ex.getMessage());
            }
        }
    }//GEN-LAST:event_new_buttonActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        JFileChooser file = new JFileChooser();
        file.setCurrentDirectory(new File(System.getProperty("user.home")));

        FileNameExtensionFilter filter = new FileNameExtensionFilter("*.Images", "jpg", "gif", "png");
        file.addChoosableFileFilter(filter);
        int result = file.showSaveDialog(null);

        if (result == JFileChooser.APPROVE_OPTION) {
            File selectedFile = file.getSelectedFile();
            String path = selectedFile.getAbsolutePath();
            img_label.setIcon(ResizeImage(path, null));
            imgPath = path;
            imgpath.setText(imgPath);
        } else if (result == JFileChooser.CANCEL_OPTION) {
            System.out.println("NO FILE SELECT !");
        }
    }//GEN-LAST:event_jButton1ActionPerformed

    private void save_bottonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_save_bottonActionPerformed
        if (pricetxt.getText().equals("") || productName.getText().equals("") || categoryComobox.getSelectedIndex() == 0 || subCategory_Comobox.getSelectedIndex() == 0 || img_label.getIcon() == null) {
            JOptionPane.showMessageDialog(null, "FILL ALL FIELDS !");
        }
        else{
            saveRow();
        }
    }//GEN-LAST:event_save_bottonActionPerformed

    private void update_buttonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_update_buttonActionPerformed
        try {
            updateRow();
        } catch (ParseException ex) {
            System.out.println(ex.getMessage());
        }
    }//GEN-LAST:event_update_buttonActionPerformed

    private void delete_buttonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_delete_buttonActionPerformed
        deleteRow();
    }//GEN-LAST:event_delete_buttonActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        this.dispose();
    }//GEN-LAST:event_jButton3ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Add_Products.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Add_Products.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Add_Products.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Add_Products.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Add_Products().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField P_idTextField;
    private javax.swing.JComboBox categoryComobox;
    private javax.swing.JButton delete_button;
    private javax.swing.JLabel img_label;
    private javax.swing.JLabel imgpath;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JButton new_button;
    private javax.swing.JTextField pricetxt;
    private javax.swing.JTextField productName;
    private javax.swing.JTable products_table;
    private javax.swing.JButton save_botton;
    private javax.swing.JComboBox subCategory_Comobox;
    private javax.swing.JButton update_button;
    // End of variables declaration//GEN-END:variables

}
