package shoppingapp;

import java.sql.*;
import java.util.*;
import javax.swing.*;
import java.awt.*;
import static shoppingapp.Shoping_Login.*;

public class ShopingApp_MainFrame extends javax.swing.JFrame {
    public static UserCartFrame ucf;
    Connection conn;
    Statement st;
    PreparedStatement ps;
    ResultSet rs;
    AddingProducts items;
    SubCategory_Panels sub_p = new SubCategory_Panels();
    ArrayList<JPanel> jp = new ArrayList();
    int count = 1;

    public ShopingApp_MainFrame() {
        initComponents();
        
        logoutBtn.setVisible(false);
        addProductsBtn.setVisible(false);
        detailsBtn.setVisible(false);
        backBtn.setVisible(false);
        myAccountBtn.setText(name);
        if(myAccountBtn.getText().endsWith("Admin")){
           addProductsBtn.setVisible(true);
           detailsBtn.setVisible(true);
           myAccountBtn.setVisible(false);
            logoutBtn.setVisible(true);
        }
        try {
            Class.forName("oracle.jdbc.driver.OracleDriver");
            conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "BHAGIA SHERI", "123456789");
            if (conn != null) {
                System.out.println("Connection Succesfullly!");
            }
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
    }

    public void addPhonesItems() {
        System.out.println("addItems method is Called !");
        try {
            st = conn.createStatement();
            String query = "Select * from shoping_products where mobiles=1 AND sub_category='PHONES' ";
            rs = st.executeQuery(query);
              while (rs.next()) {
                System.out.println("Inside while");
                items = new AddingProducts();
                sub_p.categoryLabel1.setText(rs.getString("sub_category"));
                items.proNameLabel.setText(rs.getString("PRODUCTS"));
                items.proPriceLabel.setText(rs.getString("PRICE"));
                byte[] img = rs.getBytes("Product_Img");
                ImageIcon image = new ImageIcon(img);
                Image icon = image.getImage();
                Image myImg = icon.getScaledInstance(items.img_label.getHeight(), items.img_label.getWidth(), Image.SCALE_SMOOTH);
                ImageIcon newImage = new ImageIcon(myImg);
                items.img_label.setIcon(newImage);
                items.setName("p" + count);
                System.out.println(items.getName());
                jp.add(items);
                sub_p.subCategory_Panel1.add(items);
                sub_p.subCategory_Panel1.revalidate();
                count++;
                System.out.println(rs.getString("products"));

            }
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
    }
    public void addTabletsItems() {
        System.out.println("addTablets method is Called !");
        try {
            st = conn.createStatement();
            String query = "Select * from shoping_products where mobiles=1 AND sub_category='TABLETS' ";
            rs = st.executeQuery(query);
            while (rs.next()) {
                System.out.println("Inside while");
                items = new AddingProducts();
                sub_p.categoryLabel2.setText(rs.getString("sub_category"));
                items.proNameLabel.setText(rs.getString("PRODUCTS"));
                items.proPriceLabel.setText(rs.getString("PRICE"));
                byte[] img = rs.getBytes("Product_Img");
                ImageIcon image = new ImageIcon(img);
                Image icon = image.getImage();
                Image myImg = icon.getScaledInstance(items.img_label.getHeight(), items.img_label.getWidth(), Image.SCALE_SMOOTH);
                ImageIcon newImage = new ImageIcon(myImg);
                items.img_label.setIcon(newImage);
                items.setName("p" + count);
                System.out.println(items.getName());
                jp.add(items);
                 sub_p.subCategory_Panel2.add(items);
                 sub_p.subCategory_Panel2.revalidate();
                count++;
                System.out.println(rs.getString("products"));

            }
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
    }
    
     public void addBicyclesItems() {
        System.out.println("addBicyclesItems method is Called !");
        try {
            st = conn.createStatement();
            String query = "Select * from shoping_products where bikes=1 AND sub_category='BICYCLES' ";
            rs = st.executeQuery(query);
            while (rs.next()) {
                System.out.println("Inside while");
                items = new AddingProducts();
                sub_p.categoryLabel1.setText(rs.getString("sub_category"));
                items.proNameLabel.setText(rs.getString("PRODUCTS"));
                items.proPriceLabel.setText(rs.getString("PRICE"));
                byte[] img = rs.getBytes("Product_Img");
                ImageIcon image = new ImageIcon(img);
                Image icon = image.getImage();
                Image myImg = icon.getScaledInstance(items.img_label.getHeight(), items.img_label.getWidth(), Image.SCALE_SMOOTH);
                ImageIcon newImage = new ImageIcon(myImg);
                items.img_label.setIcon(newImage);
                items.setName("p" + count);
                System.out.println(items.getName());
                jp.add(items);
                sub_p.subCategory_Panel1.add(items);
                sub_p.subCategory_Panel1.revalidate();
                count++;
                System.out.println(rs.getString("products"));

            }
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
    }
    
      public void addMotorCycleItems() {
        System.out.println("addMotorCycleItems method is Called !");
        try {
            st = conn.createStatement();
            String query = "Select * from shoping_products where bikes=1 AND sub_category='MOTOR-CYCLES' ";
            rs = st.executeQuery(query);
            while (rs.next()) {
                System.out.println("Inside while");
                items = new AddingProducts();
                sub_p.categoryLabel2.setText(rs.getString("sub_category"));
                items.proNameLabel.setText(rs.getString("PRODUCTS"));
                items.proPriceLabel.setText(rs.getString("PRICE"));
                byte[] img = rs.getBytes("Product_Img");
                ImageIcon image = new ImageIcon(img);
                Image icon = image.getImage();
                Image myImg = icon.getScaledInstance(items.img_label.getHeight(), items.img_label.getWidth(), Image.SCALE_SMOOTH);
                ImageIcon newImage = new ImageIcon(myImg);
                items.img_label.setIcon(newImage);
                items.setName("p" + count);
                System.out.println(items.getName());
                jp.add(items);
                sub_p.subCategory_Panel2.add(items);
                sub_p.subCategory_Panel2.revalidate();
                count++;
                System.out.println(rs.getString("products"));

            }
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
    }
      
       public void addCompAcceItems() {
        System.out.println("addCompAcceItems method is Called !");
        try {
            st = conn.createStatement();
            String query = "Select * from shoping_products where electronics=1 AND sub_category='COMPUTER ACCESSORIES' ";
            rs = st.executeQuery(query);
            while (rs.next()) {
                System.out.println("Inside while");
                items = new AddingProducts();
                sub_p.categoryLabel1.setText(rs.getString("sub_category"));
                items.proNameLabel.setText(rs.getString("PRODUCTS"));
                items.proPriceLabel.setText(rs.getString("PRICE"));
                byte[] img = rs.getBytes("Product_Img");
                ImageIcon image = new ImageIcon(img);
                Image icon = image.getImage();
                Image myImg = icon.getScaledInstance(items.img_label.getHeight(), items.img_label.getWidth(), Image.SCALE_SMOOTH);
                ImageIcon newImage = new ImageIcon(myImg);
                items.img_label.setIcon(newImage);
                items.setName("p" + count);
                System.out.println(items.getName());
                jp.add(items);
                sub_p.subCategory_Panel1.add(items);
                sub_p.subCategory_Panel1.revalidate();
                count++;
                System.out.println(rs.getString("products"));

            }
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
    }

       
      public void addHomeElectricalItems() {
        System.out.println("addMotorCycleItems method is Called !");
        try {
            st = conn.createStatement();
            String query = "Select * from shoping_products where electronics=1 AND sub_category='HOME ELECTRICAL' ";
            rs = st.executeQuery(query);
            while (rs.next()) {
                System.out.println("Inside while");
                items = new AddingProducts();
                sub_p.categoryLabel2.setText(rs.getString("sub_category"));
                items.proNameLabel.setText(rs.getString("PRODUCTS"));
                items.proPriceLabel.setText(rs.getString("PRICE"));
                byte[] img = rs.getBytes("Product_Img");
                ImageIcon image = new ImageIcon(img);
                Image icon = image.getImage();
                Image myImg = icon.getScaledInstance(items.img_label.getHeight(), items.img_label.getWidth(), Image.SCALE_SMOOTH);
                ImageIcon newImage = new ImageIcon(myImg);
                items.img_label.setIcon(newImage);
                items.setName("p" + count);
                System.out.println(items.getName());
                jp.add(items);
                sub_p.subCategory_Panel2.add(items);
                sub_p.subCategory_Panel2.revalidate();
                count++;
                System.out.println(rs.getString("products"));

            }
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
    }
      
     public void addBedWardItems() {
        System.out.println("addBedWardItems method is Called !");
        try {
            st = conn.createStatement();
            String query = "Select * from shoping_products where furniture=1 AND sub_category='BEDS AND WARDROBES' ";
            rs = st.executeQuery(query);
            while (rs.next()) {
                System.out.println("Inside while");
                items = new AddingProducts();
                sub_p.categoryLabel1.setText(rs.getString("sub_category"));
                items.proNameLabel.setText(rs.getString("PRODUCTS"));
                items.proPriceLabel.setText(rs.getString("PRICE"));
                byte[] img = rs.getBytes("Product_Img");
                ImageIcon image = new ImageIcon(img);
                Image icon = image.getImage();
                Image myImg = icon.getScaledInstance(items.img_label.getHeight(), items.img_label.getWidth(), Image.SCALE_SMOOTH);
                ImageIcon newImage = new ImageIcon(myImg);
                items.img_label.setIcon(newImage);
                items.setName("p" + count);
                System.out.println(items.getName());
                jp.add(items);
                sub_p.subCategory_Panel1.add(items);
                sub_p.subCategory_Panel1.revalidate();
                count++;
                System.out.println(rs.getString("products"));

            }
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
    }

       
      public void  addTableDinningItems(){
        System.out.println("addTableDinningItems method is Called !");
        try {
            st = conn.createStatement();
            String query = "Select * from shoping_products where furniture=1 AND sub_category='TABLES AND DINING' ";
            rs = st.executeQuery(query);
            while (rs.next()) {
                System.out.println("Inside while");
                items = new AddingProducts();
                sub_p.categoryLabel2.setText(rs.getString("sub_category"));
                items.proNameLabel.setText(rs.getString("PRODUCTS"));
                items.proPriceLabel.setText(rs.getString("PRICE"));
                byte[] img = rs.getBytes("Product_Img");
                ImageIcon image = new ImageIcon(img);
                Image icon = image.getImage();
                Image myImg = icon.getScaledInstance(items.img_label.getHeight(), items.img_label.getWidth(), Image.SCALE_SMOOTH);
                ImageIcon newImage = new ImageIcon(myImg);
                items.img_label.setIcon(newImage);
                items.setName("p" + count);
                System.out.println(items.getName());
                jp.add(items);
                sub_p.subCategory_Panel2.add(items);
                sub_p.subCategory_Panel2.revalidate();
                count++;
                System.out.println(rs.getString("products"));

            }
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
    }
      
      public void  addSofaChairsItems(){
        System.out.println("addSofaChairsItems method is Called !");
        try {
            st = conn.createStatement();
            String query = "Select * from shoping_products where furniture=1 AND sub_category='SOFA & CHAIRS' ";
            rs = st.executeQuery(query);
            while (rs.next()) {
                System.out.println("Inside while");
                items = new AddingProducts();
                //sub_p.categoryLabel3.setText(rs.getString("sub_category"));
                items.proNameLabel.setText(rs.getString("PRODUCTS"));
                items.proPriceLabel.setText(rs.getString("PRICE"));
                byte[] img = rs.getBytes("Product_Img");
                ImageIcon image = new ImageIcon(img);
                Image icon = image.getImage();
                Image myImg = icon.getScaledInstance(items.img_label.getHeight(), items.img_label.getWidth(), Image.SCALE_SMOOTH);
                ImageIcon newImage = new ImageIcon(myImg);
                items.img_label.setIcon(newImage);
                items.setName("p" + count);
                System.out.println(items.getName());
                jp.add(items);
//                sub_p.subCategory_Panel3.add(items);
//                sub_p.subCategory_Panel3.revalidate();
                count++;
                System.out.println(rs.getString("products"));

            }
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
    }
      
   public void loginCondition(){
   System.out.println("loginCondition method is Called !");
        try {
            st = conn.createStatement();
            String query = "Select * from shoping_reg where user_name='"+myAccountBtn.getText()+"'";
            rs = st.executeQuery(query);
            if (rs.next()) {
                System.out.println("Inside if");
               ucf = new UserCartFrame();
               ucf.show();
               
            }
            else{
             new Shoping_Login().show();
            }
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
   }
   
    public void logoutCondition(){
   System.out.println("logoutCondition method is Called !");
        try {
            st = conn.createStatement();
            String query = "Select * from shoping_reg where user_name='"+myAccountBtn.getText()+"'";
            rs = st.executeQuery(query);
            if (rs.next()) {
                System.out.println("Inside if");
                this.dispose();
            }
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
   }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        MainPanel = new javax.swing.JPanel();
        backgroundPanel = new javax.swing.JPanel();
        categoryPanel = new javax.swing.JPanel();
        BikesBtn = new javax.swing.JButton();
        mobileBtn = new javax.swing.JButton();
        electronicsBtn = new javax.swing.JButton();
        furnitureBtn = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        myAccountBtn = new javax.swing.JButton();
        detailsBtn = new javax.swing.JButton();
        addProductsBtn = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        logoutBtn = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        backBtn = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(null);

        backgroundPanel.setBackground(new java.awt.Color(255, 255, 255));
        backgroundPanel.setLayout(new java.awt.CardLayout());

        categoryPanel.setBackground(new java.awt.Color(255, 255, 255));
        categoryPanel.setLayout(null);

        BikesBtn.setBackground(new java.awt.Color(255, 255, 255));
        BikesBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/shoppingapp/bikeIcon.jpg"))); // NOI18N
        BikesBtn.setBorder(null);
        BikesBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BikesBtnActionPerformed(evt);
            }
        });
        categoryPanel.add(BikesBtn);
        BikesBtn.setBounds(520, 20, 450, 300);

        mobileBtn.setBackground(new java.awt.Color(255, 255, 255));
        mobileBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/shoppingapp/mb1.png"))); // NOI18N
        mobileBtn.setBorder(null);
        mobileBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mobileBtnActionPerformed(evt);
            }
        });
        categoryPanel.add(mobileBtn);
        mobileBtn.setBounds(240, 470, 230, 220);

        electronicsBtn.setBackground(new java.awt.Color(255, 255, 255));
        electronicsBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/shoppingapp/electrical I.png"))); // NOI18N
        electronicsBtn.setBorder(null);
        electronicsBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                electronicsBtnActionPerformed(evt);
            }
        });
        categoryPanel.add(electronicsBtn);
        electronicsBtn.setBounds(550, 340, 380, 350);

        furnitureBtn.setBackground(new java.awt.Color(255, 255, 255));
        furnitureBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/shoppingapp/fur Icon.jpg"))); // NOI18N
        furnitureBtn.setBorder(null);
        furnitureBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                furnitureBtnActionPerformed(evt);
            }
        });
        categoryPanel.add(furnitureBtn);
        furnitureBtn.setBounds(20, 10, 450, 420);

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/shoppingapp/shop.gif"))); // NOI18N
        categoryPanel.add(jLabel1);
        jLabel1.setBounds(980, 0, 100, 100);

        backgroundPanel.add(categoryPanel, "card2");

        javax.swing.GroupLayout MainPanelLayout = new javax.swing.GroupLayout(MainPanel);
        MainPanel.setLayout(MainPanelLayout);
        MainPanelLayout.setHorizontalGroup(
            MainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(backgroundPanel, javax.swing.GroupLayout.DEFAULT_SIZE, 1091, Short.MAX_VALUE)
        );
        MainPanelLayout.setVerticalGroup(
            MainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(MainPanelLayout.createSequentialGroup()
                .addComponent(backgroundPanel, javax.swing.GroupLayout.PREFERRED_SIZE, 2273, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 481, Short.MAX_VALUE))
        );

        jScrollPane1.setViewportView(MainPanel);

        getContentPane().add(jScrollPane1);
        jScrollPane1.setBounds(260, 160, 1100, 2130);

        jPanel3.setBackground(new java.awt.Color(153, 204, 255));
        jPanel3.setBorder(javax.swing.BorderFactory.createEtchedBorder(new java.awt.Color(153, 153, 153), new java.awt.Color(153, 153, 153)));
        jPanel3.setLayout(null);

        myAccountBtn.setBackground(new java.awt.Color(255, 255, 255));
        myAccountBtn.setFont(new java.awt.Font("Times New Roman", 3, 18)); // NOI18N
        myAccountBtn.setForeground(new java.awt.Color(0, 51, 204));
        myAccountBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/shoppingapp/myAccount.png"))); // NOI18N
        myAccountBtn.setText("MY ACCOUNT");
        myAccountBtn.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(153, 153, 153), new java.awt.Color(153, 153, 153), new java.awt.Color(153, 153, 153), new java.awt.Color(153, 153, 153)));
        myAccountBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                myAccountBtnActionPerformed(evt);
            }
        });
        jPanel3.add(myAccountBtn);
        myAccountBtn.setBounds(760, 50, 200, 60);

        detailsBtn.setBackground(new java.awt.Color(255, 255, 255));
        detailsBtn.setFont(new java.awt.Font("Times New Roman", 3, 18)); // NOI18N
        detailsBtn.setForeground(new java.awt.Color(0, 51, 204));
        detailsBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/shoppingapp/details.png"))); // NOI18N
        detailsBtn.setText(" DETAILS");
        detailsBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                detailsBtnActionPerformed(evt);
            }
        });
        jPanel3.add(detailsBtn);
        detailsBtn.setBounds(20, 30, 170, 40);

        addProductsBtn.setBackground(new java.awt.Color(255, 255, 255));
        addProductsBtn.setFont(new java.awt.Font("Times New Roman", 3, 18)); // NOI18N
        addProductsBtn.setForeground(new java.awt.Color(0, 51, 204));
        addProductsBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/shoppingapp/add1.png"))); // NOI18N
        addProductsBtn.setText("PRODUCTS");
        addProductsBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addProductsBtnActionPerformed(evt);
            }
        });
        jPanel3.add(addProductsBtn);
        addProductsBtn.setBounds(20, 90, 170, 40);

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/shoppingapp/logo.png"))); // NOI18N
        jPanel3.add(jLabel2);
        jLabel2.setBounds(290, 0, 420, 160);

        logoutBtn.setBackground(new java.awt.Color(255, 255, 255));
        logoutBtn.setFont(new java.awt.Font("Times New Roman", 3, 18)); // NOI18N
        logoutBtn.setForeground(new java.awt.Color(0, 51, 204));
        logoutBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/shoppingapp/LOGOUT.png"))); // NOI18N
        logoutBtn.setText("LOGOUT");
        logoutBtn.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(153, 153, 153), new java.awt.Color(153, 153, 153), new java.awt.Color(153, 153, 153), new java.awt.Color(153, 153, 153)));
        logoutBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                logoutBtnActionPerformed(evt);
            }
        });
        jPanel3.add(logoutBtn);
        logoutBtn.setBounds(970, 50, 120, 60);

        getContentPane().add(jPanel3);
        jPanel3.setBounds(260, 0, 1100, 160);

        jPanel2.setBackground(new java.awt.Color(153, 204, 255));
        jPanel2.setBorder(javax.swing.BorderFactory.createEtchedBorder(new java.awt.Color(153, 153, 153), new java.awt.Color(153, 153, 153)));
        jPanel2.setLayout(null);

        backBtn.setBackground(new java.awt.Color(153, 204, 255));
        backBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/shoppingapp/back (1).png"))); // NOI18N
        backBtn.setBorder(null);
        backBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                backBtnActionPerformed(evt);
            }
        });
        jPanel2.add(backBtn);
        backBtn.setBounds(10, 10, 30, 50);

        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/shoppingapp/logo2.gif"))); // NOI18N
        jPanel2.add(jLabel3);
        jLabel3.setBounds(10, 300, 230, 310);

        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/shoppingapp/shop2.png"))); // NOI18N
        jPanel2.add(jLabel4);
        jLabel4.setBounds(-90, 170, 350, 130);

        getContentPane().add(jPanel2);
        jPanel2.setBounds(0, 0, 260, 3730);

        setSize(new java.awt.Dimension(1376, 3767));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void mobileBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mobileBtnActionPerformed
        backBtn.setVisible(true);
        categoryPanel.setVisible(false);
        backgroundPanel.setVisible(true);
        backgroundPanel.add(sub_p);
        backgroundPanel.revalidate();
        sub_p.show();
        addPhonesItems();
        addTabletsItems();
    }//GEN-LAST:event_mobileBtnActionPerformed

    private void backBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_backBtnActionPerformed
        this.setVisible(false);
        new ShopingApp_MainFrame().show();
        
    }//GEN-LAST:event_backBtnActionPerformed

    private void myAccountBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_myAccountBtnActionPerformed
      loginCondition();  
        
    }//GEN-LAST:event_myAccountBtnActionPerformed

    private void BikesBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BikesBtnActionPerformed
          backBtn.setVisible(true);
          categoryPanel.setVisible(false);
         backgroundPanel.setVisible(true);
         backgroundPanel.add(sub_p);
         backgroundPanel.revalidate();
         sub_p.show();
          addBicyclesItems();
          addMotorCycleItems();
    }//GEN-LAST:event_BikesBtnActionPerformed

    private void electronicsBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_electronicsBtnActionPerformed
          backBtn.setVisible(true);
          categoryPanel.setVisible(false);
         backgroundPanel.setVisible(true);
         backgroundPanel.add(sub_p);
         backgroundPanel.revalidate();
         sub_p.show();
         addCompAcceItems();
         addHomeElectricalItems();
    }//GEN-LAST:event_electronicsBtnActionPerformed

    private void furnitureBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_furnitureBtnActionPerformed
        backBtn.setVisible(true);
        categoryPanel.setVisible(false);
         backgroundPanel.setVisible(true);
         backgroundPanel.add(sub_p);
         backgroundPanel.revalidate();
         sub_p.show();
         addBedWardItems();
         addTableDinningItems();
         addSofaChairsItems();
    }//GEN-LAST:event_furnitureBtnActionPerformed

    private void detailsBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_detailsBtnActionPerformed
     new CustomerInfo().show();
    }//GEN-LAST:event_detailsBtnActionPerformed

    private void addProductsBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addProductsBtnActionPerformed
     new Add_Products().show();
    }//GEN-LAST:event_addProductsBtnActionPerformed

    private void logoutBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_logoutBtnActionPerformed
      logoutCondition();
    }//GEN-LAST:event_logoutBtnActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ShopingApp_MainFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ShopingApp_MainFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ShopingApp_MainFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ShopingApp_MainFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ShopingApp_MainFrame().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BikesBtn;
    private javax.swing.JPanel MainPanel;
    public javax.swing.JButton addProductsBtn;
    private javax.swing.JButton backBtn;
    private javax.swing.JPanel backgroundPanel;
    private javax.swing.JPanel categoryPanel;
    public javax.swing.JButton detailsBtn;
    private javax.swing.JButton electronicsBtn;
    private javax.swing.JButton furnitureBtn;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    public javax.swing.JButton logoutBtn;
    private javax.swing.JButton mobileBtn;
    public javax.swing.JButton myAccountBtn;
    // End of variables declaration//GEN-END:variables
}
