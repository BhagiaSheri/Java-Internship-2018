package shoppingapp;
import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.sql.*;
import java.io.*;
import java.util.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ButtonGroup;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import net.proteanit.sql.DbUtils;
public class CustomerInfo extends javax.swing.JFrame {
Connection conn;
Statement st;
ResultSet rs;
String r_id;
 String uname=null;
 String email=null;
 String pass= null;
 String contact_no=null;
 String role= null;
     /**
     * Creates new form MainCompanyFrame
     */
    public CustomerInfo() {
        initComponents();
        this.R_idTextField.disable();
        try{
          Class.forName("oracle.jdbc.driver.OracleDriver");
             conn= DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","BHAGIA SHERI","123456789");
            if(conn!=null){
                System.out.println("Connection Succesfullly!");
            }
        }catch(Exception ex){
                System.out.println(ex.getMessage());
                }
           tableData();
    }
   
    
  
  public void validationForInsertion() throws SQLException{
        try {
            st = conn.createStatement();
            String query = "select * from shoping_reg where email_id='" + Email_textfield.getText() + "' OR user_name='" + U_nameTextfield.getText() + "'";
            rs = st.executeQuery(query);
            if (rs.next()) {
                JOptionPane.showMessageDialog(null, "USER NAME OR EMAIL ID ALREADY EXISTS !!!");
            } else {
                showData();
            }
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
  }     
  public void showData(){
      
 uname=this.U_nameTextfield.getText();
email=this.Email_textfield.getText();
 pass=this.pass_textfield.getText();
 contact_no= this.contact_txtfield.getText();
role=this.role_dropdown.getSelectedItem().toString();
if(role.equalsIgnoreCase("admin")){
uname = uname+"Admin";
}
try {
       st=conn.createStatement();  
        String query="insert into shoping_reg(R_ID,User_Name,Email_id,Contact_no,password,role)values(SHOPING_REG_SEQUENCE.NEXTVAL,'"+uname+"','"+email+"','"+contact_no+"', '"+pass+"','"+role+"')" ;
         int row=st.executeUpdate(query);
         System.out.println("uname  "+uname);
           if(row>0){
              System.out.println("DATA INSERTED !");
              JOptionPane.showMessageDialog(null, "REGISTERED !!!");
              tableData();
   }
          else{
          System.out.println("DATA NOT INSERTED !");
          }
      
         }
     catch (Exception ex) {
     System.out.println(ex.getMessage());
     }
this.R_idTextField.setText("");
this.U_nameTextfield.setText("");
this.Email_textfield.setText("");
this.pass_textfield.setText("");
this.contact_txtfield.setText("");
this.role_dropdown.setSelectedIndex(0);
}

  public void tableData(){
    JTableHeader jh = customer_table.getTableHeader();
    jh.setBackground(Color.WHITE);
    jh.setForeground(Color.BLACK);
    jh.setFont(new Font ("Times New Roman", Font.PLAIN , 14));
    customer_table.setBackground(new Color(0,0,0,0));
    ((DefaultTableCellRenderer)customer_table.getDefaultRenderer(Object.class)).setBackground(new Color(0,0,0,0));
   customer_table.setGridColor(Color.GRAY);
 jScrollPane2.setBackground(new Color(0,0,0,0));
  jScrollPane2.setOpaque(false);
customer_table.setOpaque(false);
 ((DefaultTableCellRenderer)customer_table.getDefaultRenderer(Object.class)).setOpaque(true);
 jScrollPane2.getViewport().setOpaque(false);
  customer_table.setShowGrid(true);
    try{
   Statement   stm = conn.createStatement();
          rs = stm.executeQuery("select * from shoping_reg"); 
          customer_table.setModel(DbUtils.resultSetToTableModel(rs));
    }catch(Exception e){
     System.out.println(e.getMessage());
    }
    }
    
  public void updateRow() throws ParseException{
      
  if(customer_table.getSelectedRowCount()==0){
  JOptionPane.showMessageDialog(null,"SELECT ANY ROW FIRST !");
  }
  else if(customer_table.getSelectedRowCount()==1){

  DefaultTableModel model = (DefaultTableModel)customer_table.getModel();
  int selectedRowIndex = customer_table.getSelectedRow();
  R_idTextField.setText(model.getValueAt(selectedRowIndex, 0).toString());
  U_nameTextfield.setText(model.getValueAt(selectedRowIndex, 1).toString());
  Email_textfield.setText(model.getValueAt(selectedRowIndex, 2).toString());
  //if(model.getValueAt(selectedRowIndex, 3).equals(null)){
  contact_txtfield.setText("");
 // }
//  else{
// contact_txtfield.setText(model.getValueAt(selectedRowIndex, 3).toString());
//  }
 pass_textfield.setText(model.getValueAt(selectedRowIndex, 4).toString());
 role_dropdown.setSelectedItem(model.getValueAt(selectedRowIndex, 5).toString());
  }
 else{
  JOptionPane.showMessageDialog(null, "ONE ROW CAN BE UPDATED AT A TIME !");
  }
  }
  
  public void deleteRow(){
  if(customer_table.getSelectedRowCount()==0){
  JOptionPane.showMessageDialog(null,"SELECT ANY ROW FIRST !");
  }
  else if(customer_table.getSelectedRowCount()==1){
  DefaultTableModel model = (DefaultTableModel)customer_table.getModel();
  int selectedRowIndex = customer_table.getSelectedRow();
  r_id = model.getValueAt(selectedRowIndex, 0).toString();
   try {
         Statement st=conn.createStatement();
          String query="DELETE FROM SHOPING_REG WHERE R_ID='"+r_id+"'" ;
         int row=st.executeUpdate(query);
           if(row>0){
              System.out.println("DATA DELETED !");
              JOptionPane.showMessageDialog(null, "REMOVED !!!");
              tableData();
           }
          else{
          System.out.println("DATA NOT DELETED !");
          }
          }
     catch (Exception ex) {
     System.out.println(ex.getMessage());
     }
  }
  else{
  JOptionPane.showMessageDialog(null, "ONE ROW CAN BE DELETED AT A TIME !");
  }
  }
  public void saveRow(){
  r_id = this.R_idTextField.getText();
  uname=this.U_nameTextfield.getText();
 email=this.Email_textfield.getText();
pass=this.pass_textfield.getText();
 contact_no= this.contact_txtfield.getText();
role=this.role_dropdown.getSelectedItem().toString();
if(role.equalsIgnoreCase("admin")){
uname = uname+"Admin";
}
    try{
        String query= "update shoping_reg set user_name=? , email_id= ? ,  contact_no=? , Password = ? , Role = ? WHERE R_ID="+r_id+"";
         PreparedStatement  ps = conn.prepareStatement(query);
         ps.setString(1, uname);
         ps.setString(2, email);
         ps.setString(3, contact_no);
         ps.setString(4, pass);
         ps.setString(5, role);
          int rows=  ps.executeUpdate();
           if(rows>0){
              System.out.println("DATA UPDATED !");  
              JOptionPane.showMessageDialog(null, "STATUS UPDATED !!!");
             tableData();
           }
          else{
           System.out.println("DATA NOT UPDATED !");
           }
        }catch(Exception e){
           System.out.println(e.getMessage());
        }   
this.R_idTextField.setText("");
this.U_nameTextfield.setText("");
this.Email_textfield.setText("");
this.pass_textfield.setText("");
this.contact_txtfield.setText("");
this.role_dropdown.setSelectedIndex(0);
   }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        R_idTextField = new javax.swing.JTextField();
        U_nameTextfield = new javax.swing.JTextField();
        Email_textfield = new javax.swing.JTextField();
        pass_textfield = new javax.swing.JTextField();
        contact_txtfield = new javax.swing.JTextField();
        role_dropdown = new javax.swing.JComboBox();
        save_botton = new javax.swing.JButton();
        update_button = new javax.swing.JButton();
        delete_button = new javax.swing.JButton();
        new_button = new javax.swing.JButton();
        jLabel10 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        customer_table = new javax.swing.JTable();
        jLabel3 = new javax.swing.JLabel();
        jButton3 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("EMPLOYEES INFORMATION FORM !!!");
        setBackground(new java.awt.Color(102, 102, 102));
        getContentPane().setLayout(null);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setLayout(null);

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));
        jPanel2.setBorder(javax.swing.BorderFactory.createEtchedBorder(new java.awt.Color(153, 153, 153), new java.awt.Color(153, 153, 153)));
        jPanel2.setLayout(null);

        jLabel1.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel1.setText("REGESTRATION ID:");
        jPanel2.add(jLabel1);
        jLabel1.setBounds(10, 20, 140, 20);

        jLabel2.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel2.setText("USER NAME:");
        jPanel2.add(jLabel2);
        jLabel2.setBounds(10, 70, 110, 20);

        jLabel4.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel4.setText("EMAIL");
        jPanel2.add(jLabel4);
        jLabel4.setBounds(10, 110, 90, 20);

        jLabel5.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel5.setText("PASSWORD:");
        jPanel2.add(jLabel5);
        jLabel5.setBounds(10, 190, 120, 17);

        jLabel6.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel6.setText("CONTACT:");
        jPanel2.add(jLabel6);
        jLabel6.setBounds(10, 150, 100, 17);

        jLabel7.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel7.setText("ROLE:");
        jPanel2.add(jLabel7);
        jLabel7.setBounds(10, 230, 130, 20);

        R_idTextField.setEditable(false);
        R_idTextField.setBackground(new java.awt.Color(255, 255, 204));
        R_idTextField.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        R_idTextField.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jPanel2.add(R_idTextField);
        R_idTextField.setBounds(180, 20, 160, 30);

        U_nameTextfield.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jPanel2.add(U_nameTextfield);
        U_nameTextfield.setBounds(180, 70, 160, 23);

        Email_textfield.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jPanel2.add(Email_textfield);
        Email_textfield.setBounds(180, 110, 160, 23);

        pass_textfield.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jPanel2.add(pass_textfield);
        pass_textfield.setBounds(180, 190, 160, 23);

        contact_txtfield.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jPanel2.add(contact_txtfield);
        contact_txtfield.setBounds(180, 150, 160, 23);

        role_dropdown.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        role_dropdown.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "SELECT ROLE", "ADMIN", "CUSTOMER" }));
        jPanel2.add(role_dropdown);
        role_dropdown.setBounds(180, 240, 160, 25);

        save_botton.setBackground(new java.awt.Color(0, 51, 204));
        save_botton.setFont(new java.awt.Font("Times New Roman", 3, 18)); // NOI18N
        save_botton.setForeground(new java.awt.Color(255, 255, 255));
        save_botton.setText("SAVE");
        save_botton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                save_bottonActionPerformed(evt);
            }
        });
        jPanel2.add(save_botton);
        save_botton.setBounds(600, 130, 160, 60);

        update_button.setBackground(new java.awt.Color(0, 51, 204));
        update_button.setFont(new java.awt.Font("Times New Roman", 3, 18)); // NOI18N
        update_button.setForeground(new java.awt.Color(255, 255, 255));
        update_button.setText("UPDATE");
        update_button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                update_buttonActionPerformed(evt);
            }
        });
        jPanel2.add(update_button);
        update_button.setBounds(600, 70, 160, 60);

        delete_button.setBackground(new java.awt.Color(0, 51, 204));
        delete_button.setFont(new java.awt.Font("Times New Roman", 3, 18)); // NOI18N
        delete_button.setForeground(new java.awt.Color(255, 255, 255));
        delete_button.setText("DELETE");
        delete_button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                delete_buttonActionPerformed(evt);
            }
        });
        jPanel2.add(delete_button);
        delete_button.setBounds(600, 190, 160, 60);

        new_button.setBackground(new java.awt.Color(0, 51, 204));
        new_button.setFont(new java.awt.Font("Times New Roman", 3, 18)); // NOI18N
        new_button.setForeground(new java.awt.Color(255, 255, 255));
        new_button.setText("NEW");
        new_button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                new_buttonActionPerformed(evt);
            }
        });
        jPanel2.add(new_button);
        new_button.setBounds(600, 10, 160, 60);

        jPanel1.add(jPanel2);
        jPanel2.setBounds(230, 200, 820, 280);

        jLabel10.setFont(new java.awt.Font("Times New Roman", 1, 20)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(153, 153, 153));
        jLabel10.setText("Details");
        jPanel1.add(jLabel10);
        jLabel10.setBounds(230, 170, 110, 30);

        customer_table.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 153, 153), 2));
        customer_table.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        customer_table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        customer_table.setSelectionBackground(new java.awt.Color(153, 153, 255));
        jScrollPane2.setViewportView(customer_table);

        jPanel1.add(jScrollPane2);
        jScrollPane2.setBounds(230, 480, 820, 190);

        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/shoppingapp/logo.png"))); // NOI18N
        jPanel1.add(jLabel3);
        jLabel3.setBounds(480, 20, 420, 160);

        jButton3.setBackground(new java.awt.Color(255, 255, 255));
        jButton3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/shoppingapp/back (1).png"))); // NOI18N
        jButton3.setBorder(null);
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton3);
        jButton3.setBounds(10, 10, 30, 50);

        getContentPane().add(jPanel1);
        jPanel1.setBounds(0, 0, 1390, 710);

        setSize(new java.awt.Dimension(1403, 752));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void new_buttonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_new_buttonActionPerformed
  if(U_nameTextfield.getText().equals("") || Email_textfield.getText().equals("") || pass_textfield.getText().equals("") ||  role_dropdown.getSelectedIndex()==0){
          JOptionPane.showMessageDialog(null,"FILL ALL FIELDS !");
       }
 else if (!(Email_textfield.getText().endsWith("@gmail.com"))) {
            JOptionPane.showMessageDialog(null, "INVALID EMAIL FORMAT !!!\n======================");
        }
  else{
  try{
       validationForInsertion();
  }catch(Exception ex){
  System.out.println(ex.getMessage());
  }
  }
    }//GEN-LAST:event_new_buttonActionPerformed

    private void update_buttonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_update_buttonActionPerformed
        try {
            updateRow();
        } catch (ParseException ex) {
            System.out.println(ex.getMessage());
        }
    }//GEN-LAST:event_update_buttonActionPerformed

    private void delete_buttonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_delete_buttonActionPerformed
        deleteRow();
    }//GEN-LAST:event_delete_buttonActionPerformed

    private void save_bottonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_save_bottonActionPerformed
       if(U_nameTextfield.getText().equals("") || Email_textfield.getText().equals("") || pass_textfield.getText().equals("") || role_dropdown.getSelectedIndex()==0 ){
          JOptionPane.showMessageDialog(null,"NULL VALUES CAN NOT BE UPDATED!!!");
       }
       else if (!(Email_textfield.getText().endsWith("@gmail.com"))) {
            JOptionPane.showMessageDialog(null, "INVALID EMAIL FORMAT !!!\n======================");
        }
       else{
           saveRow();
       }
    }//GEN-LAST:event_save_bottonActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        this.dispose();
    }//GEN-LAST:event_jButton3ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(CustomerInfo.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(CustomerInfo.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(CustomerInfo.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(CustomerInfo.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new CustomerInfo().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField Email_textfield;
    private javax.swing.JTextField R_idTextField;
    private javax.swing.JTextField U_nameTextfield;
    private javax.swing.JTextField contact_txtfield;
    private javax.swing.JTable customer_table;
    private javax.swing.JButton delete_button;
    private javax.swing.JButton jButton3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JButton new_button;
    private javax.swing.JTextField pass_textfield;
    private javax.swing.JComboBox role_dropdown;
    private javax.swing.JButton save_botton;
    private javax.swing.JButton update_button;
    // End of variables declaration//GEN-END:variables

}
