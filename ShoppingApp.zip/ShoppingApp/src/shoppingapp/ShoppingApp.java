package shoppingapp;

import java.sql.SQLException;

public class ShoppingApp {

    public static void main(String[] args) throws ClassNotFoundException, SQLException {
        new ShopingApp_MainFrame().show();
    }

}
