package schedulingmanager;
import java.sql.*;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.Timer;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import net.proteanit.sql.DbUtils;
import java.util.Date;
/**
 *
 * @author Hp
 */
public class ShowNotesFrame extends javax.swing.JFrame {
 Connection conn;  
 Statement st;
 ResultSet rs;
 String s_id;
 String descp, date, time, venue;
    /**
     * Creates new form ShowNotesFrame
     */
    public ShowNotesFrame() {
        initComponents();
          try{
          Class.forName("oracle.jdbc.driver.OracleDriver");
             conn= DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","BHAGIA SHERI","123456789");
            if(conn!=null){
                System.out.println("Connection Succesfullly!");
            }
        }catch(Exception ex){
                System.out.println(ex.getMessage());
                }
          showDate();
         showTime();
          updation_panel.setVisible(false);
           tableData();
           
           
    }
    
    public void showDate(){
 java.util.Date d = new java.util.Date();
 SimpleDateFormat sf = new SimpleDateFormat("yyyy-MM-dd");
 datelabel.setText(sf.format(d));
 }   
 
 public void showTime(){
  new Timer(0, new ActionListener(){
        @Override
        public void actionPerformed(ActionEvent e) {
          Date d = new Date();
        SimpleDateFormat sf = new SimpleDateFormat("HH:mm:ss");
        timelabel.setText(sf.format(d)); 
      }
      }).start();
 }
  
    public void tableData(){
    JTableHeader jh = notesTable.getTableHeader();
    jh.setBackground(new Color(153,153,255));
    jh.setForeground(Color.BLACK);
    jh.setFont(new Font ("BROADWAY", Font.BOLD , 18));
    notesTable.setBackground(new Color(0,0,0,0));
    ((DefaultTableCellRenderer)notesTable.getDefaultRenderer(Object.class)).setBackground(new Color(0,0,0,0));
    notesTable.setGridColor(Color.GRAY);
   notesTableScrollpane.setBackground(new Color(0,0,0,0));
  notesTableScrollpane.setOpaque(false);
  notesTable.setOpaque(false);
 ((DefaultTableCellRenderer)notesTable.getDefaultRenderer(Object.class)).setOpaque(true);
 notesTableScrollpane.getViewport().setOpaque(false);
  notesTable.setShowGrid(true);
    try{
   Statement   stm = conn.createStatement();
         rs = stm.executeQuery("select * from scheduling_note"); 
         notesTable.setModel(DbUtils.resultSetToTableModel(rs));
    }catch(Exception e){
     System.out.println(e.getMessage());
    }
    }
     
  public void updateRow() throws ParseException{
      
  if(notesTable.getSelectedRowCount()==0){
  JOptionPane.showMessageDialog(null,"SELECT ANY ROW FIRST !");
  }
  else if(notesTable.getSelectedRowCount()==1){
   updation_panel.setVisible(true);
  DefaultTableModel model = (DefaultTableModel)notesTable.getModel();
  int selectedRowIndex = notesTable.getSelectedRow();
 s_id=(model.getValueAt(selectedRowIndex, 0).toString());
 note_txtarea.setText(model.getValueAt(selectedRowIndex, 1).toString());
  java.util.Date date = new SimpleDateFormat("yyyy-MM-dd").parse((String)model.getValueAt(selectedRowIndex, 2).toString());
 dot_datachooser.setDate(date);
 venue_txtfield.setText(model.getValueAt(selectedRowIndex, 4).toString());
 try{
 st = conn.createStatement();
 String query = "Select tot from scheduling_note where S_ID='"+s_id+"'";
 rs= st.executeQuery(query);
 while(rs.next()){
  timeChooser.setTime(rs.getTime("tot"));
 }
 }catch(Exception e){
 System.out.println(e.getMessage());
 }

  
  }
 else{
  JOptionPane.showMessageDialog(null, "ONE ROW CAN BE UPDATED AT A TIME !");
  }
  }
  
  public void validationForSave(){
descp=note_txtarea.getText().toLowerCase();
date=((JTextField) dot_datachooser.getDateEditor().getUiComponent()).getText();
time=timeChooser.getFormatedTime().toString();
venue=venue_txtfield.getText().toLowerCase();
System.out.println(descp+","+date+","+time+","+venue);
 try{  
 st = conn.createStatement();
  String query = "Select * from scheduling_note where description='"+descp+"'AND DOT='"+date+"' AND TOT='"+time+"' AND venue='"+venue+"'";
  rs= st.executeQuery(query);
  if(rs.next()){
   System.out.println("if");
  JOptionPane.showMessageDialog(null, "SAME TASK ALREADY EXISTS! \n==================================");
  }
 else{
      System.out.println("else");
 validationForSave2();
  }
 }catch(Exception ex){
  System.out.println(ex.getMessage());
 }
  }        
  public void validationForSave2(){
date=((JTextField) dot_datachooser.getDateEditor().getUiComponent()).getText();
time=timeChooser.getFormatedTime().toString();
 try{  
 st = conn.createStatement();
  
  String query = "Select * from scheduling_note where DOT='"+date+"' AND TOT='"+time+"'";
  rs= st.executeQuery(query);
  if(rs.next()){
 System.out.println("if");
  JOptionPane.showMessageDialog(null, "YOU ALREADY HAVE DEFINED ANOTHER TASK IN SAME TIMINGS ! \n=================================================");
  }
  else{
 System.out.println("else");
 saveRow();
  }
 }catch(Exception ex){
  System.out.println(ex.getMessage());
 }
  }
 
  public void saveRow(){
  descp=note_txtarea.getText();
date=((JTextField) dot_datachooser.getDateEditor().getUiComponent()).getText();
time=timeChooser.getFormatedTime().toString();
venue=venue_txtfield.getText();
System.out.println(descp+","+date+","+time+","+venue);
    try{

        String query= "update Scheduling_note set description=? , dot= ? , tot=? , venue=? WHERE S_ID="+s_id+"";
           PreparedStatement  ps = conn.prepareStatement(query);
         ps.setString(1,   descp);
         ps.setString(2, date);
         ps.setString(3, time);
         ps.setString(4, venue);
          int rows=  ps.executeUpdate();
           if(rows>0){
               updation_panel.setVisible(false);
              tableData();
               JOptionPane.showMessageDialog(null, "ROW UPDATED !\n =================");
           }
          else{
           System.out.println("DATA NOT UPDATED !");
           }
        }catch(Exception e){
           System.out.println(e.getMessage());
        }   
   }
      public void deleteRow(){
  if(notesTable.getSelectedRowCount()==0){
  JOptionPane.showMessageDialog(null,"SELECT ANY ROW FIRST !");
  }
  else if(notesTable.getSelectedRowCount()==1){
  DefaultTableModel model = (DefaultTableModel)notesTable.getModel();
  int selectedRowIndex = notesTable.getSelectedRow();
  s_id = model.getValueAt(selectedRowIndex, 0).toString();
   try {
         Statement st=conn.createStatement();
          String query="DELETE FROM SCHEDULING_NOTE WHERE S_ID='"+s_id+"'" ;
         int row=st.executeUpdate(query);
           if(row>0){
              tableData();
              JOptionPane.showMessageDialog(null, "ROW DELETED !\n =================");
           }
          else{
          System.out.println("DATA NOT DELETED !");
          }
          }
     catch (Exception ex) {
     System.out.println(ex.getMessage());
     }
  }
  else{
  JOptionPane.showMessageDialog(null, "ONE ROW CAN BE DELETED AT A TIME !");
  }
  }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        background_panel = new javax.swing.JPanel();
        backButton = new javax.swing.JButton();
        exitbtn = new javax.swing.JButton();
        deleteBtn = new javax.swing.JButton();
        updateBtn = new javax.swing.JButton();
        notesTableScrollpane = new javax.swing.JScrollPane();
        notesTable = new javax.swing.JTable();
        jLabel5 = new javax.swing.JLabel();
        updation_panel = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        venue_txtfield = new javax.swing.JTextField();
        timeChooser = new lu.tudor.santec.jtimechooser.JTimeChooser();
        dot_datachooser = new com.toedter.calendar.JDateChooser();
        datelabel = new javax.swing.JLabel();
        timelabel = new javax.swing.JLabel();
        note_txtarea = new javax.swing.JTextField();
        save_button = new javax.swing.JButton();
        jLabel6 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("SHOW TASKS LIST!");
        getContentPane().setLayout(null);

        jPanel1.setBackground(new java.awt.Color(0, 0, 0));
        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(102, 102, 255), 5));
        jPanel1.setLayout(null);

        background_panel.setBackground(new java.awt.Color(255, 255, 255));
        background_panel.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(102, 102, 255), 5));
        background_panel.setLayout(null);

        backButton.setBackground(new java.awt.Color(204, 204, 204));
        backButton.setFont(new java.awt.Font("Times New Roman", 3, 18)); // NOI18N
        backButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/schedulingmanager/BACK.png"))); // NOI18N
        backButton.setText("BACK");
        backButton.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(153, 153, 153), new java.awt.Color(153, 153, 153), new java.awt.Color(153, 153, 153), new java.awt.Color(153, 153, 153)));
        backButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                backButtonActionPerformed(evt);
            }
        });
        background_panel.add(backButton);
        backButton.setBounds(620, 10, 150, 70);

        exitbtn.setBackground(new java.awt.Color(204, 204, 204));
        exitbtn.setFont(new java.awt.Font("Times New Roman", 3, 18)); // NOI18N
        exitbtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/schedulingmanager/exit.png"))); // NOI18N
        exitbtn.setText("EXIT");
        exitbtn.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(153, 153, 153), new java.awt.Color(153, 153, 153), new java.awt.Color(153, 153, 153), new java.awt.Color(153, 153, 153)));
        exitbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                exitbtnActionPerformed(evt);
            }
        });
        background_panel.add(exitbtn);
        exitbtn.setBounds(780, 10, 150, 70);

        deleteBtn.setBackground(new java.awt.Color(204, 204, 204));
        deleteBtn.setFont(new java.awt.Font("Times New Roman", 3, 14)); // NOI18N
        deleteBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/schedulingmanager/deleterow.png"))); // NOI18N
        deleteBtn.setText("DELETE");
        deleteBtn.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(153, 153, 153), new java.awt.Color(153, 153, 153), new java.awt.Color(153, 153, 153), new java.awt.Color(153, 153, 153)));
        deleteBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteBtnActionPerformed(evt);
            }
        });
        background_panel.add(deleteBtn);
        deleteBtn.setBounds(460, 10, 150, 60);

        updateBtn.setBackground(new java.awt.Color(204, 204, 204));
        updateBtn.setFont(new java.awt.Font("Times New Roman", 3, 14)); // NOI18N
        updateBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/schedulingmanager/update.png"))); // NOI18N
        updateBtn.setText("UPDATE");
        updateBtn.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(153, 153, 153), new java.awt.Color(153, 153, 153), new java.awt.Color(153, 153, 153), new java.awt.Color(153, 153, 153)));
        updateBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                updateBtnActionPerformed(evt);
            }
        });
        background_panel.add(updateBtn);
        updateBtn.setBounds(10, 10, 150, 60);

        notesTable.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(153, 153, 153), new java.awt.Color(153, 153, 153), new java.awt.Color(153, 153, 153), new java.awt.Color(153, 153, 153)));
        notesTable.setFont(new java.awt.Font("Times New Roman", 3, 14)); // NOI18N
        notesTable.setForeground(new java.awt.Color(153, 0, 153));
        notesTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        notesTable.setSelectionBackground(new java.awt.Color(153, 255, 255));
        notesTableScrollpane.setViewportView(notesTable);

        background_panel.add(notesTableScrollpane);
        notesTableScrollpane.setBounds(10, 70, 600, 290);

        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/schedulingmanager/alarm.gif"))); // NOI18N
        background_panel.add(jLabel5);
        jLabel5.setBounds(630, 100, 290, 520);

        updation_panel.setBackground(new java.awt.Color(153, 153, 255));
        updation_panel.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(51, 51, 51), new java.awt.Color(51, 51, 51), new java.awt.Color(51, 51, 51), new java.awt.Color(51, 51, 51)));
        updation_panel.setLayout(null);

        jLabel1.setFont(new java.awt.Font("Times New Roman", 3, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 51, 51));
        jLabel1.setText("DESCRIPTION: ");
        updation_panel.add(jLabel1);
        jLabel1.setBounds(50, 40, 140, 30);

        jLabel2.setFont(new java.awt.Font("Times New Roman", 3, 18)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(0, 51, 51));
        jLabel2.setText("DATE: ");
        updation_panel.add(jLabel2);
        jLabel2.setBounds(50, 80, 130, 30);

        jLabel3.setFont(new java.awt.Font("Times New Roman", 3, 18)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(0, 51, 51));
        jLabel3.setText("TIME: ");
        updation_panel.add(jLabel3);
        jLabel3.setBounds(50, 120, 120, 30);

        jLabel4.setFont(new java.awt.Font("Times New Roman", 3, 18)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(0, 51, 51));
        jLabel4.setText("VENUE: ");
        updation_panel.add(jLabel4);
        jLabel4.setBounds(50, 160, 120, 30);

        venue_txtfield.setFont(new java.awt.Font("Times New Roman", 3, 14)); // NOI18N
        venue_txtfield.setForeground(new java.awt.Color(0, 51, 51));
        venue_txtfield.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        updation_panel.add(venue_txtfield);
        venue_txtfield.setBounds(220, 160, 250, 30);

        timeChooser.setBackground(new java.awt.Color(255, 255, 255));
        timeChooser.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        timeChooser.setForeground(new java.awt.Color(0, 51, 51));
        timeChooser.setFont(new java.awt.Font("Times New Roman", 3, 14)); // NOI18N
        timeChooser.setShowIcon(true);
        updation_panel.add(timeChooser);
        timeChooser.setBounds(220, 120, 250, 30);

        dot_datachooser.setBackground(new java.awt.Color(255, 255, 255));
        dot_datachooser.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        dot_datachooser.setForeground(new java.awt.Color(0, 51, 51));
        dot_datachooser.setDateFormatString("yyyy-MM-dd");
        dot_datachooser.setFont(new java.awt.Font("Times New Roman", 3, 14)); // NOI18N
        updation_panel.add(dot_datachooser);
        dot_datachooser.setBounds(220, 80, 250, 30);

        datelabel.setFont(new java.awt.Font("Times New Roman", 3, 18)); // NOI18N
        datelabel.setText("DATE");
        updation_panel.add(datelabel);
        datelabel.setBounds(10, 0, 100, 30);

        timelabel.setBackground(new java.awt.Color(153, 153, 255));
        timelabel.setFont(new java.awt.Font("Times New Roman", 3, 18)); // NOI18N
        timelabel.setText("TIME");
        updation_panel.add(timelabel);
        timelabel.setBounds(410, 0, 110, 30);

        note_txtarea.setFont(new java.awt.Font("Times New Roman", 3, 14)); // NOI18N
        note_txtarea.setForeground(new java.awt.Color(0, 51, 51));
        note_txtarea.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        updation_panel.add(note_txtarea);
        note_txtarea.setBounds(220, 40, 250, 30);

        save_button.setBackground(new java.awt.Color(204, 204, 204));
        save_button.setFont(new java.awt.Font("Times New Roman", 3, 20)); // NOI18N
        save_button.setForeground(new java.awt.Color(0, 51, 51));
        save_button.setIcon(new javax.swing.ImageIcon(getClass().getResource("/schedulingmanager/save.png"))); // NOI18N
        save_button.setText("SAVE");
        save_button.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(153, 153, 153), new java.awt.Color(153, 153, 153), new java.awt.Color(153, 153, 153), new java.awt.Color(153, 153, 153)));
        save_button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                save_buttonActionPerformed(evt);
            }
        });
        updation_panel.add(save_button);
        save_button.setBounds(220, 200, 150, 50);

        background_panel.add(updation_panel);
        updation_panel.setBounds(10, 360, 600, 260);

        jLabel6.setFont(new java.awt.Font("Times New Roman", 3, 40)); // NOI18N
        jLabel6.setText("TODO - LIST !");
        background_panel.add(jLabel6);
        jLabel6.setBounds(180, 13, 260, 47);

        jPanel1.add(background_panel);
        background_panel.setBounds(20, 20, 940, 640);

        getContentPane().add(jPanel1);
        jPanel1.setBounds(0, 0, 980, 680);

        setSize(new java.awt.Dimension(996, 719));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void backButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_backButtonActionPerformed
        this.setVisible(false);
        new Schedule_MainFrame().show();
    }//GEN-LAST:event_backButtonActionPerformed

    private void exitbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_exitbtnActionPerformed
        System.exit(0);
    }//GEN-LAST:event_exitbtnActionPerformed

    private void deleteBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteBtnActionPerformed
       deleteRow();
    }//GEN-LAST:event_deleteBtnActionPerformed

    private void updateBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_updateBtnActionPerformed
     try {
         updateRow();
     } catch (ParseException ex) {
         Logger.getLogger(ShowNotesFrame.class.getName()).log(Level.SEVERE, null, ex);
     }
    }//GEN-LAST:event_updateBtnActionPerformed

    private void save_buttonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_save_buttonActionPerformed
        if(note_txtarea.getText().equals("")  || timeChooser.getFormatedTime().equals("00:00:00") || venue_txtfield.getText().equals("") || ((JTextField) dot_datachooser.getDateEditor().getUiComponent()).getText().toString().equals("")){
            JOptionPane.showMessageDialog(null,"NULL VALUES CAN NOT BE UPDATED !!! \n ==============================");
        }
        else{
            validationForSave();
        }
    }//GEN-LAST:event_save_buttonActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ShowNotesFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ShowNotesFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ShowNotesFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ShowNotesFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ShowNotesFrame().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton backButton;
    private javax.swing.JPanel background_panel;
    private javax.swing.JLabel datelabel;
    private javax.swing.JButton deleteBtn;
    private com.toedter.calendar.JDateChooser dot_datachooser;
    private javax.swing.JButton exitbtn;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JTextField note_txtarea;
    private javax.swing.JTable notesTable;
    private javax.swing.JScrollPane notesTableScrollpane;
    private javax.swing.JButton save_button;
    private lu.tudor.santec.jtimechooser.JTimeChooser timeChooser;
    private javax.swing.JLabel timelabel;
    private javax.swing.JButton updateBtn;
    private javax.swing.JPanel updation_panel;
    private javax.swing.JTextField venue_txtfield;
    // End of variables declaration//GEN-END:variables
}
