package schedulingmanager;
public class SchedulingManager{
public static void main(String[] args) {
SplashScreenFrame sf=  new SplashScreenFrame();
 sf.setVisible(true);
 try{
 for(int loading =0;loading<=100; loading++){
  Thread.sleep(35);
  sf.jProgressBar1.setValue(loading);
  if(loading==100){
  sf.setVisible(false);
 new BackgroundFrame().show();
  }
  }
  }catch(Exception ex){
System.out.println(ex.getMessage());
 } 
 }
 }
