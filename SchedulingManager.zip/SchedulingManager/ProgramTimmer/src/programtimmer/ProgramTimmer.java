package programtimmer;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import static java.lang.Thread.sleep;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import javax.swing.JOptionPane;
import sun.audio.AudioPlayer;
import sun.audio.AudioStream;
public class ProgramTimmer {
Connection conn;  
   Statement st;
   ResultSet rs;
   InputStream music;
   AudioStream audios;  
   static  String des, da, ti;
   static String currentTime;
    static  String currentDate;
   public void checkTask(){
       System.out.println("Inside checkTask method !");
       Thread t = new Thread(){
        public void run(){
        int wl=0;
         try{
          Class.forName("oracle.jdbc.driver.OracleDriver");
             conn= DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","BHAGIA SHERI","123456789");
            if(conn!=null){
                System.out.println("Connection Succesfullly!");
            }
           st = conn.createStatement();
           Date d  = new Date();
          SimpleDateFormat sf = new SimpleDateFormat("yyyy-MM-dd");
          currentDate=sf.format(d);
           System.out.println(currentDate);  
         while(wl==0){
         Calendar c = new GregorianCalendar();
         String hours = Integer.toString(c.get(Calendar.HOUR_OF_DAY));
         String mins=Integer.toString(c.get(Calendar.MINUTE));
        String secs = Integer.toString(c.get(Calendar.SECOND));
        if(hours.length()==1){
        hours="0"+hours;
        }
        if(mins.length()==1){
        mins="0"+mins;
        }
         if(secs.length()==1){
        secs="0"+secs;
        }
         currentTime = hours+":"+mins+":"+secs;
         System.out.println("CurrentTime is:  "+currentTime);
        
         String query = "Select * from scheduling_note where tot='"+currentTime+"' AND dot='"+currentDate+"'";
         rs= st.executeQuery(query);
        
        if(rs.next()){
          System.out.println("Inside if");  
          ti=rs.getString("tot");
          System.out.println(ti);
          des = rs.getString("description");
          try{
            music =new FileInputStream(new File("C:\\Users\\Hp\\Documents\\NetBeansProjects\\SchedulingManager\\AlarmClock.wav"));
            audios=new AudioStream(music); 
            AudioPlayer.player.start(audios);
             } 
                 catch(Exception e){
                 System.out.println(e.getMessage());    
                 }
          JOptionPane.showMessageDialog(null, des);
                 }
        else{
        System.out.println("inside else");
        }
        sleep(1000);
        AudioPlayer.player.stop(audios);
         }
        
}catch(Exception e){
          System.out.println(e.getMessage());    
         } 
    }
 };
 t.setPriority(Thread.MAX_PRIORITY);
 t.start();
         }
    public static void main(String[] args) {
 ProgramTimmer pt = new ProgramTimmer();
 pt.checkTask();
    }
    
}
