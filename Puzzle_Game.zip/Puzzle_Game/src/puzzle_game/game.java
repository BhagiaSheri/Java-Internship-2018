package puzzle_game;
import java.awt.Image;
import java.util.ArrayList;
import java.util.Collections;
import javax.imageio.ImageIO;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import java.sql.*;
public class game extends javax.swing.JFrame {
     Connection conn;
     Statement st;
     ResultSet rs;
    int moves = 50;
    String replay;
    String output = "";
    int score;
    public game() {
        initComponents();
        setSize(895,731);
        Start_Page sp2 = new Start_Page();
        gamer_name.setText(sp2.name);
         try{
         Class.forName("oracle.jdbc.driver.OracleDriver");
            conn= DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","BHAGIA SHERI","123456789");
            if(conn!=null){
            System.out.println("Connection Succesfullly!");
            }
            }catch(Exception e){
        System.out.println(e.getMessage());
        }
       
     this.move.setText("  MOVES:  "+moves);
     setImages();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();
        jButton6 = new javax.swing.JButton();
        jButton7 = new javax.swing.JButton();
        jButton8 = new javax.swing.JButton();
        jButton9 = new javax.swing.JButton();
        exit = new javax.swing.JButton();
        hint = new javax.swing.JButton();
        gamer_name = new javax.swing.JTextField();
        move = new javax.swing.JTextField();
        reset = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("START THE GAME !");
        getContentPane().setLayout(null);

        jPanel1.setBackground(new java.awt.Color(102, 0, 102));
        jPanel1.setLayout(null);

        jButton1.setBackground(new java.awt.Color(102, 0, 102));
        jButton1.setFont(new java.awt.Font("Tahoma", 0, 1)); // NOI18N
        jButton1.setForeground(new java.awt.Color(102, 0, 102));
        jButton1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                jButton1MouseReleased(evt);
            }
        });
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton1);
        jButton1.setBounds(0, 0, 230, 230);

        jButton2.setBackground(new java.awt.Color(102, 0, 102));
        jButton2.setFont(new java.awt.Font("Tahoma", 0, 1)); // NOI18N
        jButton2.setForeground(new java.awt.Color(102, 0, 102));
        jButton2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                jButton2MouseReleased(evt);
            }
        });
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton2);
        jButton2.setBounds(230, 0, 230, 230);

        jButton3.setBackground(new java.awt.Color(102, 0, 102));
        jButton3.setFont(new java.awt.Font("Tahoma", 0, 1)); // NOI18N
        jButton3.setForeground(new java.awt.Color(102, 0, 102));
        jButton3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                jButton3MouseReleased(evt);
            }
        });
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton3);
        jButton3.setBounds(460, 0, 230, 230);

        jButton4.setBackground(new java.awt.Color(102, 0, 102));
        jButton4.setFont(new java.awt.Font("Tahoma", 0, 1)); // NOI18N
        jButton4.setForeground(new java.awt.Color(102, 0, 102));
        jButton4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                jButton4MouseReleased(evt);
            }
        });
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton4);
        jButton4.setBounds(0, 230, 230, 230);

        jButton5.setBackground(new java.awt.Color(102, 0, 102));
        jButton5.setFont(new java.awt.Font("Tahoma", 0, 1)); // NOI18N
        jButton5.setForeground(new java.awt.Color(102, 0, 102));
        jButton5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                jButton5MouseReleased(evt);
            }
        });
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton5);
        jButton5.setBounds(230, 230, 230, 230);

        jButton6.setBackground(new java.awt.Color(102, 0, 102));
        jButton6.setFont(new java.awt.Font("Tahoma", 0, 1)); // NOI18N
        jButton6.setForeground(new java.awt.Color(102, 0, 102));
        jButton6.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                jButton6MouseReleased(evt);
            }
        });
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton6);
        jButton6.setBounds(460, 230, 230, 230);

        jButton7.setBackground(new java.awt.Color(102, 0, 102));
        jButton7.setFont(new java.awt.Font("Tahoma", 0, 1)); // NOI18N
        jButton7.setForeground(new java.awt.Color(102, 0, 102));
        jButton7.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                jButton7MouseReleased(evt);
            }
        });
        jButton7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton7ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton7);
        jButton7.setBounds(0, 460, 230, 230);

        jButton8.setBackground(new java.awt.Color(102, 0, 102));
        jButton8.setFont(new java.awt.Font("Tahoma", 0, 1)); // NOI18N
        jButton8.setForeground(new java.awt.Color(102, 0, 102));
        jButton8.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                jButton8MouseReleased(evt);
            }
        });
        jButton8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton8ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton8);
        jButton8.setBounds(230, 460, 230, 230);

        jButton9.setBackground(new java.awt.Color(102, 0, 102));
        jButton9.setFont(new java.awt.Font("Tahoma", 0, 1)); // NOI18N
        jButton9.setForeground(new java.awt.Color(102, 0, 102));
        jButton9.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                jButton9MouseReleased(evt);
            }
        });
        jButton9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton9ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton9);
        jButton9.setBounds(460, 460, 230, 230);

        exit.setBackground(new java.awt.Color(255, 102, 153));
        exit.setFont(new java.awt.Font("Broadway", 3, 18)); // NOI18N
        exit.setForeground(new java.awt.Color(153, 0, 153));
        exit.setText("EXIT");
        exit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                exitActionPerformed(evt);
            }
        });
        jPanel1.add(exit);
        exit.setBounds(690, 630, 190, 60);

        hint.setBackground(new java.awt.Color(255, 102, 153));
        hint.setFont(new java.awt.Font("Broadway", 3, 18)); // NOI18N
        hint.setForeground(new java.awt.Color(153, 0, 153));
        hint.setText("HINT");
        hint.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                hintActionPerformed(evt);
            }
        });
        jPanel1.add(hint);
        hint.setBounds(690, 490, 190, 60);

        gamer_name.setEditable(false);
        gamer_name.setBackground(new java.awt.Color(255, 102, 153));
        gamer_name.setFont(new java.awt.Font("Broadway", 1, 18)); // NOI18N
        gamer_name.setForeground(new java.awt.Color(153, 0, 153));
        jPanel1.add(gamer_name);
        gamer_name.setBounds(690, 0, 190, 70);

        move.setEditable(false);
        move.setBackground(new java.awt.Color(255, 102, 153));
        move.setFont(new java.awt.Font("Broadway", 1, 18)); // NOI18N
        move.setForeground(new java.awt.Color(153, 0, 153));
        jPanel1.add(move);
        move.setBounds(690, 80, 190, 60);

        reset.setBackground(new java.awt.Color(255, 102, 153));
        reset.setFont(new java.awt.Font("Broadway", 3, 18)); // NOI18N
        reset.setForeground(new java.awt.Color(153, 0, 153));
        reset.setText("RESET");
        reset.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                resetActionPerformed(evt);
            }
        });
        jPanel1.add(reset);
        reset.setBounds(690, 560, 190, 60);

        getContentPane().add(jPanel1);
        jPanel1.setBounds(0, 0, 880, 690);

        setSize(new java.awt.Dimension(895, 730));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    
public void winCondition(){
if (jButton1.getText().equals("") && jButton2.getText().equals("2") && 
jButton3.getText().equals("3") && jButton4.getText().equals("4") && jButton5.getText().equals("5") &&
jButton6.getText().equals("6") && jButton7.getText().equals("7") &&
 jButton8.getText().equals("8") && jButton9.getText().equals("9") ) {
    score = moves*5;
    System.out.println("score: "+score);
    Start_Page sp1 = new  Start_Page();
    try{
            st = conn.createStatement();
            int rows= st.executeUpdate("update puzzle_game set score="+score+" WHERE name='"+sp1.name+"'");
            if(rows>0){
              System.out.println("DATA INSERTED !");  
            }
            else{
             System.out.println("DATA NOT INSERTED !");
            }
        }catch(Exception e){
           System.out.println(e.getMessage());
        }   
  output = "=======PUZZLE GAME====== \n CONGRATULATIONS !!! ***"+sp1.name+"***\n YOU WON THE PUZZLE GAME!!! \n  YOUR SCORE IS:"+score+"\n REMAINING MOVES ARE: "+moves; 
   JOptionPane.showMessageDialog(null,  output);
   
   replay=  JOptionPane.showInputDialog("DO YOU WANT TO REPLAY!.....(YES OR NO)");
   if(replay.equalsIgnoreCase("yes")){
   this.setVisible(false);
   new game().show();
   }
   else{
   System.exit(0);
   }
   }
    }
 
 public void lose(){
   if(moves==0){
    Start_Page sp1 = new  Start_Page();
    output = "====PUZZLE GAME==== \n "+sp1.name+", YOU LOOSE THE GAME !"; 
   JOptionPane.showMessageDialog(null,  output);
    replay=  JOptionPane.showInputDialog("DO YOU WANT TO TRY AGAIN!.....(YES OR NO)");
   if(replay.equalsIgnoreCase("yes")){
   this.setVisible(false);
   new game().show();
   }
   else{
   System.exit(0);
   }
   }
 }
    
    public void setImages(){
   ArrayList<Integer> list = new ArrayList<Integer>();
        for (int i=2; i<10; i++) {
            list.add(new Integer(i));
        }
      Collections.shuffle(list);
           
         try {   
    Image img = ImageIO.read(getClass().getResource(list.get(0)+".png"));
    jButton9.setIcon(new ImageIcon(img));
  
     img = ImageIO.read(getClass().getResource(list.get(1)+".png"));
    jButton2.setIcon(new ImageIcon(img));
       
     img = ImageIO.read(getClass().getResource(list.get(2)+".png"));
    jButton3.setIcon(new ImageIcon(img));
    
     img = ImageIO.read(getClass().getResource(list.get(3)+".png"));
    jButton4.setIcon(new ImageIcon(img));
     
     img = ImageIO.read(getClass().getResource(list.get(4)+".png"));
    jButton5.setIcon(new ImageIcon(img));
     
     img = ImageIO.read(getClass().getResource(list.get(5)+".png"));
    jButton6.setIcon(new ImageIcon(img));
     
     img = ImageIO.read(getClass().getResource(list.get(6)+".png"));
    jButton7.setIcon(new ImageIcon(img));
     
     img = ImageIO.read(getClass().getResource(list.get(7)+".png"));
    jButton8.setIcon(new ImageIcon(img));
    jButton1.setIcon(null);
    
    
    jButton1.setText("");
    jButton2.setText(list.get(1).toString());
    jButton3.setText(list.get(2).toString());
    jButton4.setText(list.get(3).toString());
    jButton5.setText(list.get(4).toString());
    jButton6.setText(list.get(5).toString());
    jButton7.setText(list.get(6).toString());
    jButton8.setText(list.get(7).toString());
    jButton9.setText(list.get(0).toString());
    
         } catch (Exception ex) {
    System.out.println(ex);
         }
  }

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here
       
        if(jButton2.getIcon() == null && jButton2.getText().equals("")){
            if(moves!=0){
                moves--;
         this.move.setText("  MOVES:  "+moves);
            Icon s1 = jButton1.getIcon();
            jButton2.setIcon(s1);
            jButton1.setIcon(null);
            
        String t1 = jButton1.getText();
        jButton2.setText(t1);
        jButton1.setText("");
        }
        }
        if(jButton4.getIcon()==null && jButton4.getText().equals("")){
             if(moves!=0){
                moves--;
         this.move.setText("  MOVES:  "+moves);
            Icon s2 = jButton1.getIcon();
            jButton4.setIcon(s2);
            jButton1.setIcon(null);
            
        String t2 = jButton1.getText();
        jButton4.setText(t2);
        jButton1.setText("");
        }
        }
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:
      
        if(jButton1.getIcon()==null  && jButton1.getText().equals("")){
             if(moves!=0){
                moves--;
            this.move.setText("  MOVES:  "+moves);
            Icon s2 = jButton2.getIcon();
            jButton1.setIcon(s2);
            jButton2.setIcon(null);
            String t2 = jButton2.getText();
            System.out.println(t2);
           jButton1.setText(t2);
           jButton2.setText("");
        }
        }
        if(jButton3.getIcon()==null && jButton3.getText().equals("")){
             if(moves!=0){
                moves--;
         this.move.setText("  MOVES:  "+moves);
            Icon s3= jButton2.getIcon();
            jButton3.setIcon(s3);
            jButton2.setIcon(null);
            
            String t3 = jButton2.getText();
        jButton3.setText(t3);
        jButton2.setText("");
             }
        }
        if(jButton5.getIcon()==null && jButton5.getText().equals("")){
             if(moves!=0){
                moves--;
         this.move.setText("  MOVES:  "+moves);
            Icon s5 = jButton2.getIcon();
            jButton5.setIcon(s5);
            jButton2.setIcon(null);
            
         String t5 = jButton2.getText();
        jButton5.setText(t5);
        jButton2.setText("");
        }
        }
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        // TODO add your handling code here:
          if(jButton2.getIcon()==null && jButton2.getText().equals("")){
               if(moves!=0){
                moves--;
         this.move.setText("  MOVES:  "+moves);
            Icon s3 = jButton3.getIcon();
            jButton2.setIcon(s3);
            jButton3.setIcon(null);
            
            String t3 = jButton3.getText();
           jButton2.setText(t3);
          jButton3.setText("");
               }
        }
        if(jButton6.getIcon()==null && jButton6 .getText().equals("")){
             if(moves!=0){
                moves--;
            this.move.setText("  MOVES:  "+moves);
            Icon s4 = jButton3.getIcon();
            jButton6.setIcon(s4);
            jButton3.setIcon(null);
            
        String t4 = jButton3.getText();
        jButton6.setText(t4);
        jButton3.setText("");
             }
        }
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed
        // TODO add your handling code here:
      
        if(jButton3.getIcon()==null && jButton3.getText().equals("")){
             if(moves!=0){
                moves--;
         this.move.setText("  MOVES:  "+moves);
            Icon s10 = jButton6.getIcon();
            jButton3.setIcon(s10);
            jButton6.setIcon(null);
            
         String t10 = jButton6.getText();
        jButton3.setText(t10);
        jButton6.setText("");
             }
        }
        if(jButton5.getIcon()==null && jButton5.getText().equals("")){
             if(moves!=0){
                moves--;
         this.move.setText("  MOVES:  "+moves);
            Icon s11 = jButton6.getIcon();
            jButton5.setIcon(s11);
            jButton6.setIcon(null);
            
         String t11 = jButton6.getText();
        jButton5.setText(t11);
        jButton6.setText("");
        }
        }
        if(jButton9.getIcon()==null && jButton9.getText().equals("")){
             if(moves!=0){
                moves--;
         this.move.setText("  MOVES:  "+moves);
            Icon s8 = jButton6.getIcon();
            jButton9.setIcon(s8);
            jButton6.setIcon(null);
            
            String t8 = jButton6.getText();
        jButton9.setText(t8);
        jButton6.setText("");
             }
        }
    }//GEN-LAST:event_jButton6ActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
        // TODO add your handling code here:
   
        if(jButton2.getIcon()==null && jButton2.getText().equals("")){
             if(moves!=0){
                moves--;
         this.move.setText("  MOVES:  "+moves);
           
            Icon s6 = jButton5.getIcon();
            jButton2.setIcon(s6);
            jButton5.setIcon(null);
            
            String t6 = jButton5.getText();
        jButton2.setText(t6);
        jButton5.setText("");
             }
        }
        if(jButton4.getIcon()==null && jButton4.getText().equals("")){
             if(moves!=0){
                moves--;
         this.move.setText("  MOVES:  "+moves);
            Icon s7 = jButton5.getIcon();
            jButton4.setIcon(s7);
            jButton5.setIcon(null);
            
            String t7 = jButton5.getText();
        jButton4.setText(t7);
        jButton5.setText("");
        }
        }
        if(jButton6.getIcon()==null && jButton6.getText().equals("")){
             if(moves!=0){
                moves--;
         this.move.setText("  MOVES:  "+moves);
            Icon s8 = jButton5.getIcon();
            jButton6.setIcon(s8);
            jButton5.setIcon(null);
            
            String t8 = jButton5.getText();
        jButton6.setText(t8);
        jButton5.setText("");
        }
        }
        if(jButton8.getIcon()==null && jButton8.getText().equals("")){
             if(moves!=0){
                moves--;
         this.move.setText("  MOVES:  "+moves);
            Icon s9 = jButton5.getIcon();
            jButton8.setIcon(s9);
            jButton5.setIcon(null);
            
            String t9 = jButton5.getText();
        jButton8.setText(t9);
        jButton5.setText("");
             }
        }
    }//GEN-LAST:event_jButton5ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        // TODO add your handling code here:
       
        if(jButton1.getIcon()==null && jButton1.getText().equals("")){
             if(moves!=0){
                moves--;
         this.move.setText("  MOVES:  "+moves);
            Icon s = jButton4.getIcon();
            jButton1.setIcon(s);
            jButton4.setIcon(null);
            
          String t = jButton4.getText();
        jButton1.setText(t);
        jButton4.setText("");
        }
        }
        if(jButton7.getIcon()==null && jButton7.getText().equals("")){
             if(moves!=0){
                moves--;
         this.move.setText("  MOVES:  "+moves);
            Icon s5 = jButton4.getIcon();
            jButton7.setIcon(s5);
            jButton4.setIcon(null);
            
            String t5 = jButton4.getText();
        jButton7.setText(t5);
        jButton4.setText("");
        }
        }
        if(jButton5.getIcon()==null && jButton5.getText().equals("")){
             if(moves!=0){
                moves--;
         this.move.setText("  MOVES:  "+moves);
            Icon s4 = jButton4.getIcon();
            jButton5.setIcon(s4);
            jButton4.setIcon(null);
            
            String t4 = jButton4.getText();
        jButton5.setText(t4);
        jButton4.setText("");
        }
        }
    }//GEN-LAST:event_jButton4ActionPerformed

    private void jButton7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton7ActionPerformed
        // TODO add your handling code here:
       
        if(jButton4.getIcon()==null && jButton4.getText().equals("")){
             if(moves!=0){
                moves--;
         this.move.setText("  MOVES:  "+moves);
            Icon s9 = jButton7.getIcon();
            jButton4.setIcon(s9);
            jButton7.setIcon(null);
            
            String t9 = jButton7.getText();
        jButton4.setText(t9);
        jButton7.setText("");
        }
        }
        if(jButton8.getIcon()==null && jButton8.getText().equals("")){
             if(moves!=0){
                moves--;
         this.move.setText("  MOVES:  "+moves);
            Icon s10 = jButton7.getIcon();
            jButton8.setIcon(s10);
            jButton7.setIcon(null);
            
            String t10 = jButton7.getText();
        jButton8.setText(t10);
        jButton7.setText("");
             }
        }
    }//GEN-LAST:event_jButton7ActionPerformed

    private void jButton8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton8ActionPerformed
        // TODO add your handling code here:
    
        if(jButton5.getIcon()==null && jButton5.getText().equals("")){
             if(moves!=0){
                moves--;
         this.move.setText("  MOVES:  "+moves);
            Icon s11 = jButton8.getIcon();
            jButton5.setIcon(s11);
            jButton8.setIcon(null);
            
            String t11= jButton8.getText();
        jButton5.setText(t11);
        jButton8.setText("");
        }
        }
        if(jButton7.getIcon()==null && jButton7.getText().equals("")){
             if(moves!=0){
                moves--;
         this.move.setText("  MOVES:  "+moves);
            Icon s12 = jButton8.getIcon();
            jButton7.setIcon(s12);
            jButton8.setIcon(null);
            
            String t12 = jButton8.getText();
        jButton7.setText(t12);
        jButton8.setText("");
        }
        }
        if(jButton9.getIcon()==null && jButton9.getText().equals("")){
             if(moves!=0){
                moves--;
         this.move.setText("  MOVES:  "+moves);
            Icon s13 = jButton8.getIcon();
            jButton9.setIcon(s13);
            jButton8.setIcon(null);
            
            String t13 = jButton8.getText();
        jButton9.setText(t13);
        jButton8.setText("");
        }
        }
    }//GEN-LAST:event_jButton8ActionPerformed

    private void jButton9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton9ActionPerformed
        // TODO add your handling code here:
       if(jButton6.getIcon()==null && jButton6.getText().equals("")){
            if(moves!=0){
                moves--;
         this.move.setText("  MOVES:  "+moves);
            Icon s6 = jButton9.getIcon();
            jButton6.setIcon(s6);
            jButton9.setIcon(null);
            
            String t6 = jButton9.getText();
        jButton6.setText(t6);
        jButton9.setText("");
        }
       }
        if(jButton8.getIcon()==null && jButton8.getText().equals("")){
             if(moves!=0){
                moves--;
         this.move.setText("  MOVES:  "+moves);
            Icon s7 = jButton9.getIcon();
            jButton8.setIcon(s7);
            jButton9.setIcon(null);
            
        String t7 = jButton9.getText();
        jButton8.setText(t7);
        jButton9.setText("");
             }
        }
    }//GEN-LAST:event_jButton9ActionPerformed

    private void exitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_exitActionPerformed
        System.exit(0);
    }//GEN-LAST:event_exitActionPerformed

    private void hintActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_hintActionPerformed
       new picture().show();
    }//GEN-LAST:event_hintActionPerformed

    private void jButton1MouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton1MouseReleased
       winCondition();  
             lose();
    }//GEN-LAST:event_jButton1MouseReleased

    private void jButton2MouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton2MouseReleased
      
          winCondition();  
               lose();
    }//GEN-LAST:event_jButton2MouseReleased

    private void jButton3MouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton3MouseReleased
          winCondition();  
                lose();
    }//GEN-LAST:event_jButton3MouseReleased

    private void jButton4MouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton4MouseReleased
          winCondition();  
                lose();
    }//GEN-LAST:event_jButton4MouseReleased

    private void jButton5MouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton5MouseReleased
          winCondition();  
                lose();
    }//GEN-LAST:event_jButton5MouseReleased

    private void jButton6MouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton6MouseReleased
         winCondition();  
               lose();
    }//GEN-LAST:event_jButton6MouseReleased

    private void jButton7MouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton7MouseReleased
         winCondition(); 
       lose();
    }//GEN-LAST:event_jButton7MouseReleased

    private void jButton8MouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton8MouseReleased
          winCondition();  
        if(moves==0){
    Start_Page sp1 = new  Start_Page();
    output = "====PUZZLE GAME==== \n "+sp1.name+" \n  "+" YOU LOOSE THE GAME !!!!!  \n  TRY AGAIN !!!"; 
   JOptionPane.showMessageDialog(null,  output);
   }
    }//GEN-LAST:event_jButton8MouseReleased

    private void jButton9MouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton9MouseReleased
         winCondition();  
         lose();
    }//GEN-LAST:event_jButton9MouseReleased

    private void resetActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_resetActionPerformed
      this.setVisible(false);
      new game().show();
    }//GEN-LAST:event_resetActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(game.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(game.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(game.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(game.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new game().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton exit;
    public javax.swing.JTextField gamer_name;
    private javax.swing.JButton hint;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JButton jButton7;
    private javax.swing.JButton jButton8;
    private javax.swing.JButton jButton9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JTextField move;
    private javax.swing.JButton reset;
    // End of variables declaration//GEN-END:variables
}
