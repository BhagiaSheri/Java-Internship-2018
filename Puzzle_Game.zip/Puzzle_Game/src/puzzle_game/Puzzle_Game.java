package puzzle_game;
public class Puzzle_Game {
public static void main(String[] args) {
Game_SplashScreen gs=  new Game_SplashScreen();
 gs.setVisible(true);
 try{
 for(int loading =0;loading<=100; loading++){
  Thread.sleep(45);
  gs.load1.setText(Integer.toString(loading)+"%");
  gs.jProgressBar1.setValue(loading);
  if(loading==100){
  gs.setVisible(false);
  new Start_Page().show();
  }
  }
  }catch(Exception ex){
System.out.println(ex.getMessage());
 }
    }
    
}
