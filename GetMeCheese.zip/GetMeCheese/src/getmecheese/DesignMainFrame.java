package getmecheese;
import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.event.*;
import java.awt.event.KeyListener;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import static java.lang.Thread.sleep;
import java.util.*;
import javax.swing.JOptionPane;
import javax.swing.*;
import sun.audio.AudioPlayer;
import sun.audio.AudioStream;
/**
 *
 * @author Hp
 */
public class DesignMainFrame extends javax.swing.JFrame implements KeyListener { 
     InputStream music, sound; 
    AudioStream audios, audio;  
    static int min=00;
      static int sec=00;
       static int milisec=00;
       static boolean status = true;
        boolean moveStatus;
         static int score=0;
        String input;
        int confirm;
       int range =10;
       int x, y;
         ArrayList<JPanel> p;
         ArrayList<JLabel> l;
          Rectangle p_rect;
          Rectangle m_rect;
          Rectangle l_rect;
          Rectangle c_rect;
    /**
     * Creates new form DesignMainFrame
     */
    public DesignMainFrame() {
        initComponents();
        this.addKeyListener(this);
       this.setFocusable(true);
        this.setFocusTraversalKeysEnabled(false);
        timeLimit();
        mazeSound();
       l= new ArrayList<JLabel>();
      l.add(l2);l.add(l1);l.add(l3);l.add(l4);l.add(l5);l.add(l6);
      l.add(l7);l.add(l8);l.add(l9);l.add(l10);l.add(l11);l.add(l12);
      l.add(l13);l.add(l14);l.add(l15);l.add(l16);l.add(l17);l.add(l18);
       l.add(l19);l.add(l20);l.add(l21);l.add(l22);l.add(l23);l.add(l24);
       l.add(l25);l.add(l26);l.add(l27);l.add(l28);
        
       p = new ArrayList<JPanel>();
         p.add(p1); p.add(p2);p.add(p3);p.add(p4);p.add(p5);p.add(p6);
         p.add(p7);p.add(p8);p.add(p9);p.add(p10);p.add(p11);p.add(p12);
         p.add(p13);p.add(p14);p.add(p15);p.add(p16);p.add(p17);p.add(p18);
         p.add(p19); p.add(p20);p.add(p21);p.add(p22);p.add(p23);p.add(p24);
         p.add(p25);p.add(p26);p.add(p27);p.add(p28);p.add(p29);p.add(p30);
         p.add(p31);p.add(p32);p.add(p33);p.add(p34);p.add(p35);p.add(p36);
         p.add(p37); p.add(p38);p.add(p39);p.add(p40);p.add(p41);p.add(p42);
         p.add(p43);p.add(p44);p.add(p45);p.add(p46);p.add(p47);p.add(p48);
         p.add(p49);p.add(p50);p.add(p51);p.add(p52);p.add(p53);p.add(p54);
         p.add(p55); p.add(p56);p.add(p57);p.add(p58);p.add(p59);p.add(p60);
         p.add(p61);p.add(p62);p.add(p63);p.add(p64);p.add(p65);p.add(p66);
         p.add(p67);p.add(p68);p.add(p69);p.add(p70);p.add(p71);p.add(p72);
         p.add(p73); p.add(p74);p.add(p75);p.add(p76);p.add(p77);p.add(p78);
         p.add(p79);p.add(p80);p.add(p81);p.add(p82);p.add(p83);p.add(p84);
         p.add(p85);p.add(p86);p.add(p87);p.add(p89);p.add(p91);p.add(p92);
         p.add(p93); p.add(p94);p.add(p95);p.add(p96);p.add(p97);p.add(p98);
         p.add(p99);p.add(p100);p.add(p101);p.add(p102);p.add(p103);p.add(p104);
         p.add(p105);p.add(p106);p.add(p107);p.add(p108);p.add(p109);p.add(p90);
         p.add(p110);p.add(p111);p.add(p112);
         
     
              }
   
    public void bonusCondition(){
    for(int i =0 ; i<l.size(); i++){
        l_rect = new Rectangle(l.get(i).getX(), l.get(i).getY()+range-10, l.get(i).getWidth(), l.get(i).getHeight()); 
       m_rect = new Rectangle(mouselabel.getX(), mouselabel.getY(), mouselabel.getWidth(), mouselabel.getHeight());  
       if(m_rect.intersects(l_rect)){
       l.get(i).setVisible(false);
       l.remove(i);
       getBonusSound();
       score+=5;
     scoretxt.setText("SCORE:  "+score);
      }
    }
    }
     
    public void loseCondition(){
     // System.out.println("lose function called !");
    if(min==1 && sec==0){
       System.out.println("inside if !");
       c_rect = new Rectangle(cheeselabel.getX(), cheeselabel.getY(), cheeselabel.getWidth(), cheeselabel.getHeight()); 
       m_rect = new Rectangle(mouselabel.getX(), mouselabel.getY(), mouselabel.getWidth(), mouselabel.getHeight());  
       if((m_rect.intersects(c_rect))){
       // JOptionPane.showMessageDialog(null, "YOU WIN THE GAME !");
       }else{
      status=false;
     input =  JOptionPane.showInputDialog(null, "YOU LOSE THE GAME\n===== TIMES UP !======\n\nDO YOU WANT TO TRY AGAIN...(YES OR NO)");
     if(input.equalsIgnoreCase("yes")){
       min=0;
       sec=0;
       milisec=0;
      this.setVisible(false);
      status=true;
      new DesignMainFrame().show();
     }
      if(input.equalsIgnoreCase("no")){ 
        System.exit(0);
        }
     }   
    }
 }

public void alertSound(){
 try{
music =new FileInputStream(new File("C:\\Users\\Hp\\Documents\\NetBeansProjects\\GetMeCheese\\alertsound.wav"));
 audios=new AudioStream(music); 
AudioPlayer.player.start(audios);
sleep(200);
AudioPlayer.player.stop(audios);
} 
catch(Exception e){
System.out.println(e.getMessage());
}
    }

public void mazeSound(){
 try{
sound =new FileInputStream(new File("C:\\Users\\Hp\\Documents\\NetBeansProjects\\GetMeCheese\\gameSound.wav"));
 audio=new AudioStream(sound); 
AudioPlayer.player.start(audio);
} 
catch(Exception e){
System.out.println(e.getMessage());
}
    }

public void getBonusSound(){
 try{
music =new FileInputStream(new File("C:\\Users\\Hp\\Documents\\NetBeansProjects\\GetMeCheese\\getbonus.wav"));
 audios=new AudioStream(music);
AudioPlayer.player.start(audios);
sleep(400);
AudioPlayer.player.stop(audios);
} 
catch(Exception e){
System.out.println(e.getMessage());
}
    }

public void winningSound(){
 try{
music =new FileInputStream(new File("C:\\Users\\Hp\\Documents\\NetBeansProjects\\GetMeCheese\\winningsound.wav"));
 audios=new AudioStream(music);
AudioPlayer.player.start(audios);
sleep(2000);
AudioPlayer.player.stop(audios);
} 
catch(Exception e){
System.out.println(e.getMessage());
}
    }
    
    
    public void winCondition(){
     // System.out.println("win function called !");
    
       c_rect = new Rectangle(cheeselabel.getX(), cheeselabel.getY(), cheeselabel.getWidth(), cheeselabel.getHeight()); 
       m_rect = new Rectangle(mouselabel.getX(), mouselabel.getY(), mouselabel.getWidth(), mouselabel.getHeight());  
              
       if((m_rect.intersects(c_rect))){
          // System.out.println("inside another if !");
            score+=20;
            scoretxt.setText("BOUNCES:  "+score);
           cheeselabel.setVisible(false);
           winningSound();
           status=false;
           String wtime = mint.getText()+""+secs.getText()+""+milisecs.getText()+" ms";
          JOptionPane.showMessageDialog(null, "YOU WIN THE GAME\n YOUR  "+scoretxt.getText()+"\n YOU TAKE TIME IS: "+wtime);
          min = 0;
          sec =0;
          milisec =0;
          this.setVisible(false);
          new MazeStartFrame().show();
       }
       
    
    }
    
       public void timeLimit(){
          System.out.println("timeLimit functionCalled!");
         status = true;
        Thread t = new Thread(){
        public void run(){
           for( ; ; ){
           if(status==true){    
           try{
           sleep(1);
           if(milisec>1000){
           milisec=00;
           sec++;
           }
            if(sec>60){
           milisec=00;
           sec=00;
           min++;
           }
           milisecs.setText(": "+milisec);
           milisec++;
           secs.setText(": "+sec);
           mint.setText("0"+min); 
           }catch(Exception ex){
           System.out.println(ex.getMessage());
           }
           loseCondition();
           winCondition();
           }
            
           else{
                   break;
           }
           }
           }
        };
        t.start();
    
    }
    public void restartCondition(){
    System.out.println("Restart Method is Called !");
    this.setVisible(false);
    min=0;
    sec = 0;
    milisec = 0;
    new DesignMainFrame().show();
    }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        backgroundPanel = new javax.swing.JPanel();
        gamePanel = new javax.swing.JPanel();
        p1 = new javax.swing.JPanel();
        p2 = new javax.swing.JPanel();
        jPanel80 = new javax.swing.JPanel();
        jPanel81 = new javax.swing.JPanel();
        p3 = new javax.swing.JPanel();
        p4 = new javax.swing.JPanel();
        p5 = new javax.swing.JPanel();
        p6 = new javax.swing.JPanel();
        p7 = new javax.swing.JPanel();
        p8 = new javax.swing.JPanel();
        p9 = new javax.swing.JPanel();
        p10 = new javax.swing.JPanel();
        p11 = new javax.swing.JPanel();
        p12 = new javax.swing.JPanel();
        p13 = new javax.swing.JPanel();
        p14 = new javax.swing.JPanel();
        p15 = new javax.swing.JPanel();
        p16 = new javax.swing.JPanel();
        p17 = new javax.swing.JPanel();
        p18 = new javax.swing.JPanel();
        p19 = new javax.swing.JPanel();
        p20 = new javax.swing.JPanel();
        p21 = new javax.swing.JPanel();
        p22 = new javax.swing.JPanel();
        p23 = new javax.swing.JPanel();
        p24 = new javax.swing.JPanel();
        p25 = new javax.swing.JPanel();
        p26 = new javax.swing.JPanel();
        p27 = new javax.swing.JPanel();
        p28 = new javax.swing.JPanel();
        p29 = new javax.swing.JPanel();
        p30 = new javax.swing.JPanel();
        p31 = new javax.swing.JPanel();
        p32 = new javax.swing.JPanel();
        p33 = new javax.swing.JPanel();
        p34 = new javax.swing.JPanel();
        p35 = new javax.swing.JPanel();
        p36 = new javax.swing.JPanel();
        p37 = new javax.swing.JPanel();
        p38 = new javax.swing.JPanel();
        p39 = new javax.swing.JPanel();
        p40 = new javax.swing.JPanel();
        p41 = new javax.swing.JPanel();
        p42 = new javax.swing.JPanel();
        p43 = new javax.swing.JPanel();
        p44 = new javax.swing.JPanel();
        p45 = new javax.swing.JPanel();
        p46 = new javax.swing.JPanel();
        p49 = new javax.swing.JPanel();
        p50 = new javax.swing.JPanel();
        p47 = new javax.swing.JPanel();
        p48 = new javax.swing.JPanel();
        p51 = new javax.swing.JPanel();
        p52 = new javax.swing.JPanel();
        p53 = new javax.swing.JPanel();
        p54 = new javax.swing.JPanel();
        p55 = new javax.swing.JPanel();
        p56 = new javax.swing.JPanel();
        p57 = new javax.swing.JPanel();
        p58 = new javax.swing.JPanel();
        p59 = new javax.swing.JPanel();
        p60 = new javax.swing.JPanel();
        p61 = new javax.swing.JPanel();
        p62 = new javax.swing.JPanel();
        p63 = new javax.swing.JPanel();
        p64 = new javax.swing.JPanel();
        p65 = new javax.swing.JPanel();
        p66 = new javax.swing.JPanel();
        p67 = new javax.swing.JPanel();
        p68 = new javax.swing.JPanel();
        p69 = new javax.swing.JPanel();
        p70 = new javax.swing.JPanel();
        p71 = new javax.swing.JPanel();
        p72 = new javax.swing.JPanel();
        p73 = new javax.swing.JPanel();
        p74 = new javax.swing.JPanel();
        p75 = new javax.swing.JPanel();
        p76 = new javax.swing.JPanel();
        p77 = new javax.swing.JPanel();
        p78 = new javax.swing.JPanel();
        p79 = new javax.swing.JPanel();
        p80 = new javax.swing.JPanel();
        p81 = new javax.swing.JPanel();
        p82 = new javax.swing.JPanel();
        p83 = new javax.swing.JPanel();
        p84 = new javax.swing.JPanel();
        p85 = new javax.swing.JPanel();
        p86 = new javax.swing.JPanel();
        p87 = new javax.swing.JPanel();
        p89 = new javax.swing.JPanel();
        p90 = new javax.swing.JPanel();
        p91 = new javax.swing.JPanel();
        p92 = new javax.swing.JPanel();
        p93 = new javax.swing.JPanel();
        p94 = new javax.swing.JPanel();
        p95 = new javax.swing.JPanel();
        p96 = new javax.swing.JPanel();
        p97 = new javax.swing.JPanel();
        p98 = new javax.swing.JPanel();
        p99 = new javax.swing.JPanel();
        p100 = new javax.swing.JPanel();
        p101 = new javax.swing.JPanel();
        p102 = new javax.swing.JPanel();
        p103 = new javax.swing.JPanel();
        p104 = new javax.swing.JPanel();
        p105 = new javax.swing.JPanel();
        p106 = new javax.swing.JPanel();
        p107 = new javax.swing.JPanel();
        p108 = new javax.swing.JPanel();
        p109 = new javax.swing.JPanel();
        p110 = new javax.swing.JPanel();
        p111 = new javax.swing.JPanel();
        p112 = new javax.swing.JPanel();
        mouselabel = new javax.swing.JLabel();
        l2 = new javax.swing.JLabel();
        l1 = new javax.swing.JLabel();
        cheeselabel = new javax.swing.JLabel();
        l3 = new javax.swing.JLabel();
        l4 = new javax.swing.JLabel();
        l5 = new javax.swing.JLabel();
        l6 = new javax.swing.JLabel();
        l7 = new javax.swing.JLabel();
        l8 = new javax.swing.JLabel();
        l9 = new javax.swing.JLabel();
        l10 = new javax.swing.JLabel();
        l11 = new javax.swing.JLabel();
        l12 = new javax.swing.JLabel();
        l13 = new javax.swing.JLabel();
        l14 = new javax.swing.JLabel();
        l15 = new javax.swing.JLabel();
        l16 = new javax.swing.JLabel();
        l17 = new javax.swing.JLabel();
        l18 = new javax.swing.JLabel();
        l19 = new javax.swing.JLabel();
        l20 = new javax.swing.JLabel();
        l21 = new javax.swing.JLabel();
        l22 = new javax.swing.JLabel();
        l23 = new javax.swing.JLabel();
        l24 = new javax.swing.JLabel();
        l25 = new javax.swing.JLabel();
        l26 = new javax.swing.JLabel();
        l27 = new javax.swing.JLabel();
        l28 = new javax.swing.JLabel();
        timerPanel = new javax.swing.JPanel();
        secs = new javax.swing.JLabel();
        milisecs = new javax.swing.JLabel();
        mint = new javax.swing.JLabel();
        mslabel = new javax.swing.JLabel();
        mintlabel = new javax.swing.JLabel();
        secslabel = new javax.swing.JLabel();
        pausebtn = new javax.swing.JButton();
        scoretxt = new javax.swing.JTextField();
        exitbuttton = new javax.swing.JButton();
        restrartbtn = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        hintbtn = new javax.swing.JButton();
        backbtn = new javax.swing.JButton();
        stop = new javax.swing.JButton();
        play = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(null);

        backgroundPanel.setBackground(new java.awt.Color(153, 153, 0));
        backgroundPanel.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 5));
        backgroundPanel.setLayout(null);

        gamePanel.setBackground(new java.awt.Color(204, 204, 255));
        gamePanel.setLayout(null);

        p1.setBackground(new java.awt.Color(0, 51, 51));
        p1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 51, 51)));

        javax.swing.GroupLayout p1Layout = new javax.swing.GroupLayout(p1);
        p1.setLayout(p1Layout);
        p1Layout.setHorizontalGroup(
            p1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 18, Short.MAX_VALUE)
        );
        p1Layout.setVerticalGroup(
            p1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 458, Short.MAX_VALUE)
        );

        gamePanel.add(p1);
        p1.setBounds(720, 20, 20, 460);

        p2.setBackground(new java.awt.Color(0, 51, 51));
        p2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 51, 51)));

        jPanel80.setBackground(new java.awt.Color(0, 0, 0));
        jPanel80.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        javax.swing.GroupLayout jPanel80Layout = new javax.swing.GroupLayout(jPanel80);
        jPanel80.setLayout(jPanel80Layout);
        jPanel80Layout.setHorizontalGroup(
            jPanel80Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 8, Short.MAX_VALUE)
        );
        jPanel80Layout.setVerticalGroup(
            jPanel80Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 38, Short.MAX_VALUE)
        );

        jPanel81.setBackground(new java.awt.Color(0, 0, 0));
        jPanel81.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        javax.swing.GroupLayout jPanel81Layout = new javax.swing.GroupLayout(jPanel81);
        jPanel81.setLayout(jPanel81Layout);
        jPanel81Layout.setHorizontalGroup(
            jPanel81Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 108, Short.MAX_VALUE)
        );
        jPanel81Layout.setVerticalGroup(
            jPanel81Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 8, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout p2Layout = new javax.swing.GroupLayout(p2);
        p2.setLayout(p2Layout);
        p2Layout.setHorizontalGroup(
            p2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 120, Short.MAX_VALUE)
            .addGroup(p2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(p2Layout.createSequentialGroup()
                    .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(p2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(jPanel80, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jPanel81, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGap(0, 0, Short.MAX_VALUE)))
        );
        p2Layout.setVerticalGroup(
            p2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 50, Short.MAX_VALUE)
            .addGroup(p2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(p2Layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(jPanel80, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, 0)
                    .addComponent(jPanel81, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );

        gamePanel.add(p2);
        p2.setBounds(140, 90, 90, 10);

        p3.setBackground(new java.awt.Color(0, 51, 51));
        p3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 51, 51)));

        javax.swing.GroupLayout p3Layout = new javax.swing.GroupLayout(p3);
        p3.setLayout(p3Layout);
        p3Layout.setHorizontalGroup(
            p3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 18, Short.MAX_VALUE)
        );
        p3Layout.setVerticalGroup(
            p3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 118, Short.MAX_VALUE)
        );

        gamePanel.add(p3);
        p3.setBounds(720, 510, 20, 120);

        p4.setBackground(new java.awt.Color(0, 51, 51));
        p4.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 51, 51)));

        javax.swing.GroupLayout p4Layout = new javax.swing.GroupLayout(p4);
        p4.setLayout(p4Layout);
        p4Layout.setHorizontalGroup(
            p4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 18, Short.MAX_VALUE)
        );
        p4Layout.setVerticalGroup(
            p4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 548, Short.MAX_VALUE)
        );

        gamePanel.add(p4);
        p4.setBounds(0, 90, 20, 550);

        p5.setBackground(new java.awt.Color(0, 51, 51));
        p5.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 51, 51)));

        javax.swing.GroupLayout p5Layout = new javax.swing.GroupLayout(p5);
        p5.setLayout(p5Layout);
        p5Layout.setHorizontalGroup(
            p5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 8, Short.MAX_VALUE)
        );
        p5Layout.setVerticalGroup(
            p5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 78, Short.MAX_VALUE)
        );

        gamePanel.add(p5);
        p5.setBounds(290, 20, 10, 80);

        p6.setBackground(new java.awt.Color(0, 51, 51));
        p6.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 51, 51)));

        javax.swing.GroupLayout p6Layout = new javax.swing.GroupLayout(p6);
        p6.setLayout(p6Layout);
        p6Layout.setHorizontalGroup(
            p6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 738, Short.MAX_VALUE)
        );
        p6Layout.setVerticalGroup(
            p6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 18, Short.MAX_VALUE)
        );

        gamePanel.add(p6);
        p6.setBounds(0, 620, 740, 20);

        p7.setBackground(new java.awt.Color(0, 51, 51));
        p7.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 51, 51)));

        javax.swing.GroupLayout p7Layout = new javax.swing.GroupLayout(p7);
        p7.setLayout(p7Layout);
        p7Layout.setHorizontalGroup(
            p7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 18, Short.MAX_VALUE)
        );
        p7Layout.setVerticalGroup(
            p7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 38, Short.MAX_VALUE)
        );

        gamePanel.add(p7);
        p7.setBounds(0, 20, 20, 40);

        p8.setBackground(new java.awt.Color(0, 51, 51));
        p8.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 51, 51)));

        javax.swing.GroupLayout p8Layout = new javax.swing.GroupLayout(p8);
        p8.setLayout(p8Layout);
        p8Layout.setHorizontalGroup(
            p8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 738, Short.MAX_VALUE)
        );
        p8Layout.setVerticalGroup(
            p8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 18, Short.MAX_VALUE)
        );

        gamePanel.add(p8);
        p8.setBounds(0, 0, 740, 20);

        p9.setBackground(new java.awt.Color(0, 51, 51));
        p9.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 51, 51)));

        javax.swing.GroupLayout p9Layout = new javax.swing.GroupLayout(p9);
        p9.setLayout(p9Layout);
        p9Layout.setHorizontalGroup(
            p9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 8, Short.MAX_VALUE)
        );
        p9Layout.setVerticalGroup(
            p9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 78, Short.MAX_VALUE)
        );

        gamePanel.add(p9);
        p9.setBounds(60, 20, 10, 80);

        p10.setBackground(new java.awt.Color(0, 51, 51));
        p10.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 51, 51)));

        javax.swing.GroupLayout p10Layout = new javax.swing.GroupLayout(p10);
        p10.setLayout(p10Layout);
        p10Layout.setHorizontalGroup(
            p10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 98, Short.MAX_VALUE)
        );
        p10Layout.setVerticalGroup(
            p10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 8, Short.MAX_VALUE)
        );

        gamePanel.add(p10);
        p10.setBounds(340, 90, 100, 10);

        p11.setBackground(new java.awt.Color(0, 51, 51));
        p11.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 51, 51)));

        javax.swing.GroupLayout p11Layout = new javax.swing.GroupLayout(p11);
        p11.setLayout(p11Layout);
        p11Layout.setHorizontalGroup(
            p11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 38, Short.MAX_VALUE)
        );
        p11Layout.setVerticalGroup(
            p11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 8, Short.MAX_VALUE)
        );

        gamePanel.add(p11);
        p11.setBounds(100, 50, 40, 10);

        p12.setBackground(new java.awt.Color(0, 51, 51));
        p12.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 51, 51)));

        javax.swing.GroupLayout p12Layout = new javax.swing.GroupLayout(p12);
        p12.setLayout(p12Layout);
        p12Layout.setHorizontalGroup(
            p12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 108, Short.MAX_VALUE)
        );
        p12Layout.setVerticalGroup(
            p12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 8, Short.MAX_VALUE)
        );

        gamePanel.add(p12);
        p12.setBounds(180, 50, 110, 10);

        p13.setBackground(new java.awt.Color(0, 51, 51));
        p13.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 51, 51)));

        javax.swing.GroupLayout p13Layout = new javax.swing.GroupLayout(p13);
        p13.setLayout(p13Layout);
        p13Layout.setHorizontalGroup(
            p13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 8, Short.MAX_VALUE)
        );
        p13Layout.setVerticalGroup(
            p13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 38, Short.MAX_VALUE)
        );

        gamePanel.add(p13);
        p13.setBounds(230, 90, 10, 40);

        p14.setBackground(new java.awt.Color(0, 51, 51));
        p14.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 51, 51)));

        javax.swing.GroupLayout p14Layout = new javax.swing.GroupLayout(p14);
        p14.setLayout(p14Layout);
        p14Layout.setHorizontalGroup(
            p14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 8, Short.MAX_VALUE)
        );
        p14Layout.setVerticalGroup(
            p14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 48, Short.MAX_VALUE)
        );

        gamePanel.add(p14);
        p14.setBounds(340, 50, 10, 50);

        p15.setBackground(new java.awt.Color(0, 51, 51));
        p15.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 51, 51)));

        javax.swing.GroupLayout p15Layout = new javax.swing.GroupLayout(p15);
        p15.setLayout(p15Layout);
        p15Layout.setHorizontalGroup(
            p15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 8, Short.MAX_VALUE)
        );
        p15Layout.setVerticalGroup(
            p15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 88, Short.MAX_VALUE)
        );

        gamePanel.add(p15);
        p15.setBounds(130, 50, 10, 90);

        p16.setBackground(new java.awt.Color(0, 51, 51));
        p16.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 51, 51)));

        javax.swing.GroupLayout p16Layout = new javax.swing.GroupLayout(p16);
        p16.setLayout(p16Layout);
        p16Layout.setHorizontalGroup(
            p16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 108, Short.MAX_VALUE)
        );
        p16Layout.setVerticalGroup(
            p16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 8, Short.MAX_VALUE)
        );

        gamePanel.add(p16);
        p16.setBounds(230, 130, 110, 10);

        p17.setBackground(new java.awt.Color(0, 51, 51));
        p17.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 51, 51)));

        javax.swing.GroupLayout p17Layout = new javax.swing.GroupLayout(p17);
        p17.setLayout(p17Layout);
        p17Layout.setHorizontalGroup(
            p17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 8, Short.MAX_VALUE)
        );
        p17Layout.setVerticalGroup(
            p17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 98, Short.MAX_VALUE)
        );

        gamePanel.add(p17);
        p17.setBounds(630, 170, 10, 100);

        p18.setBackground(new java.awt.Color(0, 51, 51));
        p18.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 51, 51)));

        javax.swing.GroupLayout p18Layout = new javax.swing.GroupLayout(p18);
        p18.setLayout(p18Layout);
        p18Layout.setHorizontalGroup(
            p18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 8, Short.MAX_VALUE)
        );
        p18Layout.setVerticalGroup(
            p18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 118, Short.MAX_VALUE)
        );

        gamePanel.add(p18);
        p18.setBounds(390, 20, 10, 120);

        p19.setBackground(new java.awt.Color(0, 51, 51));
        p19.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 51, 51)));

        javax.swing.GroupLayout p19Layout = new javax.swing.GroupLayout(p19);
        p19.setLayout(p19Layout);
        p19Layout.setHorizontalGroup(
            p19Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 68, Short.MAX_VALUE)
        );
        p19Layout.setVerticalGroup(
            p19Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 8, Short.MAX_VALUE)
        );

        gamePanel.add(p19);
        p19.setBounds(550, 90, 70, 10);

        p20.setBackground(new java.awt.Color(0, 51, 51));
        p20.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 51, 51)));

        javax.swing.GroupLayout p20Layout = new javax.swing.GroupLayout(p20);
        p20.setLayout(p20Layout);
        p20Layout.setHorizontalGroup(
            p20Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 108, Short.MAX_VALUE)
        );
        p20Layout.setVerticalGroup(
            p20Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 8, Short.MAX_VALUE)
        );

        gamePanel.add(p20);
        p20.setBounds(440, 50, 110, 10);

        p21.setBackground(new java.awt.Color(0, 51, 51));
        p21.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 51, 51)));

        javax.swing.GroupLayout p21Layout = new javax.swing.GroupLayout(p21);
        p21.setLayout(p21Layout);
        p21Layout.setHorizontalGroup(
            p21Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 8, Short.MAX_VALUE)
        );
        p21Layout.setVerticalGroup(
            p21Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 38, Short.MAX_VALUE)
        );

        gamePanel.add(p21);
        p21.setBounds(540, 60, 10, 40);

        p22.setBackground(new java.awt.Color(0, 51, 51));
        p22.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 51, 51)));

        javax.swing.GroupLayout p22Layout = new javax.swing.GroupLayout(p22);
        p22.setLayout(p22Layout);
        p22Layout.setHorizontalGroup(
            p22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 8, Short.MAX_VALUE)
        );
        p22Layout.setVerticalGroup(
            p22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 78, Short.MAX_VALUE)
        );

        gamePanel.add(p22);
        p22.setBounds(490, 60, 10, 80);

        p23.setBackground(new java.awt.Color(0, 51, 51));
        p23.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 51, 51)));

        javax.swing.GroupLayout p23Layout = new javax.swing.GroupLayout(p23);
        p23.setLayout(p23Layout);
        p23Layout.setHorizontalGroup(
            p23Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 48, Short.MAX_VALUE)
        );
        p23Layout.setVerticalGroup(
            p23Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 8, Short.MAX_VALUE)
        );

        gamePanel.add(p23);
        p23.setBounds(450, 130, 50, 10);

        p24.setBackground(new java.awt.Color(0, 51, 51));
        p24.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 51, 51)));

        javax.swing.GroupLayout p24Layout = new javax.swing.GroupLayout(p24);
        p24.setLayout(p24Layout);
        p24Layout.setHorizontalGroup(
            p24Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 8, Short.MAX_VALUE)
        );
        p24Layout.setVerticalGroup(
            p24Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 138, Short.MAX_VALUE)
        );

        gamePanel.add(p24);
        p24.setBounds(450, 130, 10, 140);

        p25.setBackground(new java.awt.Color(0, 51, 51));
        p25.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 51, 51)));

        javax.swing.GroupLayout p25Layout = new javax.swing.GroupLayout(p25);
        p25.setLayout(p25Layout);
        p25Layout.setHorizontalGroup(
            p25Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 8, Short.MAX_VALUE)
        );
        p25Layout.setVerticalGroup(
            p25Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 168, Short.MAX_VALUE)
        );

        gamePanel.add(p25);
        p25.setBounds(670, 50, 10, 170);

        p26.setBackground(new java.awt.Color(0, 51, 51));
        p26.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 51, 51)));

        javax.swing.GroupLayout p26Layout = new javax.swing.GroupLayout(p26);
        p26.setLayout(p26Layout);
        p26Layout.setHorizontalGroup(
            p26Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 48, Short.MAX_VALUE)
        );
        p26Layout.setVerticalGroup(
            p26Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 8, Short.MAX_VALUE)
        );

        gamePanel.add(p26);
        p26.setBounds(450, 210, 50, 10);

        p27.setBackground(new java.awt.Color(0, 51, 51));
        p27.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 51, 51)));

        javax.swing.GroupLayout p27Layout = new javax.swing.GroupLayout(p27);
        p27.setLayout(p27Layout);
        p27Layout.setHorizontalGroup(
            p27Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 88, Short.MAX_VALUE)
        );
        p27Layout.setVerticalGroup(
            p27Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 8, Short.MAX_VALUE)
        );

        gamePanel.add(p27);
        p27.setBounds(500, 170, 90, 10);

        p28.setBackground(new java.awt.Color(0, 51, 51));
        p28.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 51, 51)));

        javax.swing.GroupLayout p28Layout = new javax.swing.GroupLayout(p28);
        p28.setLayout(p28Layout);
        p28Layout.setHorizontalGroup(
            p28Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 38, Short.MAX_VALUE)
        );
        p28Layout.setVerticalGroup(
            p28Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 8, Short.MAX_VALUE)
        );

        gamePanel.add(p28);
        p28.setBounds(550, 130, 40, 10);

        p29.setBackground(new java.awt.Color(0, 51, 51));
        p29.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 51, 51)));

        javax.swing.GroupLayout p29Layout = new javax.swing.GroupLayout(p29);
        p29.setLayout(p29Layout);
        p29Layout.setHorizontalGroup(
            p29Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 8, Short.MAX_VALUE)
        );
        p29Layout.setVerticalGroup(
            p29Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 48, Short.MAX_VALUE)
        );

        gamePanel.add(p29);
        p29.setBounds(580, 130, 10, 50);

        p30.setBackground(new java.awt.Color(0, 51, 51));
        p30.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 51, 51)));

        javax.swing.GroupLayout p30Layout = new javax.swing.GroupLayout(p30);
        p30.setLayout(p30Layout);
        p30Layout.setHorizontalGroup(
            p30Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 8, Short.MAX_VALUE)
        );
        p30Layout.setVerticalGroup(
            p30Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 28, Short.MAX_VALUE)
        );

        gamePanel.add(p30);
        p30.setBounds(580, 20, 10, 30);

        p31.setBackground(new java.awt.Color(0, 51, 51));
        p31.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 51, 51)));

        javax.swing.GroupLayout p31Layout = new javax.swing.GroupLayout(p31);
        p31.setLayout(p31Layout);
        p31Layout.setHorizontalGroup(
            p31Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 38, Short.MAX_VALUE)
        );
        p31Layout.setVerticalGroup(
            p31Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 8, Short.MAX_VALUE)
        );

        gamePanel.add(p31);
        p31.setBounds(630, 170, 40, 10);

        p32.setBackground(new java.awt.Color(0, 51, 51));
        p32.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 51, 51)));

        javax.swing.GroupLayout p32Layout = new javax.swing.GroupLayout(p32);
        p32.setLayout(p32Layout);
        p32Layout.setHorizontalGroup(
            p32Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 128, Short.MAX_VALUE)
        );
        p32Layout.setVerticalGroup(
            p32Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 8, Short.MAX_VALUE)
        );

        gamePanel.add(p32);
        p32.setBounds(450, 270, 130, 10);

        p33.setBackground(new java.awt.Color(0, 51, 51));
        p33.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 51, 51)));

        javax.swing.GroupLayout p33Layout = new javax.swing.GroupLayout(p33);
        p33.setLayout(p33Layout);
        p33Layout.setHorizontalGroup(
            p33Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 8, Short.MAX_VALUE)
        );
        p33Layout.setVerticalGroup(
            p33Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 98, Short.MAX_VALUE)
        );

        gamePanel.add(p33);
        p33.setBounds(540, 170, 10, 100);

        p34.setBackground(new java.awt.Color(0, 51, 51));
        p34.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 51, 51)));

        javax.swing.GroupLayout p34Layout = new javax.swing.GroupLayout(p34);
        p34.setLayout(p34Layout);
        p34Layout.setHorizontalGroup(
            p34Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 8, Short.MAX_VALUE)
        );
        p34Layout.setVerticalGroup(
            p34Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 118, Short.MAX_VALUE)
        );

        gamePanel.add(p34);
        p34.setBounds(620, 20, 10, 120);

        p35.setBackground(new java.awt.Color(0, 51, 51));
        p35.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 51, 51)));

        javax.swing.GroupLayout p35Layout = new javax.swing.GroupLayout(p35);
        p35.setLayout(p35Layout);
        p35Layout.setHorizontalGroup(
            p35Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 88, Short.MAX_VALUE)
        );
        p35Layout.setVerticalGroup(
            p35Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 8, Short.MAX_VALUE)
        );

        gamePanel.add(p35);
        p35.setBounds(630, 270, 90, 10);

        p36.setBackground(new java.awt.Color(0, 51, 51));
        p36.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 51, 51)));

        javax.swing.GroupLayout p36Layout = new javax.swing.GroupLayout(p36);
        p36.setLayout(p36Layout);
        p36Layout.setHorizontalGroup(
            p36Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 8, Short.MAX_VALUE)
        );
        p36Layout.setVerticalGroup(
            p36Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 28, Short.MAX_VALUE)
        );

        gamePanel.add(p36);
        p36.setBounds(670, 280, 10, 30);

        p37.setBackground(new java.awt.Color(0, 51, 51));
        p37.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 51, 51)));

        javax.swing.GroupLayout p37Layout = new javax.swing.GroupLayout(p37);
        p37.setLayout(p37Layout);
        p37Layout.setHorizontalGroup(
            p37Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 38, Short.MAX_VALUE)
        );
        p37Layout.setVerticalGroup(
            p37Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 8, Short.MAX_VALUE)
        );

        gamePanel.add(p37);
        p37.setBounds(680, 340, 40, 10);

        p38.setBackground(new java.awt.Color(0, 51, 51));
        p38.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 51, 51)));

        javax.swing.GroupLayout p38Layout = new javax.swing.GroupLayout(p38);
        p38.setLayout(p38Layout);
        p38Layout.setHorizontalGroup(
            p38Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 8, Short.MAX_VALUE)
        );
        p38Layout.setVerticalGroup(
            p38Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 38, Short.MAX_VALUE)
        );

        gamePanel.add(p38);
        p38.setBounds(570, 280, 10, 40);

        p39.setBackground(new java.awt.Color(0, 51, 51));
        p39.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 51, 51)));

        javax.swing.GroupLayout p39Layout = new javax.swing.GroupLayout(p39);
        p39.setLayout(p39Layout);
        p39Layout.setHorizontalGroup(
            p39Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 8, Short.MAX_VALUE)
        );
        p39Layout.setVerticalGroup(
            p39Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 68, Short.MAX_VALUE)
        );

        gamePanel.add(p39);
        p39.setBounds(90, 120, 10, 70);

        p40.setBackground(new java.awt.Color(0, 51, 51));
        p40.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 51, 51)));

        javax.swing.GroupLayout p40Layout = new javax.swing.GroupLayout(p40);
        p40.setLayout(p40Layout);
        p40Layout.setHorizontalGroup(
            p40Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 68, Short.MAX_VALUE)
        );
        p40Layout.setVerticalGroup(
            p40Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 8, Short.MAX_VALUE)
        );

        gamePanel.add(p40);
        p40.setBounds(20, 160, 70, 10);

        p41.setBackground(new java.awt.Color(0, 51, 51));
        p41.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 51, 51)));

        javax.swing.GroupLayout p41Layout = new javax.swing.GroupLayout(p41);
        p41.setLayout(p41Layout);
        p41Layout.setHorizontalGroup(
            p41Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 38, Short.MAX_VALUE)
        );
        p41Layout.setVerticalGroup(
            p41Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 8, Short.MAX_VALUE)
        );

        gamePanel.add(p41);
        p41.setBounds(100, 180, 40, 10);

        p42.setBackground(new java.awt.Color(0, 51, 51));
        p42.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 51, 51)));

        javax.swing.GroupLayout p42Layout = new javax.swing.GroupLayout(p42);
        p42.setLayout(p42Layout);
        p42Layout.setHorizontalGroup(
            p42Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 8, Short.MAX_VALUE)
        );
        p42Layout.setVerticalGroup(
            p42Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 98, Short.MAX_VALUE)
        );

        gamePanel.add(p42);
        p42.setBounds(180, 140, 10, 100);

        p43.setBackground(new java.awt.Color(0, 51, 51));
        p43.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 51, 51)));

        javax.swing.GroupLayout p43Layout = new javax.swing.GroupLayout(p43);
        p43.setLayout(p43Layout);
        p43Layout.setHorizontalGroup(
            p43Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 8, Short.MAX_VALUE)
        );
        p43Layout.setVerticalGroup(
            p43Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 58, Short.MAX_VALUE)
        );

        gamePanel.add(p43);
        p43.setBounds(130, 180, 10, 60);

        p44.setBackground(new java.awt.Color(0, 51, 51));
        p44.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 51, 51)));

        javax.swing.GroupLayout p44Layout = new javax.swing.GroupLayout(p44);
        p44.setLayout(p44Layout);
        p44Layout.setHorizontalGroup(
            p44Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 48, Short.MAX_VALUE)
        );
        p44Layout.setVerticalGroup(
            p44Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 8, Short.MAX_VALUE)
        );

        gamePanel.add(p44);
        p44.setBounds(130, 230, 50, 10);

        p45.setBackground(new java.awt.Color(0, 51, 51));
        p45.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 51, 51)));

        javax.swing.GroupLayout p45Layout = new javax.swing.GroupLayout(p45);
        p45.setLayout(p45Layout);
        p45Layout.setHorizontalGroup(
            p45Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 8, Short.MAX_VALUE)
        );
        p45Layout.setVerticalGroup(
            p45Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 128, Short.MAX_VALUE)
        );

        gamePanel.add(p45);
        p45.setBounds(280, 140, 10, 130);

        p46.setBackground(new java.awt.Color(0, 51, 51));
        p46.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 51, 51)));

        javax.swing.GroupLayout p46Layout = new javax.swing.GroupLayout(p46);
        p46.setLayout(p46Layout);
        p46Layout.setHorizontalGroup(
            p46Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 98, Short.MAX_VALUE)
        );
        p46Layout.setVerticalGroup(
            p46Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 8, Short.MAX_VALUE)
        );

        gamePanel.add(p46);
        p46.setBounds(190, 170, 100, 10);

        p49.setBackground(new java.awt.Color(0, 51, 51));
        p49.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 51, 51)));

        javax.swing.GroupLayout p49Layout = new javax.swing.GroupLayout(p49);
        p49.setLayout(p49Layout);
        p49Layout.setHorizontalGroup(
            p49Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 98, Short.MAX_VALUE)
        );
        p49Layout.setVerticalGroup(
            p49Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 8, Short.MAX_VALUE)
        );

        gamePanel.add(p49);
        p49.setBounds(350, 170, 100, 10);

        p50.setBackground(new java.awt.Color(0, 51, 51));
        p50.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 51, 51)));

        javax.swing.GroupLayout p50Layout = new javax.swing.GroupLayout(p50);
        p50.setLayout(p50Layout);
        p50Layout.setHorizontalGroup(
            p50Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 48, Short.MAX_VALUE)
        );
        p50Layout.setVerticalGroup(
            p50Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 8, Short.MAX_VALUE)
        );

        gamePanel.add(p50);
        p50.setBounds(350, 210, 50, 10);

        p47.setBackground(new java.awt.Color(0, 51, 51));
        p47.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 51, 51)));

        javax.swing.GroupLayout p47Layout = new javax.swing.GroupLayout(p47);
        p47.setLayout(p47Layout);
        p47Layout.setHorizontalGroup(
            p47Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 8, Short.MAX_VALUE)
        );
        p47Layout.setVerticalGroup(
            p47Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 68, Short.MAX_VALUE)
        );

        gamePanel.add(p47);
        p47.setBounds(390, 210, 10, 70);

        p48.setBackground(new java.awt.Color(0, 51, 51));
        p48.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 51, 51)));

        javax.swing.GroupLayout p48Layout = new javax.swing.GroupLayout(p48);
        p48.setLayout(p48Layout);
        p48Layout.setHorizontalGroup(
            p48Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 148, Short.MAX_VALUE)
        );
        p48Layout.setVerticalGroup(
            p48Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 8, Short.MAX_VALUE)
        );

        gamePanel.add(p48);
        p48.setBounds(240, 270, 150, 10);

        p51.setBackground(new java.awt.Color(0, 51, 51));
        p51.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 51, 51)));

        javax.swing.GroupLayout p51Layout = new javax.swing.GroupLayout(p51);
        p51.setLayout(p51Layout);
        p51Layout.setHorizontalGroup(
            p51Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 8, Short.MAX_VALUE)
        );
        p51Layout.setVerticalGroup(
            p51Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 198, Short.MAX_VALUE)
        );

        gamePanel.add(p51);
        p51.setBounds(230, 240, 10, 200);

        p52.setBackground(new java.awt.Color(0, 51, 51));
        p52.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 51, 51)));

        javax.swing.GroupLayout p52Layout = new javax.swing.GroupLayout(p52);
        p52.setLayout(p52Layout);
        p52Layout.setHorizontalGroup(
            p52Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 8, Short.MAX_VALUE)
        );
        p52Layout.setVerticalGroup(
            p52Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 38, Short.MAX_VALUE)
        );

        gamePanel.add(p52);
        p52.setBounds(50, 200, 10, 40);

        p53.setBackground(new java.awt.Color(0, 51, 51));
        p53.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 51, 51)));

        javax.swing.GroupLayout p53Layout = new javax.swing.GroupLayout(p53);
        p53.setLayout(p53Layout);
        p53Layout.setHorizontalGroup(
            p53Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 38, Short.MAX_VALUE)
        );
        p53Layout.setVerticalGroup(
            p53Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 8, Short.MAX_VALUE)
        );

        gamePanel.add(p53);
        p53.setBounds(50, 230, 40, 10);

        p54.setBackground(new java.awt.Color(0, 51, 51));
        p54.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 51, 51)));

        javax.swing.GroupLayout p54Layout = new javax.swing.GroupLayout(p54);
        p54.setLayout(p54Layout);
        p54Layout.setHorizontalGroup(
            p54Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 8, Short.MAX_VALUE)
        );
        p54Layout.setVerticalGroup(
            p54Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 68, Short.MAX_VALUE)
        );

        gamePanel.add(p54);
        p54.setBounds(80, 230, 10, 70);

        p55.setBackground(new java.awt.Color(0, 51, 51));
        p55.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 51, 51)));

        javax.swing.GroupLayout p55Layout = new javax.swing.GroupLayout(p55);
        p55.setLayout(p55Layout);
        p55Layout.setHorizontalGroup(
            p55Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 38, Short.MAX_VALUE)
        );
        p55Layout.setVerticalGroup(
            p55Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 8, Short.MAX_VALUE)
        );

        gamePanel.add(p55);
        p55.setBounds(50, 300, 40, 10);

        p56.setBackground(new java.awt.Color(0, 51, 51));
        p56.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 51, 51)));

        javax.swing.GroupLayout p56Layout = new javax.swing.GroupLayout(p56);
        p56.setLayout(p56Layout);
        p56Layout.setHorizontalGroup(
            p56Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 8, Short.MAX_VALUE)
        );
        p56Layout.setVerticalGroup(
            p56Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 28, Short.MAX_VALUE)
        );

        gamePanel.add(p56);
        p56.setBounds(340, 280, 10, 30);

        p57.setBackground(new java.awt.Color(0, 51, 51));
        p57.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 51, 51)));

        javax.swing.GroupLayout p57Layout = new javax.swing.GroupLayout(p57);
        p57.setLayout(p57Layout);
        p57Layout.setHorizontalGroup(
            p57Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 118, Short.MAX_VALUE)
        );
        p57Layout.setVerticalGroup(
            p57Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 8, Short.MAX_VALUE)
        );

        gamePanel.add(p57);
        p57.setBounds(20, 580, 120, 10);

        p58.setBackground(new java.awt.Color(0, 51, 51));
        p58.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 51, 51)));

        javax.swing.GroupLayout p58Layout = new javax.swing.GroupLayout(p58);
        p58.setLayout(p58Layout);
        p58Layout.setHorizontalGroup(
            p58Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 208, Short.MAX_VALUE)
        );
        p58Layout.setVerticalGroup(
            p58Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 8, Short.MAX_VALUE)
        );

        gamePanel.add(p58);
        p58.setBounds(410, 310, 210, 10);

        p59.setBackground(new java.awt.Color(0, 51, 51));
        p59.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 51, 51)));

        javax.swing.GroupLayout p59Layout = new javax.swing.GroupLayout(p59);
        p59.setLayout(p59Layout);
        p59Layout.setHorizontalGroup(
            p59Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 38, Short.MAX_VALUE)
        );
        p59Layout.setVerticalGroup(
            p59Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 8, Short.MAX_VALUE)
        );

        gamePanel.add(p59);
        p59.setBounds(680, 580, 40, 10);

        p60.setBackground(new java.awt.Color(0, 51, 51));
        p60.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 51, 51)));

        javax.swing.GroupLayout p60Layout = new javax.swing.GroupLayout(p60);
        p60.setLayout(p60Layout);
        p60Layout.setHorizontalGroup(
            p60Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 38, Short.MAX_VALUE)
        );
        p60Layout.setVerticalGroup(
            p60Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 8, Short.MAX_VALUE)
        );

        gamePanel.add(p60);
        p60.setBounds(680, 510, 40, 10);

        p61.setBackground(new java.awt.Color(0, 51, 51));
        p61.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 51, 51)));

        javax.swing.GroupLayout p61Layout = new javax.swing.GroupLayout(p61);
        p61.setLayout(p61Layout);
        p61Layout.setHorizontalGroup(
            p61Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 8, Short.MAX_VALUE)
        );
        p61Layout.setVerticalGroup(
            p61Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 78, Short.MAX_VALUE)
        );

        gamePanel.add(p61);
        p61.setBounds(610, 310, 10, 80);

        p62.setBackground(new java.awt.Color(0, 51, 51));
        p62.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 51, 51)));

        javax.swing.GroupLayout p62Layout = new javax.swing.GroupLayout(p62);
        p62.setLayout(p62Layout);
        p62Layout.setHorizontalGroup(
            p62Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 8, Short.MAX_VALUE)
        );
        p62Layout.setVerticalGroup(
            p62Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 68, Short.MAX_VALUE)
        );

        gamePanel.add(p62);
        p62.setBounds(410, 310, 10, 70);

        p63.setBackground(new java.awt.Color(0, 51, 51));
        p63.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 51, 51)));

        javax.swing.GroupLayout p63Layout = new javax.swing.GroupLayout(p63);
        p63.setLayout(p63Layout);
        p63Layout.setHorizontalGroup(
            p63Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 8, Short.MAX_VALUE)
        );
        p63Layout.setVerticalGroup(
            p63Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 48, Short.MAX_VALUE)
        );

        gamePanel.add(p63);
        p63.setBounds(280, 300, 10, 50);

        p64.setBackground(new java.awt.Color(0, 51, 51));
        p64.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 51, 51)));

        javax.swing.GroupLayout p64Layout = new javax.swing.GroupLayout(p64);
        p64.setLayout(p64Layout);
        p64Layout.setHorizontalGroup(
            p64Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 8, Short.MAX_VALUE)
        );
        p64Layout.setVerticalGroup(
            p64Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 78, Short.MAX_VALUE)
        );

        gamePanel.add(p64);
        p64.setBounds(50, 300, 10, 80);

        p65.setBackground(new java.awt.Color(0, 51, 51));
        p65.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 51, 51)));

        javax.swing.GroupLayout p65Layout = new javax.swing.GroupLayout(p65);
        p65.setLayout(p65Layout);
        p65Layout.setHorizontalGroup(
            p65Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 38, Short.MAX_VALUE)
        );
        p65Layout.setVerticalGroup(
            p65Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 8, Short.MAX_VALUE)
        );

        gamePanel.add(p65);
        p65.setBounds(50, 380, 40, 10);

        p66.setBackground(new java.awt.Color(0, 51, 51));
        p66.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 51, 51)));

        javax.swing.GroupLayout p66Layout = new javax.swing.GroupLayout(p66);
        p66.setLayout(p66Layout);
        p66Layout.setHorizontalGroup(
            p66Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 138, Short.MAX_VALUE)
        );
        p66Layout.setVerticalGroup(
            p66Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 8, Short.MAX_VALUE)
        );

        gamePanel.add(p66);
        p66.setBounds(100, 340, 140, 10);

        p67.setBackground(new java.awt.Color(0, 51, 51));
        p67.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 51, 51)));

        javax.swing.GroupLayout p67Layout = new javax.swing.GroupLayout(p67);
        p67.setLayout(p67Layout);
        p67Layout.setHorizontalGroup(
            p67Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 98, Short.MAX_VALUE)
        );
        p67Layout.setVerticalGroup(
            p67Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 8, Short.MAX_VALUE)
        );

        gamePanel.add(p67);
        p67.setBounds(90, 270, 100, 10);

        p68.setBackground(new java.awt.Color(0, 51, 51));
        p68.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 51, 51)));

        javax.swing.GroupLayout p68Layout = new javax.swing.GroupLayout(p68);
        p68.setLayout(p68Layout);
        p68Layout.setHorizontalGroup(
            p68Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 48, Short.MAX_VALUE)
        );
        p68Layout.setVerticalGroup(
            p68Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 8, Short.MAX_VALUE)
        );

        gamePanel.add(p68);
        p68.setBounds(140, 300, 50, 10);

        p69.setBackground(new java.awt.Color(0, 51, 51));
        p69.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 51, 51)));

        javax.swing.GroupLayout p69Layout = new javax.swing.GroupLayout(p69);
        p69.setLayout(p69Layout);
        p69Layout.setHorizontalGroup(
            p69Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 8, Short.MAX_VALUE)
        );
        p69Layout.setVerticalGroup(
            p69Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 168, Short.MAX_VALUE)
        );

        gamePanel.add(p69);
        p69.setBounds(130, 300, 10, 170);

        p70.setBackground(new java.awt.Color(0, 51, 51));
        p70.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 51, 51)));

        javax.swing.GroupLayout p70Layout = new javax.swing.GroupLayout(p70);
        p70.setLayout(p70Layout);
        p70Layout.setHorizontalGroup(
            p70Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 118, Short.MAX_VALUE)
        );
        p70Layout.setVerticalGroup(
            p70Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 8, Short.MAX_VALUE)
        );

        gamePanel.add(p70);
        p70.setBounds(290, 340, 120, 10);

        p71.setBackground(new java.awt.Color(0, 51, 51));
        p71.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 51, 51)));

        javax.swing.GroupLayout p71Layout = new javax.swing.GroupLayout(p71);
        p71.setLayout(p71Layout);
        p71Layout.setHorizontalGroup(
            p71Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 8, Short.MAX_VALUE)
        );
        p71Layout.setVerticalGroup(
            p71Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 68, Short.MAX_VALUE)
        );

        gamePanel.add(p71);
        p71.setBounds(130, 510, 10, 70);

        p72.setBackground(new java.awt.Color(0, 51, 51));
        p72.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 51, 51)));

        javax.swing.GroupLayout p72Layout = new javax.swing.GroupLayout(p72);
        p72.setLayout(p72Layout);
        p72Layout.setHorizontalGroup(
            p72Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 8, Short.MAX_VALUE)
        );
        p72Layout.setVerticalGroup(
            p72Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 128, Short.MAX_VALUE)
        );

        gamePanel.add(p72);
        p72.setBounds(80, 380, 10, 130);

        p73.setBackground(new java.awt.Color(0, 51, 51));
        p73.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 51, 51)));

        javax.swing.GroupLayout p73Layout = new javax.swing.GroupLayout(p73);
        p73.setLayout(p73Layout);
        p73Layout.setHorizontalGroup(
            p73Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 58, Short.MAX_VALUE)
        );
        p73Layout.setVerticalGroup(
            p73Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 8, Short.MAX_VALUE)
        );

        gamePanel.add(p73);
        p73.setBounds(80, 510, 60, 10);

        p74.setBackground(new java.awt.Color(0, 51, 51));
        p74.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 51, 51)));

        javax.swing.GroupLayout p74Layout = new javax.swing.GroupLayout(p74);
        p74.setLayout(p74Layout);
        p74Layout.setHorizontalGroup(
            p74Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 8, Short.MAX_VALUE)
        );
        p74Layout.setVerticalGroup(
            p74Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 108, Short.MAX_VALUE)
        );

        gamePanel.add(p74);
        p74.setBounds(50, 450, 10, 110);

        p75.setBackground(new java.awt.Color(0, 51, 51));
        p75.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 51, 51)));

        javax.swing.GroupLayout p75Layout = new javax.swing.GroupLayout(p75);
        p75.setLayout(p75Layout);
        p75Layout.setHorizontalGroup(
            p75Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 38, Short.MAX_VALUE)
        );
        p75Layout.setVerticalGroup(
            p75Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 8, Short.MAX_VALUE)
        );

        gamePanel.add(p75);
        p75.setBounds(50, 450, 40, 10);

        p76.setBackground(new java.awt.Color(0, 51, 51));
        p76.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 51, 51)));

        javax.swing.GroupLayout p76Layout = new javax.swing.GroupLayout(p76);
        p76.setLayout(p76Layout);
        p76Layout.setHorizontalGroup(
            p76Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 38, Short.MAX_VALUE)
        );
        p76Layout.setVerticalGroup(
            p76Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 8, Short.MAX_VALUE)
        );

        gamePanel.add(p76);
        p76.setBounds(60, 550, 40, 10);

        p77.setBackground(new java.awt.Color(0, 51, 51));
        p77.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 51, 51)));

        javax.swing.GroupLayout p77Layout = new javax.swing.GroupLayout(p77);
        p77.setLayout(p77Layout);
        p77Layout.setHorizontalGroup(
            p77Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 8, Short.MAX_VALUE)
        );
        p77Layout.setVerticalGroup(
            p77Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 208, Short.MAX_VALUE)
        );

        gamePanel.add(p77);
        p77.setBounds(180, 380, 10, 210);

        p78.setBackground(new java.awt.Color(0, 51, 51));
        p78.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 51, 51)));

        javax.swing.GroupLayout p78Layout = new javax.swing.GroupLayout(p78);
        p78.setLayout(p78Layout);
        p78Layout.setHorizontalGroup(
            p78Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 118, Short.MAX_VALUE)
        );
        p78Layout.setVerticalGroup(
            p78Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 8, Short.MAX_VALUE)
        );

        gamePanel.add(p78);
        p78.setBounds(230, 390, 120, 10);

        p79.setBackground(new java.awt.Color(0, 51, 51));
        p79.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 51, 51)));

        javax.swing.GroupLayout p79Layout = new javax.swing.GroupLayout(p79);
        p79.setLayout(p79Layout);
        p79Layout.setHorizontalGroup(
            p79Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 8, Short.MAX_VALUE)
        );
        p79Layout.setVerticalGroup(
            p79Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 48, Short.MAX_VALUE)
        );

        gamePanel.add(p79);
        p79.setBounds(340, 390, 10, 50);

        p80.setBackground(new java.awt.Color(0, 51, 51));
        p80.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 51, 51)));

        javax.swing.GroupLayout p80Layout = new javax.swing.GroupLayout(p80);
        p80.setLayout(p80Layout);
        p80Layout.setHorizontalGroup(
            p80Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 58, Short.MAX_VALUE)
        );
        p80Layout.setVerticalGroup(
            p80Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 8, Short.MAX_VALUE)
        );

        gamePanel.add(p80);
        p80.setBounds(410, 380, 60, 10);

        p81.setBackground(new java.awt.Color(0, 51, 51));
        p81.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 51, 51)));

        javax.swing.GroupLayout p81Layout = new javax.swing.GroupLayout(p81);
        p81.setLayout(p81Layout);
        p81Layout.setHorizontalGroup(
            p81Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 78, Short.MAX_VALUE)
        );
        p81Layout.setVerticalGroup(
            p81Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 8, Short.MAX_VALUE)
        );

        gamePanel.add(p81);
        p81.setBounds(580, 380, 80, 10);

        p82.setBackground(new java.awt.Color(0, 51, 51));
        p82.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 51, 51)));

        javax.swing.GroupLayout p82Layout = new javax.swing.GroupLayout(p82);
        p82.setLayout(p82Layout);
        p82Layout.setHorizontalGroup(
            p82Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 68, Short.MAX_VALUE)
        );
        p82Layout.setVerticalGroup(
            p82Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 8, Short.MAX_VALUE)
        );

        gamePanel.add(p82);
        p82.setBounds(340, 430, 70, 10);

        p83.setBackground(new java.awt.Color(0, 51, 51));
        p83.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 51, 51)));

        javax.swing.GroupLayout p83Layout = new javax.swing.GroupLayout(p83);
        p83.setLayout(p83Layout);
        p83Layout.setHorizontalGroup(
            p83Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 8, Short.MAX_VALUE)
        );
        p83Layout.setVerticalGroup(
            p83Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 88, Short.MAX_VALUE)
        );

        gamePanel.add(p83);
        p83.setBounds(540, 350, 10, 90);

        p84.setBackground(new java.awt.Color(0, 51, 51));
        p84.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 51, 51)));

        javax.swing.GroupLayout p84Layout = new javax.swing.GroupLayout(p84);
        p84.setLayout(p84Layout);
        p84Layout.setHorizontalGroup(
            p84Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 128, Short.MAX_VALUE)
        );
        p84Layout.setVerticalGroup(
            p84Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 8, Short.MAX_VALUE)
        );

        gamePanel.add(p84);
        p84.setBounds(450, 340, 130, 10);

        p85.setBackground(new java.awt.Color(0, 51, 51));
        p85.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 51, 51)));

        javax.swing.GroupLayout p85Layout = new javax.swing.GroupLayout(p85);
        p85.setLayout(p85Layout);
        p85Layout.setHorizontalGroup(
            p85Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 8, Short.MAX_VALUE)
        );
        p85Layout.setVerticalGroup(
            p85Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 88, Short.MAX_VALUE)
        );

        gamePanel.add(p85);
        p85.setBounds(500, 350, 10, 90);

        p86.setBackground(new java.awt.Color(0, 51, 51));
        p86.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 51, 51)));

        javax.swing.GroupLayout p86Layout = new javax.swing.GroupLayout(p86);
        p86.setLayout(p86Layout);
        p86Layout.setHorizontalGroup(
            p86Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 8, Short.MAX_VALUE)
        );
        p86Layout.setVerticalGroup(
            p86Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 138, Short.MAX_VALUE)
        );

        gamePanel.add(p86);
        p86.setBounds(460, 380, 10, 140);

        p87.setBackground(new java.awt.Color(0, 51, 51));
        p87.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 51, 51)));

        javax.swing.GroupLayout p87Layout = new javax.swing.GroupLayout(p87);
        p87.setLayout(p87Layout);
        p87Layout.setHorizontalGroup(
            p87Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 78, Short.MAX_VALUE)
        );
        p87Layout.setVerticalGroup(
            p87Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 8, Short.MAX_VALUE)
        );

        gamePanel.add(p87);
        p87.setBounds(540, 430, 80, 10);

        p89.setBackground(new java.awt.Color(0, 51, 51));
        p89.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 51, 51)));

        javax.swing.GroupLayout p89Layout = new javax.swing.GroupLayout(p89);
        p89.setLayout(p89Layout);
        p89Layout.setHorizontalGroup(
            p89Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 38, Short.MAX_VALUE)
        );
        p89Layout.setVerticalGroup(
            p89Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 8, Short.MAX_VALUE)
        );

        gamePanel.add(p89);
        p89.setBounds(680, 430, 40, 10);

        p90.setBackground(new java.awt.Color(0, 51, 51));
        p90.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 51, 51)));

        javax.swing.GroupLayout p90Layout = new javax.swing.GroupLayout(p90);
        p90.setLayout(p90Layout);
        p90Layout.setHorizontalGroup(
            p90Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 128, Short.MAX_VALUE)
        );
        p90Layout.setVerticalGroup(
            p90Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 8, Short.MAX_VALUE)
        );

        gamePanel.add(p90);
        p90.setBounds(590, 470, 130, 10);

        p91.setBackground(new java.awt.Color(0, 51, 51));
        p91.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 51, 51)));

        javax.swing.GroupLayout p91Layout = new javax.swing.GroupLayout(p91);
        p91.setLayout(p91Layout);
        p91Layout.setHorizontalGroup(
            p91Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 8, Short.MAX_VALUE)
        );
        p91Layout.setVerticalGroup(
            p91Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 48, Short.MAX_VALUE)
        );

        gamePanel.add(p91);
        p91.setBounds(580, 430, 10, 50);

        p92.setBackground(new java.awt.Color(0, 51, 51));
        p92.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 51, 51)));

        javax.swing.GroupLayout p92Layout = new javax.swing.GroupLayout(p92);
        p92.setLayout(p92Layout);
        p92Layout.setHorizontalGroup(
            p92Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 348, Short.MAX_VALUE)
        );
        p92Layout.setVerticalGroup(
            p92Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 8, Short.MAX_VALUE)
        );

        gamePanel.add(p92);
        p92.setBounds(190, 470, 350, 10);

        p93.setBackground(new java.awt.Color(0, 51, 51));
        p93.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 51, 51)));

        javax.swing.GroupLayout p93Layout = new javax.swing.GroupLayout(p93);
        p93.setLayout(p93Layout);
        p93Layout.setHorizontalGroup(
            p93Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 8, Short.MAX_VALUE)
        );
        p93Layout.setVerticalGroup(
            p93Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 88, Short.MAX_VALUE)
        );

        gamePanel.add(p93);
        p93.setBounds(530, 470, 10, 90);

        p94.setBackground(new java.awt.Color(0, 51, 51));
        p94.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 51, 51)));

        javax.swing.GroupLayout p94Layout = new javax.swing.GroupLayout(p94);
        p94.setLayout(p94Layout);
        p94Layout.setHorizontalGroup(
            p94Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 8, Short.MAX_VALUE)
        );
        p94Layout.setVerticalGroup(
            p94Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 28, Short.MAX_VALUE)
        );

        gamePanel.add(p94);
        p94.setBounds(280, 440, 10, 30);

        p95.setBackground(new java.awt.Color(0, 51, 51));
        p95.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 51, 51)));

        javax.swing.GroupLayout p95Layout = new javax.swing.GroupLayout(p95);
        p95.setLayout(p95Layout);
        p95Layout.setHorizontalGroup(
            p95Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 38, Short.MAX_VALUE)
        );
        p95Layout.setVerticalGroup(
            p95Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 8, Short.MAX_VALUE)
        );

        gamePanel.add(p95);
        p95.setBounds(180, 510, 40, 10);

        p96.setBackground(new java.awt.Color(0, 51, 51));
        p96.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 51, 51)));

        javax.swing.GroupLayout p96Layout = new javax.swing.GroupLayout(p96);
        p96.setLayout(p96Layout);
        p96Layout.setHorizontalGroup(
            p96Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 8, Short.MAX_VALUE)
        );
        p96Layout.setVerticalGroup(
            p96Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 68, Short.MAX_VALUE)
        );

        gamePanel.add(p96);
        p96.setBounds(340, 480, 10, 70);

        p97.setBackground(new java.awt.Color(0, 51, 51));
        p97.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 51, 51)));

        javax.swing.GroupLayout p97Layout = new javax.swing.GroupLayout(p97);
        p97.setLayout(p97Layout);
        p97Layout.setHorizontalGroup(
            p97Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 48, Short.MAX_VALUE)
        );
        p97Layout.setVerticalGroup(
            p97Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 8, Short.MAX_VALUE)
        );

        gamePanel.add(p97);
        p97.setBounds(530, 510, 50, 10);

        p98.setBackground(new java.awt.Color(0, 51, 51));
        p98.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 51, 51)));

        javax.swing.GroupLayout p98Layout = new javax.swing.GroupLayout(p98);
        p98.setLayout(p98Layout);
        p98Layout.setHorizontalGroup(
            p98Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 68, Short.MAX_VALUE)
        );
        p98Layout.setVerticalGroup(
            p98Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 8, Short.MAX_VALUE)
        );

        gamePanel.add(p98);
        p98.setBounds(590, 550, 70, 10);

        p99.setBackground(new java.awt.Color(0, 51, 51));
        p99.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 51, 51)));

        javax.swing.GroupLayout p99Layout = new javax.swing.GroupLayout(p99);
        p99.setLayout(p99Layout);
        p99Layout.setHorizontalGroup(
            p99Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 8, Short.MAX_VALUE)
        );
        p99Layout.setVerticalGroup(
            p99Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 68, Short.MAX_VALUE)
        );

        gamePanel.add(p99);
        p99.setBounds(620, 480, 10, 70);

        p100.setBackground(new java.awt.Color(0, 51, 51));
        p100.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 51, 51)));

        javax.swing.GroupLayout p100Layout = new javax.swing.GroupLayout(p100);
        p100.setLayout(p100Layout);
        p100Layout.setHorizontalGroup(
            p100Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 8, Short.MAX_VALUE)
        );
        p100Layout.setVerticalGroup(
            p100Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 28, Short.MAX_VALUE)
        );

        gamePanel.add(p100);
        p100.setBounds(620, 600, 10, 30);

        p101.setBackground(new java.awt.Color(0, 51, 51));
        p101.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 51, 51)));

        javax.swing.GroupLayout p101Layout = new javax.swing.GroupLayout(p101);
        p101.setLayout(p101Layout);
        p101Layout.setHorizontalGroup(
            p101Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 8, Short.MAX_VALUE)
        );
        p101Layout.setVerticalGroup(
            p101Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 68, Short.MAX_VALUE)
        );

        gamePanel.add(p101);
        p101.setBounds(280, 520, 10, 70);

        p102.setBackground(new java.awt.Color(0, 51, 51));
        p102.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 51, 51)));

        javax.swing.GroupLayout p102Layout = new javax.swing.GroupLayout(p102);
        p102.setLayout(p102Layout);
        p102Layout.setHorizontalGroup(
            p102Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 8, Short.MAX_VALUE)
        );
        p102Layout.setVerticalGroup(
            p102Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 48, Short.MAX_VALUE)
        );

        gamePanel.add(p102);
        p102.setBounds(580, 550, 10, 50);

        p103.setBackground(new java.awt.Color(0, 51, 51));
        p103.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 51, 51)));

        javax.swing.GroupLayout p103Layout = new javax.swing.GroupLayout(p103);
        p103.setLayout(p103Layout);
        p103Layout.setHorizontalGroup(
            p103Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 78, Short.MAX_VALUE)
        );
        p103Layout.setVerticalGroup(
            p103Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 8, Short.MAX_VALUE)
        );

        gamePanel.add(p103);
        p103.setBounds(510, 590, 80, 10);

        p104.setBackground(new java.awt.Color(0, 51, 51));
        p104.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 51, 51)));

        javax.swing.GroupLayout p104Layout = new javax.swing.GroupLayout(p104);
        p104.setLayout(p104Layout);
        p104Layout.setHorizontalGroup(
            p104Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 8, Short.MAX_VALUE)
        );
        p104Layout.setVerticalGroup(
            p104Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 38, Short.MAX_VALUE)
        );

        gamePanel.add(p104);
        p104.setBounds(400, 520, 10, 40);

        p105.setBackground(new java.awt.Color(0, 51, 51));
        p105.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 51, 51)));

        javax.swing.GroupLayout p105Layout = new javax.swing.GroupLayout(p105);
        p105.setLayout(p105Layout);
        p105Layout.setHorizontalGroup(
            p105Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 98, Short.MAX_VALUE)
        );
        p105Layout.setVerticalGroup(
            p105Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 8, Short.MAX_VALUE)
        );

        gamePanel.add(p105);
        p105.setBounds(400, 550, 100, 10);

        p106.setBackground(new java.awt.Color(0, 51, 51));
        p106.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 51, 51)));

        javax.swing.GroupLayout p106Layout = new javax.swing.GroupLayout(p106);
        p106.setLayout(p106Layout);
        p106Layout.setHorizontalGroup(
            p106Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 8, Short.MAX_VALUE)
        );
        p106Layout.setVerticalGroup(
            p106Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 78, Short.MAX_VALUE)
        );

        gamePanel.add(p106);
        p106.setBounds(500, 520, 10, 80);

        p107.setBackground(new java.awt.Color(0, 51, 51));
        p107.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 51, 51)));

        javax.swing.GroupLayout p107Layout = new javax.swing.GroupLayout(p107);
        p107.setLayout(p107Layout);
        p107Layout.setHorizontalGroup(
            p107Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 188, Short.MAX_VALUE)
        );
        p107Layout.setVerticalGroup(
            p107Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 8, Short.MAX_VALUE)
        );

        gamePanel.add(p107);
        p107.setBounds(280, 580, 190, 10);

        p108.setBackground(new java.awt.Color(0, 51, 51));
        p108.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 51, 51)));

        javax.swing.GroupLayout p108Layout = new javax.swing.GroupLayout(p108);
        p108.setLayout(p108Layout);
        p108Layout.setHorizontalGroup(
            p108Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 8, Short.MAX_VALUE)
        );
        p108Layout.setVerticalGroup(
            p108Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 38, Short.MAX_VALUE)
        );

        gamePanel.add(p108);
        p108.setBounds(460, 590, 10, 40);

        p109.setBackground(new java.awt.Color(0, 51, 51));
        p109.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 51, 51)));

        javax.swing.GroupLayout p109Layout = new javax.swing.GroupLayout(p109);
        p109.setLayout(p109Layout);
        p109Layout.setHorizontalGroup(
            p109Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 8, Short.MAX_VALUE)
        );
        p109Layout.setVerticalGroup(
            p109Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 38, Short.MAX_VALUE)
        );

        gamePanel.add(p109);
        p109.setBounds(240, 550, 10, 40);

        p110.setBackground(new java.awt.Color(0, 51, 51));
        p110.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 51, 51)));

        javax.swing.GroupLayout p110Layout = new javax.swing.GroupLayout(p110);
        p110.setLayout(p110Layout);
        p110Layout.setHorizontalGroup(
            p110Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 38, Short.MAX_VALUE)
        );
        p110Layout.setVerticalGroup(
            p110Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 8, Short.MAX_VALUE)
        );

        gamePanel.add(p110);
        p110.setBounds(240, 540, 40, 10);

        p111.setBackground(new java.awt.Color(0, 51, 51));
        p111.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 51, 51)));

        javax.swing.GroupLayout p111Layout = new javax.swing.GroupLayout(p111);
        p111.setLayout(p111Layout);
        p111Layout.setHorizontalGroup(
            p111Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 18, Short.MAX_VALUE)
        );
        p111Layout.setVerticalGroup(
            p111Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 8, Short.MAX_VALUE)
        );

        gamePanel.add(p111);
        p111.setBounds(20, 270, 20, 10);

        p112.setBackground(new java.awt.Color(0, 51, 51));
        p112.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 51, 51)));

        javax.swing.GroupLayout p112Layout = new javax.swing.GroupLayout(p112);
        p112.setLayout(p112Layout);
        p112Layout.setHorizontalGroup(
            p112Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 18, Short.MAX_VALUE)
        );
        p112Layout.setVerticalGroup(
            p112Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 8, Short.MAX_VALUE)
        );

        gamePanel.add(p112);
        p112.setBounds(20, 420, 20, 10);

        mouselabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/getmecheese/r3.png"))); // NOI18N
        mouselabel.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        gamePanel.add(mouselabel);
        mouselabel.setBounds(0, 60, 24, 20);

        l2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/getmecheese/c1 (1).png"))); // NOI18N
        gamePanel.add(l2);
        l2.setBounds(300, 150, 30, 30);

        l1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/getmecheese/candy.png"))); // NOI18N
        gamePanel.add(l1);
        l1.setBounds(560, 220, 50, 40);

        cheeselabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/getmecheese/cheese.png"))); // NOI18N
        gamePanel.add(cheeselabel);
        cheeselabel.setBounds(710, 480, 30, 30);

        l3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/getmecheese/candy.png"))); // NOI18N
        gamePanel.add(l3);
        l3.setBounds(160, 110, 40, 40);

        l4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/getmecheese/candy.png"))); // NOI18N
        gamePanel.add(l4);
        l4.setBounds(90, 370, 40, 40);

        l5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/getmecheese/c4.png"))); // NOI18N
        gamePanel.add(l5);
        l5.setBounds(670, 220, 20, 20);

        l6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/getmecheese/candy.png"))); // NOI18N
        gamePanel.add(l6);
        l6.setBounds(410, 430, 40, 40);

        l7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/getmecheese/candy.png"))); // NOI18N
        gamePanel.add(l7);
        l7.setBounds(630, 430, 40, 40);

        l8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/getmecheese/c3.png"))); // NOI18N
        gamePanel.add(l8);
        l8.setBounds(20, 530, 30, 30);

        l9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/getmecheese/c1 (1).png"))); // NOI18N
        gamePanel.add(l9);
        l9.setBounds(360, 240, 30, 30);

        l10.setIcon(new javax.swing.ImageIcon(getClass().getResource("/getmecheese/c1 (1).png"))); // NOI18N
        gamePanel.add(l10);
        l10.setBounds(570, 100, 30, 30);

        l11.setIcon(new javax.swing.ImageIcon(getClass().getResource("/getmecheese/smilie.png"))); // NOI18N
        gamePanel.add(l11);
        l11.setBounds(610, 580, 20, 20);

        l12.setIcon(new javax.swing.ImageIcon(getClass().getResource("/getmecheese/c1 (1).png"))); // NOI18N
        gamePanel.add(l12);
        l12.setBounds(100, 30, 30, 20);

        l13.setIcon(new javax.swing.ImageIcon(getClass().getResource("/getmecheese/c1 (1).png"))); // NOI18N
        gamePanel.add(l13);
        l13.setBounds(500, 320, 30, 20);

        l14.setIcon(new javax.swing.ImageIcon(getClass().getResource("/getmecheese/coin.png"))); // NOI18N
        gamePanel.add(l14);
        l14.setBounds(40, 250, 30, 30);

        l15.setIcon(new javax.swing.ImageIcon(getClass().getResource("/getmecheese/c1 (1).png"))); // NOI18N
        gamePanel.add(l15);
        l15.setBounds(470, 20, 30, 30);

        l16.setIcon(new javax.swing.ImageIcon(getClass().getResource("/getmecheese/coin.png"))); // NOI18N
        gamePanel.add(l16);
        l16.setBounds(650, 510, 30, 30);

        l17.setIcon(new javax.swing.ImageIcon(getClass().getResource("/getmecheese/coin.png"))); // NOI18N
        gamePanel.add(l17);
        l17.setBounds(360, 60, 30, 30);

        l18.setIcon(new javax.swing.ImageIcon(getClass().getResource("/getmecheese/c3.png"))); // NOI18N
        gamePanel.add(l18);
        l18.setBounds(310, 360, 30, 30);

        l19.setIcon(new javax.swing.ImageIcon(getClass().getResource("/getmecheese/c3.png"))); // NOI18N
        gamePanel.add(l19);
        l19.setBounds(190, 440, 30, 30);

        l20.setIcon(new javax.swing.ImageIcon(getClass().getResource("/getmecheese/c3.png"))); // NOI18N
        gamePanel.add(l20);
        l20.setBounds(30, 590, 30, 30);

        l21.setIcon(new javax.swing.ImageIcon(getClass().getResource("/getmecheese/coin.png"))); // NOI18N
        gamePanel.add(l21);
        l21.setBounds(250, 560, 30, 30);

        l22.setIcon(new javax.swing.ImageIcon(getClass().getResource("/getmecheese/c4.png"))); // NOI18N
        gamePanel.add(l22);
        l22.setBounds(340, 30, 20, 20);

        l23.setIcon(new javax.swing.ImageIcon(getClass().getResource("/getmecheese/c4.png"))); // NOI18N
        gamePanel.add(l23);
        l23.setBounds(400, 500, 20, 20);

        l24.setIcon(new javax.swing.ImageIcon(getClass().getResource("/getmecheese/c4.png"))); // NOI18N
        gamePanel.add(l24);
        l24.setBounds(160, 310, 20, 20);

        l25.setIcon(new javax.swing.ImageIcon(getClass().getResource("/getmecheese/c4.png"))); // NOI18N
        gamePanel.add(l25);
        l25.setBounds(690, 30, 20, 20);

        l26.setIcon(new javax.swing.ImageIcon(getClass().getResource("/getmecheese/c4.png"))); // NOI18N
        gamePanel.add(l26);
        l26.setBounds(280, 280, 20, 20);

        l27.setIcon(new javax.swing.ImageIcon(getClass().getResource("/getmecheese/coin.png"))); // NOI18N
        gamePanel.add(l27);
        l27.setBounds(460, 180, 30, 30);

        l28.setIcon(new javax.swing.ImageIcon(getClass().getResource("/getmecheese/c3.png"))); // NOI18N
        gamePanel.add(l28);
        l28.setBounds(520, 560, 30, 30);

        backgroundPanel.add(gamePanel);
        gamePanel.setBounds(10, 50, 740, 630);

        timerPanel.setBackground(new java.awt.Color(153, 153, 0));
        timerPanel.setLayout(null);

        secs.setFont(new java.awt.Font("Times New Roman", 3, 24)); // NOI18N
        secs.setForeground(new java.awt.Color(0, 51, 51));
        secs.setText("00");
        timerPanel.add(secs);
        secs.setBounds(70, 0, 40, 40);

        milisecs.setFont(new java.awt.Font("Times New Roman", 3, 20)); // NOI18N
        milisecs.setForeground(new java.awt.Color(0, 51, 51));
        milisecs.setText("00");
        timerPanel.add(milisecs);
        milisecs.setBounds(150, 0, 50, 40);

        mint.setFont(new java.awt.Font("Times New Roman", 3, 30)); // NOI18N
        mint.setForeground(new java.awt.Color(0, 51, 51));
        mint.setText("00");
        timerPanel.add(mint);
        mint.setBounds(0, 0, 30, 40);

        mslabel.setFont(new java.awt.Font("Times New Roman", 2, 11)); // NOI18N
        mslabel.setText("MS");
        timerPanel.add(mslabel);
        mslabel.setBounds(200, 20, 20, 20);

        mintlabel.setFont(new java.awt.Font("Times New Roman", 2, 11)); // NOI18N
        mintlabel.setText("MINTS");
        timerPanel.add(mintlabel);
        mintlabel.setBounds(30, 20, 40, 20);

        secslabel.setFont(new java.awt.Font("Times New Roman", 2, 11)); // NOI18N
        secslabel.setText("SECS");
        timerPanel.add(secslabel);
        secslabel.setBounds(110, 20, 40, 20);

        backgroundPanel.add(timerPanel);
        timerPanel.setBounds(340, 10, 240, 40);

        pausebtn.setBackground(new java.awt.Color(204, 204, 255));
        pausebtn.setFont(new java.awt.Font("Broadway", 3, 18)); // NOI18N
        pausebtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/getmecheese/Pausebtn.png"))); // NOI18N
        pausebtn.setText("PAUSE");
        pausebtn.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        pausebtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                pausebtnActionPerformed(evt);
            }
        });
        backgroundPanel.add(pausebtn);
        pausebtn.setBounds(760, 280, 180, 70);

        scoretxt.setEditable(false);
        scoretxt.setBackground(new java.awt.Color(153, 153, 0));
        scoretxt.setFont(new java.awt.Font("Broadway", 3, 24)); // NOI18N
        scoretxt.setText(" BOUNCES: 00");
        scoretxt.setBorder(null);
        scoretxt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                scoretxtActionPerformed(evt);
            }
        });
        backgroundPanel.add(scoretxt);
        scoretxt.setBounds(750, 140, 190, 40);

        exitbuttton.setBackground(new java.awt.Color(204, 204, 255));
        exitbuttton.setFont(new java.awt.Font("Broadway", 3, 18)); // NOI18N
        exitbuttton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/getmecheese/cut.png"))); // NOI18N
        exitbuttton.setText("EXIT");
        exitbuttton.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        exitbuttton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                exitbutttonActionPerformed(evt);
            }
        });
        backgroundPanel.add(exitbuttton);
        exitbuttton.setBounds(760, 610, 180, 70);

        restrartbtn.setBackground(new java.awt.Color(204, 204, 255));
        restrartbtn.setFont(new java.awt.Font("Broadway", 3, 18)); // NOI18N
        restrartbtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/getmecheese/restart.png"))); // NOI18N
        restrartbtn.setText("RESTART");
        restrartbtn.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        restrartbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                restrartbtnActionPerformed(evt);
            }
        });
        backgroundPanel.add(restrartbtn);
        restrartbtn.setBounds(760, 530, 180, 70);

        jLabel3.setFont(new java.awt.Font("Broadway", 3, 24)); // NOI18N
        jLabel3.setText("TIMER :");
        backgroundPanel.add(jLabel3);
        jLabel3.setBounds(200, 10, 130, 40);

        hintbtn.setBackground(new java.awt.Color(204, 204, 255));
        hintbtn.setFont(new java.awt.Font("Broadway", 3, 18)); // NOI18N
        hintbtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/getmecheese/hint.png"))); // NOI18N
        hintbtn.setText("HINT");
        hintbtn.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        hintbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                hintbtnActionPerformed(evt);
            }
        });
        backgroundPanel.add(hintbtn);
        hintbtn.setBounds(760, 200, 180, 70);

        backbtn.setBackground(new java.awt.Color(153, 153, 0));
        backbtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/getmecheese/back.png"))); // NOI18N
        backbtn.setBorder(null);
        backbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                backbtnActionPerformed(evt);
            }
        });
        backgroundPanel.add(backbtn);
        backbtn.setBounds(10, 10, 40, 40);

        stop.setBackground(new java.awt.Color(153, 153, 0));
        stop.setIcon(new javax.swing.ImageIcon(getClass().getResource("/getmecheese/off.png"))); // NOI18N
        stop.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        stop.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                stopActionPerformed(evt);
            }
        });
        backgroundPanel.add(stop);
        stop.setBounds(850, 50, 70, 60);

        play.setBackground(new java.awt.Color(153, 153, 0));
        play.setIcon(new javax.swing.ImageIcon(getClass().getResource("/getmecheese/on (1).png"))); // NOI18N
        play.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        play.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                playActionPerformed(evt);
            }
        });
        backgroundPanel.add(play);
        play.setBounds(770, 50, 70, 60);

        getContentPane().add(backgroundPanel);
        backgroundPanel.setBounds(0, 0, 950, 690);

        setSize(new java.awt.Dimension(966, 728));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void pausebtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_pausebtnActionPerformed
        status = false;
        JOptionPane.showMessageDialog(null, "RESUME");
        this.requestFocus();
        
        timeLimit();
        
    }//GEN-LAST:event_pausebtnActionPerformed

    private void exitbutttonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_exitbutttonActionPerformed
      System.exit(0);
    }//GEN-LAST:event_exitbutttonActionPerformed

    private void restrartbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_restrartbtnActionPerformed
      AudioPlayer.player.stop(audio);
        restartCondition();
    }//GEN-LAST:event_restrartbtnActionPerformed

    private void scoretxtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_scoretxtActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_scoretxtActionPerformed

    private void hintbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_hintbtnActionPerformed
       new HintFrame().show();
    }//GEN-LAST:event_hintbtnActionPerformed

    private void backbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_backbtnActionPerformed
       this.setVisible(false);
       new MazeStartFrame().show();
    }//GEN-LAST:event_backbtnActionPerformed

    private void stopActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_stopActionPerformed
       AudioPlayer.player.stop(audio);
       this.requestFocus();
    }//GEN-LAST:event_stopActionPerformed

    private void playActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_playActionPerformed
    AudioPlayer.player.stop(audio);
        mazeSound();  
        this.requestFocus();
    }//GEN-LAST:event_playActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(DesignMainFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(DesignMainFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(DesignMainFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(DesignMainFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new DesignMainFrame().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton backbtn;
    private javax.swing.JPanel backgroundPanel;
    private javax.swing.JLabel cheeselabel;
    private javax.swing.JButton exitbuttton;
    private javax.swing.JPanel gamePanel;
    private javax.swing.JButton hintbtn;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPanel jPanel80;
    private javax.swing.JPanel jPanel81;
    private javax.swing.JLabel l1;
    private javax.swing.JLabel l10;
    private javax.swing.JLabel l11;
    private javax.swing.JLabel l12;
    private javax.swing.JLabel l13;
    private javax.swing.JLabel l14;
    private javax.swing.JLabel l15;
    private javax.swing.JLabel l16;
    private javax.swing.JLabel l17;
    private javax.swing.JLabel l18;
    private javax.swing.JLabel l19;
    private javax.swing.JLabel l2;
    private javax.swing.JLabel l20;
    private javax.swing.JLabel l21;
    private javax.swing.JLabel l22;
    private javax.swing.JLabel l23;
    private javax.swing.JLabel l24;
    private javax.swing.JLabel l25;
    private javax.swing.JLabel l26;
    private javax.swing.JLabel l27;
    private javax.swing.JLabel l28;
    private javax.swing.JLabel l3;
    private javax.swing.JLabel l4;
    private javax.swing.JLabel l5;
    private javax.swing.JLabel l6;
    private javax.swing.JLabel l7;
    private javax.swing.JLabel l8;
    private javax.swing.JLabel l9;
    private javax.swing.JLabel milisecs;
    private javax.swing.JLabel mint;
    private javax.swing.JLabel mintlabel;
    private javax.swing.JLabel mouselabel;
    private javax.swing.JLabel mslabel;
    private javax.swing.JPanel p1;
    private javax.swing.JPanel p10;
    private javax.swing.JPanel p100;
    private javax.swing.JPanel p101;
    private javax.swing.JPanel p102;
    private javax.swing.JPanel p103;
    private javax.swing.JPanel p104;
    private javax.swing.JPanel p105;
    private javax.swing.JPanel p106;
    private javax.swing.JPanel p107;
    private javax.swing.JPanel p108;
    private javax.swing.JPanel p109;
    private javax.swing.JPanel p11;
    private javax.swing.JPanel p110;
    private javax.swing.JPanel p111;
    private javax.swing.JPanel p112;
    private javax.swing.JPanel p12;
    private javax.swing.JPanel p13;
    private javax.swing.JPanel p14;
    private javax.swing.JPanel p15;
    private javax.swing.JPanel p16;
    private javax.swing.JPanel p17;
    private javax.swing.JPanel p18;
    private javax.swing.JPanel p19;
    private javax.swing.JPanel p2;
    private javax.swing.JPanel p20;
    private javax.swing.JPanel p21;
    private javax.swing.JPanel p22;
    private javax.swing.JPanel p23;
    private javax.swing.JPanel p24;
    private javax.swing.JPanel p25;
    private javax.swing.JPanel p26;
    private javax.swing.JPanel p27;
    private javax.swing.JPanel p28;
    private javax.swing.JPanel p29;
    private javax.swing.JPanel p3;
    private javax.swing.JPanel p30;
    private javax.swing.JPanel p31;
    private javax.swing.JPanel p32;
    private javax.swing.JPanel p33;
    private javax.swing.JPanel p34;
    private javax.swing.JPanel p35;
    private javax.swing.JPanel p36;
    private javax.swing.JPanel p37;
    private javax.swing.JPanel p38;
    private javax.swing.JPanel p39;
    private javax.swing.JPanel p4;
    private javax.swing.JPanel p40;
    private javax.swing.JPanel p41;
    private javax.swing.JPanel p42;
    private javax.swing.JPanel p43;
    private javax.swing.JPanel p44;
    private javax.swing.JPanel p45;
    private javax.swing.JPanel p46;
    private javax.swing.JPanel p47;
    private javax.swing.JPanel p48;
    private javax.swing.JPanel p49;
    private javax.swing.JPanel p5;
    private javax.swing.JPanel p50;
    private javax.swing.JPanel p51;
    private javax.swing.JPanel p52;
    private javax.swing.JPanel p53;
    private javax.swing.JPanel p54;
    private javax.swing.JPanel p55;
    private javax.swing.JPanel p56;
    private javax.swing.JPanel p57;
    private javax.swing.JPanel p58;
    private javax.swing.JPanel p59;
    private javax.swing.JPanel p6;
    private javax.swing.JPanel p60;
    private javax.swing.JPanel p61;
    private javax.swing.JPanel p62;
    private javax.swing.JPanel p63;
    private javax.swing.JPanel p64;
    private javax.swing.JPanel p65;
    private javax.swing.JPanel p66;
    private javax.swing.JPanel p67;
    private javax.swing.JPanel p68;
    private javax.swing.JPanel p69;
    private javax.swing.JPanel p7;
    private javax.swing.JPanel p70;
    private javax.swing.JPanel p71;
    private javax.swing.JPanel p72;
    private javax.swing.JPanel p73;
    private javax.swing.JPanel p74;
    private javax.swing.JPanel p75;
    private javax.swing.JPanel p76;
    private javax.swing.JPanel p77;
    private javax.swing.JPanel p78;
    private javax.swing.JPanel p79;
    private javax.swing.JPanel p8;
    private javax.swing.JPanel p80;
    private javax.swing.JPanel p81;
    private javax.swing.JPanel p82;
    private javax.swing.JPanel p83;
    private javax.swing.JPanel p84;
    private javax.swing.JPanel p85;
    private javax.swing.JPanel p86;
    private javax.swing.JPanel p87;
    private javax.swing.JPanel p89;
    private javax.swing.JPanel p9;
    private javax.swing.JPanel p90;
    private javax.swing.JPanel p91;
    private javax.swing.JPanel p92;
    private javax.swing.JPanel p93;
    private javax.swing.JPanel p94;
    private javax.swing.JPanel p95;
    private javax.swing.JPanel p96;
    private javax.swing.JPanel p97;
    private javax.swing.JPanel p98;
    private javax.swing.JPanel p99;
    private javax.swing.JButton pausebtn;
    private javax.swing.JButton play;
    private javax.swing.JButton restrartbtn;
    private javax.swing.JTextField scoretxt;
    private javax.swing.JLabel secs;
    private javax.swing.JLabel secslabel;
    private javax.swing.JButton stop;
    private javax.swing.JPanel timerPanel;
    // End of variables declaration//GEN-END:variables

@Override
    public void keyTyped(KeyEvent e) {
            System.out.println("KeyTyped"); 
        // throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

 @Override
    public void keyPressed(KeyEvent e) {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
      int key = e.getKeyCode();
         moveStatus=true;
          if(key==KeyEvent.VK_UP){
              
               for(int i =0 ; i<p.size(); i++){
               p_rect = new Rectangle(p.get(i).getX(), p.get(i).getY()-range+15, p.get(i).getWidth(), p.get(i).getHeight()); 
               m_rect = new Rectangle(mouselabel.getX(), mouselabel.getY(), mouselabel.getWidth(), mouselabel.getHeight()); 
              
                   if(p_rect.intersects(m_rect)){
                     alertSound();
                     moveStatus = false;
                 
                   }
               }
                bonusCondition();
               System.out.println(moveStatus);
                     if(moveStatus){
                     System.out.println("up key");        
                    mouselabel.setBounds(mouselabel.getX(), mouselabel.getY()-range, mouselabel.getWidth(), mouselabel.getHeight());
                     score+=1;   
                     scoretxt.setText("BOUNCES:  "+score);
                     }
                    
                    }
                           
                 if(key==KeyEvent.VK_DOWN){
                     for(int i =0 ; i<p.size(); i++){
                       p_rect = new Rectangle(p.get(i).getX(), p.get(i).getY()+range-15, p.get(i).getWidth(), p.get(i).getHeight()); 
                       m_rect = new Rectangle(mouselabel.getX(), mouselabel.getY(), mouselabel.getWidth(), mouselabel.getHeight()); 
                       if(p_rect.intersects(m_rect)){
                         alertSound();
                        moveStatus = false;
                         
                       
                   }
                      }
                     bonusCondition();
                       System.out.println(moveStatus);
                     if(moveStatus){
                     System.out.println("down key");        
                    mouselabel.setBounds(mouselabel.getX(), mouselabel.getY()+range, mouselabel.getWidth(), mouselabel.getHeight());
                     score+=1;   
                     scoretxt.setText("BOUNCES:  "+score);     
                             }
                 }
                        
                    if(key==KeyEvent.VK_RIGHT){
                       for(int i =0 ; i<p.size(); i++){
                       p_rect = new Rectangle(p.get(i).getX()+range-15, p.get(i).getY(), p.get(i).getWidth(), p.get(i).getHeight()); 
                       m_rect = new Rectangle(mouselabel.getX(), mouselabel.getY(), mouselabel.getWidth(), mouselabel.getHeight()); 
                       if(p_rect.intersects(m_rect)){
                          alertSound();
                        moveStatus = false;
                   }
                        }
                        bonusCondition();
                        System.out.println(moveStatus);
                     if(moveStatus){
                     System.out.println("right key");        
                    mouselabel.setBounds(mouselabel.getX()+range, mouselabel.getY(), mouselabel.getWidth(), mouselabel.getHeight());
                      score+=1;    
                     scoretxt.setText("BOUNCES:  "+score);      
                     }
                     }     
                       if(key==KeyEvent.VK_LEFT){
                         for(int i =0 ; i<p.size(); i++){
                       p_rect = new Rectangle(p.get(i).getX()-range+15, p.get(i).getY(), p.get(i).getWidth(), p.get(i).getHeight()); 
                       m_rect = new Rectangle(mouselabel.getX(), mouselabel.getY(), mouselabel.getWidth(), mouselabel.getHeight()); 
                       if(p_rect.intersects(m_rect)){
                            alertSound();
                           moveStatus = false;
                        
                   }
                         }
                          bonusCondition();
                          System.out.println(moveStatus);
                     if(moveStatus){
                     System.out.println("left key");        
                    mouselabel.setBounds(mouselabel.getX()-range, mouselabel.getY(), mouselabel.getWidth(), mouselabel.getHeight());
                      score+=1;      
                     scoretxt.setText("BOUNCES:  "+score);        
                    }
                       }
                        
                 
            
    }

 @Override
    public void keyReleased(KeyEvent e) {
      //  throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
