package mobile_inventry;
public class Mobile_Inventry {
public static void main(String[] args) {
 Splash_Screen s=  new Splash_Screen();
 s.setVisible(true);
 try{
 for(int loading =0;loading<=100; loading++){
  Thread.sleep(40);
  s.load.setText(Integer.toString(loading)+"%");
  s.load1.setText(Integer.toString(loading)+"%");
  s.jProgressBar1.setValue(loading);
  s.jProgressBar2.setValue(loading);
  
  if(loading==100){
  s.setVisible(false);
  new Mobile_Products().show();
  }
  }
  }catch(Exception ex){
System.out.println(ex.getMessage());
 }
    }
 }
