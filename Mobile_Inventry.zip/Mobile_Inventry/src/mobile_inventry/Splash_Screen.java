package mobile_inventry;
public class Splash_Screen extends javax.swing.JFrame {
    public Splash_Screen() {
        initComponents();
        setSize(730,630);
        setVisible(true);
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jProgressBar1 = new javax.swing.JProgressBar();
        jProgressBar2 = new javax.swing.JProgressBar();
        load = new javax.swing.JLabel();
        load1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        setUndecorated(true);
        getContentPane().setLayout(null);

        jPanel1.setBackground(new java.awt.Color(0, 0, 0));
        jPanel1.setForeground(new java.awt.Color(255, 255, 255));
        jPanel1.setLayout(null);

        jProgressBar1.setForeground(new java.awt.Color(0, 153, 0));
        jPanel1.add(jProgressBar1);
        jProgressBar1.setBounds(0, 0, 730, 40);

        jProgressBar2.setForeground(new java.awt.Color(0, 204, 204));
        jPanel1.add(jProgressBar2);
        jProgressBar2.setBounds(110, 310, 510, 30);

        load.setBackground(new java.awt.Color(0, 0, 0));
        load.setFont(new java.awt.Font("Times New Roman", 3, 18)); // NOI18N
        load.setForeground(new java.awt.Color(0, 153, 153));
        jPanel1.add(load);
        load.setBounds(350, 270, 60, 40);

        load1.setBackground(new java.awt.Color(0, 0, 0));
        load1.setFont(new java.awt.Font("Times New Roman", 3, 18)); // NOI18N
        load1.setForeground(new java.awt.Color(0, 153, 51));
        jPanel1.add(load1);
        load1.setBounds(470, 140, 50, 40);

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/mobile_inventry/another.gif"))); // NOI18N
        jPanel1.add(jLabel2);
        jLabel2.setBounds(110, 40, 512, 300);

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/mobile_inventry/loading.gif"))); // NOI18N
        jPanel1.add(jLabel1);
        jLabel1.setBounds(170, 350, 390, 240);
        jPanel1.add(jLabel4);
        jLabel4.setBounds(0, 0, 730, 600);

        getContentPane().add(jPanel1);
        jPanel1.setBounds(0, 0, 730, 600);

        setSize(new java.awt.Dimension(730, 596));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Splash_Screen.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Splash_Screen.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Splash_Screen.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Splash_Screen.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Splash_Screen().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel1;
    public javax.swing.JProgressBar jProgressBar1;
    public javax.swing.JProgressBar jProgressBar2;
    public javax.swing.JLabel load;
    public javax.swing.JLabel load1;
    // End of variables declaration//GEN-END:variables
}
