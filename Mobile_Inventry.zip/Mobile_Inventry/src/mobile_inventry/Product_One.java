package mobile_inventry;
import java.sql.*;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
public class Product_One extends javax.swing.JFrame {
    public Product_One() {
        initComponents();
       }
  @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        panel_oppo = new javax.swing.JPanel();
        oppof7 = new javax.swing.JButton();
        oppof5 = new javax.swing.JButton();
        f5youth = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("OPPO PRODUCTS.");
        getContentPane().setLayout(null);

        panel_oppo.setBackground(new java.awt.Color(255, 255, 255));
        panel_oppo.setLayout(null);

        oppof7.setBackground(new java.awt.Color(51, 0, 153));
        oppof7.setForeground(new java.awt.Color(51, 0, 153));
        oppof7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/mobile_inventry/F7.jpg"))); // NOI18N
        oppof7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                oppof7ActionPerformed(evt);
            }
        });
        panel_oppo.add(oppof7);
        oppof7.setBounds(30, 20, 250, 410);

        oppof5.setBackground(new java.awt.Color(51, 0, 153));
        oppof5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/mobile_inventry/F5.jpg"))); // NOI18N
        oppof5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                oppof5ActionPerformed(evt);
            }
        });
        panel_oppo.add(oppof5);
        oppof5.setBounds(310, 70, 270, 410);

        f5youth.setBackground(new java.awt.Color(51, 0, 153));
        f5youth.setIcon(new javax.swing.ImageIcon(getClass().getResource("/mobile_inventry/F5 YOUTH.jpg"))); // NOI18N
        f5youth.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                f5youthActionPerformed(evt);
            }
        });
        panel_oppo.add(f5youth);
        f5youth.setBounds(610, 20, 250, 410);

        getContentPane().add(panel_oppo);
        panel_oppo.setBounds(0, 0, 890, 510);

        setSize(new java.awt.Dimension(907, 551));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void oppof7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_oppof7ActionPerformed
    new oppoF7_specification().show();
    }//GEN-LAST:event_oppof7ActionPerformed

    private void oppof5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_oppof5ActionPerformed
           new oppoF5_specification().show();
    }//GEN-LAST:event_oppof5ActionPerformed

    private void f5youthActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_f5youthActionPerformed
         new oppoF5YOUTH_specification().show();
    }//GEN-LAST:event_f5youthActionPerformed

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Product_One.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Product_One.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Product_One.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Product_One.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Product_One().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton f5youth;
    private javax.swing.JButton oppof5;
    private javax.swing.JButton oppof7;
    private javax.swing.JPanel panel_oppo;
    // End of variables declaration//GEN-END:variables
}
