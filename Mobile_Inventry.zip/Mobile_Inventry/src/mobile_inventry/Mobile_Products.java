package mobile_inventry;

import javax.swing.JOptionPane;

public class Mobile_Products extends javax.swing.JFrame {

    public Mobile_Products() {
        initComponents();
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        m_oppo = new javax.swing.JButton();
        l_oppo = new javax.swing.JButton();
        m_huawii = new javax.swing.JButton();
        samsung = new javax.swing.JButton();
        m_nokia = new javax.swing.JButton();
        l_huawii = new javax.swing.JButton();
        l_nokia = new javax.swing.JButton();
        search = new javax.swing.JLabel();
        m_search = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("MOBILE INVENTORY!");
        getContentPane().setLayout(null);

        m_oppo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/mobile_inventry/oppo.jpg"))); // NOI18N
        m_oppo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                m_oppoActionPerformed(evt);
            }
        });
        getContentPane().add(m_oppo);
        m_oppo.setBounds(20, 40, 330, 300);

        l_oppo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/mobile_inventry/oppologo.jpg"))); // NOI18N
        l_oppo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                l_oppoActionPerformed(evt);
            }
        });
        getContentPane().add(l_oppo);
        l_oppo.setBounds(20, 340, 330, 80);

        m_huawii.setIcon(new javax.swing.ImageIcon(getClass().getResource("/mobile_inventry/hawaii_img.jpg"))); // NOI18N
        m_huawii.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                m_huawiiActionPerformed(evt);
            }
        });
        getContentPane().add(m_huawii);
        m_huawii.setBounds(750, 180, 380, 500);

        samsung.setIcon(new javax.swing.ImageIcon(getClass().getResource("/mobile_inventry/samsang1.png"))); // NOI18N
        samsung.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                samsungActionPerformed(evt);
            }
        });
        getContentPane().add(samsung);
        samsung.setBounds(70, 440, 590, 240);

        m_nokia.setIcon(new javax.swing.ImageIcon(getClass().getResource("/mobile_inventry/nokkia_img.jpg"))); // NOI18N
        m_nokia.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                m_nokiaActionPerformed(evt);
            }
        });
        getContentPane().add(m_nokia);
        m_nokia.setBounds(480, 10, 220, 420);

        l_huawii.setBackground(new java.awt.Color(0, 0, 0));
        l_huawii.setIcon(new javax.swing.ImageIcon(getClass().getResource("/mobile_inventry/huwaiilogo1.gif"))); // NOI18N
        l_huawii.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                l_huawiiActionPerformed(evt);
            }
        });
        getContentPane().add(l_huawii);
        l_huawii.setBounds(750, 90, 380, 90);

        l_nokia.setBackground(new java.awt.Color(255, 255, 255));
        l_nokia.setIcon(new javax.swing.ImageIcon(getClass().getResource("/mobile_inventry/nokialogo2.gif"))); // NOI18N
        l_nokia.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                l_nokiaActionPerformed(evt);
            }
        });
        getContentPane().add(l_nokia);
        l_nokia.setBounds(380, 10, 100, 420);

        search.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        search.setForeground(new java.awt.Color(255, 255, 255));
        search.setText("SEARCH: ");
        getContentPane().add(search);
        search.setBounds(750, 30, 100, 40);

        m_search.setFont(new java.awt.Font("Times New Roman", 3, 18)); // NOI18N
        m_search.setForeground(new java.awt.Color(0, 0, 153));
        getContentPane().add(m_search);
        m_search.setBounds(840, 30, 170, 40);

        jButton1.setBackground(new java.awt.Color(51, 0, 204));
        jButton1.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jButton1.setForeground(new java.awt.Color(255, 255, 255));
        jButton1.setText("SEARCH");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1);
        jButton1.setBounds(1010, 30, 110, 40);

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/mobile_inventry/back_mobile.jpg"))); // NOI18N
        getContentPane().add(jLabel1);
        jLabel1.setBounds(0, 0, 1140, 730);

        setSize(new java.awt.Dimension(1154, 728));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void m_huawiiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_m_huawiiActionPerformed
          new Product_Huawii().show();     
    }//GEN-LAST:event_m_huawiiActionPerformed

    private void m_oppoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_m_oppoActionPerformed
       new Product_One().show();
        
    }//GEN-LAST:event_m_oppoActionPerformed

    private void m_nokiaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_m_nokiaActionPerformed
      new Product_Nokia().show();     
    }//GEN-LAST:event_m_nokiaActionPerformed

    private void l_oppoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_l_oppoActionPerformed
         new Product_One().show();
    }//GEN-LAST:event_l_oppoActionPerformed

    private void l_nokiaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_l_nokiaActionPerformed
       new Product_Nokia().show();     
    }//GEN-LAST:event_l_nokiaActionPerformed

    private void l_huawiiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_l_huawiiActionPerformed
       new Product_Huawii().show();     
    }//GEN-LAST:event_l_huawiiActionPerformed

    private void samsungActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_samsungActionPerformed
        new Product_Samsung().show();
    }//GEN-LAST:event_samsungActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        String s;
        s= m_search.getText();
        if(s.equalsIgnoreCase("oppo")){
        new Product_One().show();
        }
        else if(s.equalsIgnoreCase("f5")){
        new oppoF5_specification().show();
        }
        else if(s.equalsIgnoreCase("f7")){
        new oppoF7_specification().show();
        }
        else if(s.equalsIgnoreCase("f5 youth") || s.equalsIgnoreCase("f5youth")){
        new oppoF5YOUTH_specification().show();
        }
        else if(s.equalsIgnoreCase("nokia")){
        new Product_Nokia().show();
        }
        else if(s.equalsIgnoreCase("nokia 5.1")){
        new nokia_51_specification().show();
        }
        else if(s.equalsIgnoreCase("nokia 3.1")){
        new nokia_31_specification().show();
        }
        else if(s.equalsIgnoreCase("nokia x6")){
        new nokia_X6_specification().show();
        }
        else if(s.equalsIgnoreCase("samsung")){
        new Product_Samsung().show();
        }
        else if(s.equalsIgnoreCase("galaxy j4")){
        new galaxyJ4_specification().show();
        }
        else  if(s.equalsIgnoreCase("galaxy j6")){
        new galaxyJ6_specification().show();
        }
        else if(s.equalsIgnoreCase("galaxy A6 plus")){
        new galaxyA6plus_specification().show();
        }
        else if(s.equalsIgnoreCase("huawei")){
        new Product_Huawii().show();
        }
        else if(s.equalsIgnoreCase("P20 LITE")){
        new huaweiP20LITE_specification().show();
        }
        else if(s.equalsIgnoreCase("P20 PRO")){
        new huaweiP20PRO_specification().show();
        }
        else  if(s.equalsIgnoreCase("MATE 10")){
        new huaweiMATE10_specification().show();
        }
        else{
            JOptionPane.showMessageDialog(null, "=====PRODUCT INFORMATION DOES NOT EXISTS !=====");
          }
    }//GEN-LAST:event_jButton1ActionPerformed

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Mobile_Products.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Mobile_Products.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Mobile_Products.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Mobile_Products.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Mobile_Products().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JButton l_huawii;
    private javax.swing.JButton l_nokia;
    private javax.swing.JButton l_oppo;
    private javax.swing.JButton m_huawii;
    private javax.swing.JButton m_nokia;
    private javax.swing.JButton m_oppo;
    private javax.swing.JTextField m_search;
    private javax.swing.JButton samsung;
    private javax.swing.JLabel search;
    // End of variables declaration//GEN-END:variables
}
