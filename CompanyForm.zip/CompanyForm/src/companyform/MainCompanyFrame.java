package companyform;
import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.sql.*;
import java.io.*;
import java.util.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ButtonGroup;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import net.proteanit.sql.DbUtils;
public class MainCompanyFrame extends javax.swing.JFrame {
    Connection conn;  
ResultSet rs;
String e_id;
 String name=null;
 String gender=null;
 int e_age;
 String blood_group= null;
 String contact_no=null;
 String qualification= null;
 String date_of_join= null;
 String address= null;
  String imgPath=null;
     /**
     * Creates new form MainCompanyFrame
     */
    public MainCompanyFrame() {
        initComponents();
        setSize(875,720);
        this.E_idTextField.disable();
        ButtonGroup bg = new ButtonGroup();
        bg.add(male_radiobutton);
         bg.add(female_radiobutton);
        try{
          Class.forName("oracle.jdbc.driver.OracleDriver");
             conn= DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","BHAGIA SHERI","123456789");
            if(conn!=null){
                System.out.println("Connection Succesfullly!");
            }
        }catch(Exception ex){
                System.out.println(ex.getMessage());
                }
           tableData();
    }
    
    public ImageIcon ResizeImage(String ImagePath, byte[ ] pic ) {
      
        ImageIcon MyImage = null;
        if(ImagePath!=null){
        MyImage = new ImageIcon(ImagePath);
        }
        else{
        MyImage = new ImageIcon(pic);
        }
        Image img = MyImage.getImage();
       Image newImg = img.getScaledInstance(img_label.getWidth(), img_label.getHeight(), Image.SCALE_AREA_AVERAGING);
       ImageIcon image = new ImageIcon(newImg); 
       return image;
    
    }
    
  
  public void validationForInsertion() throws SQLException{
       name=this.E_nameTextfield.getText();
       contact_no= this.contact_txtfield.getText();
  Statement st = conn.createStatement();
  String query = "Select contact_no from company_form where contact_no='"+contact_no+"'";
  rs= st.executeQuery(query);
  if(rs.next()){
  JOptionPane.showMessageDialog(null, "DATA ALREADY EXIST !!!");
  }
  else{
  showData();
  }
  }     
  public void showData(){
      
 name=this.E_nameTextfield.getText();
 e_age=Integer.parseInt(this.age_textfield.getText());
 blood_group=this.bloodgroup_textfield.getText();
 contact_no= this.contact_txtfield.getText();
 qualification=this.qualification_dropdown.getSelectedItem().toString();
 address=this.address_txtfield.getText();
 date_of_join = ((JTextField) e_doj.getDateEditor().getUiComponent()).getText();
if(imgPath !=null){
    
   try {
         InputStream img = new FileInputStream(new File(imgPath));
        String query="insert into company_form(Employee_ID,Name,Gender,age,blood_group,Contact_no,qualification,doj,address,photo)values(COMPANY_FORM_SEQUENCE.NEXTVAL,?,?,?,?,?,?,?,?,?)" ;
         PreparedStatement ps=conn.prepareStatement(query);  
         ps.setString(1, name);
         ps.setString(2, gender);
         ps.setString(3, Integer.toString(e_age));
         ps.setString(4, blood_group);
         ps.setString(5, contact_no);
         ps.setString(6, qualification);
         ps.setString(7, date_of_join);
         ps.setString(8, address);
         ps.setBlob(9, img);
        imgpath.setText(imgPath);
        int row=ps.executeUpdate();
           System.out.println("name  "+name+" gender "+gender+" age "+e_age+" blood group "+blood_group+" doj "+date_of_join+" img "+img);
           if(row>0){
              System.out.println("DATA INSERTED !");
              tableData();
   }
          else{
          System.out.println("DATA NOT INSERTED !");
          }
      
         }
     catch (Exception ex) {
     System.out.println(ex.getMessage());
     }
} else{
       JOptionPane.showMessageDialog(null, "IMAGE IS NOT SELECTED !!!");
}
imgPath=null;
  }
  public void tableData(){
    JTableHeader jh = company_table.getTableHeader();
    jh.setBackground(Color.BLACK);
    jh.setForeground(Color.WHITE);
    jh.setFont(new Font ("Times New Roman", Font.PLAIN , 14));
    try{
   Statement   stm = conn.createStatement();
          rs = stm.executeQuery("select * from company_form"); 
          company_table.setModel(DbUtils.resultSetToTableModel(rs));
    }catch(Exception e){
     System.out.println(e.getMessage());
    }
    }
    
  public void updateRow() throws ParseException{
      
  if(company_table.getSelectedRowCount()==0){
  JOptionPane.showMessageDialog(null,"SELECT ANY ROW FIRST !");
  }
  else if(company_table.getSelectedRowCount()==1){
  img_label.setIcon(null);
  DefaultTableModel model = (DefaultTableModel)company_table.getModel();
  int selectedRowIndex = company_table.getSelectedRow();
  E_idTextField.setText(model.getValueAt(selectedRowIndex, 0).toString());
  E_nameTextfield.setText(model.getValueAt(selectedRowIndex, 1).toString());
  gender =model.getValueAt(selectedRowIndex, 2).toString();
  if(gender.equalsIgnoreCase("male")){
  male_radiobutton.setSelected(true);
  }
  else{
      female_radiobutton.setSelected(true);
  }
  age_textfield.setText(model.getValueAt(selectedRowIndex, 3).toString());
  bloodgroup_textfield.setText(model.getValueAt(selectedRowIndex, 4).toString());
  contact_txtfield.setText(model.getValueAt(selectedRowIndex, 5).toString());
  qualification_dropdown.setSelectedItem(model.getValueAt(selectedRowIndex, 6).toString());
  java.util.Date date = new SimpleDateFormat("yyyy-MM-dd").parse((String)model.getValueAt(selectedRowIndex, 7).toString());
  e_doj.setDate(date);
  address_txtfield.setText(model.getValueAt(selectedRowIndex, 8).toString());
  imgpath.setText(model.getValueAt(selectedRowIndex, 9).toString());
  }
 else{
  JOptionPane.showMessageDialog(null, "ONE ROW CAN BE UPDATED AT A TIME !");
  }
  }
  
  public void deleteRow(){
  if(company_table.getSelectedRowCount()==0){
  JOptionPane.showMessageDialog(null,"SELECT ANY ROW FIRST !");
  }
  else if(company_table.getSelectedRowCount()==1){
  DefaultTableModel model = (DefaultTableModel)company_table.getModel();
  int selectedRowIndex = company_table.getSelectedRow();
  e_id = model.getValueAt(selectedRowIndex, 0).toString();
   try {
         Statement st=conn.createStatement();
          String query="DELETE FROM COMPANY_FORM WHERE EMPLOYEE_ID='"+e_id+"'" ;
         int row=st.executeUpdate(query);
           if(row>0){
              System.out.println("DATA DELETED !");
              tableData();
           }
          else{
          System.out.println("DATA NOT DELETED !");
          }
          }
     catch (Exception ex) {
     System.out.println(ex.getMessage());
     }
  }
  else{
  JOptionPane.showMessageDialog(null, "ONE ROW CAN BE DELETED AT A TIME !");
  }
  }
  public void saveRow(){
  e_id = this.E_idTextField.getText();
  name=this.E_nameTextfield.getText();
 e_age=Integer.parseInt(this.age_textfield.getText());
 blood_group=this.bloodgroup_textfield.getText();
 contact_no= this.contact_txtfield.getText();
 qualification=this.qualification_dropdown.getSelectedItem().toString();
date_of_join = ((JTextField) e_doj.getDateEditor().getUiComponent()).getText();
address=this.address_txtfield.getText();
if(imgPath !=null){
    try{
        InputStream img = new FileInputStream(imgPath);
        String query= "update company_form set name=? , gender= ? , age=? , blood_group=? , contact_no=? , qualification=?, doj=?,address=?, photo=? WHERE EMPLOYEE_ID="+e_id+"";
           PreparedStatement  ps = conn.prepareStatement(query);
              ps.setString(1, name);
         ps.setString(2, gender);
         ps.setString(3, Integer.toString(e_age));
         ps.setString(4, blood_group);
         ps.setString(5, contact_no);
         ps.setString(6, qualification);
         ps.setString(7, date_of_join);
         ps.setString(8, address);
         ps.setBlob(9, img);
        imgpath.setText(imgPath);
          int rows=  ps.executeUpdate();
           if(rows>0){
              System.out.println("DATA UPDATED !");  
             tableData();
           }
          else{
           System.out.println("DATA NOT UPDATED !");
           }
        }catch(Exception e){
           System.out.println(e.getMessage());
        }   
}else{
try{
        String query= "update company_form set name=? , gender= ? , age=? , blood_group=? , contact_no=? , qualification=?, doj=?,address=? WHERE EMPLOYEE_ID="+e_id+"";
           PreparedStatement  ps = conn.prepareStatement(query);
              ps.setString(1, name);
         ps.setString(2, gender);
         ps.setString(3, Integer.toString(e_age));
         ps.setString(4, blood_group);
         ps.setString(5, contact_no);
         ps.setString(6, qualification);
         ps.setString(7, date_of_join);
         ps.setString(8, address);
          int rows=  ps.executeUpdate();
           if(rows>0){
              System.out.println("DATA UPDATED !");  
             tableData();
           }
          else{
           System.out.println("DATA NOT UPDATED !");
           }
        }catch(Exception e){
           System.out.println(e.getMessage());
        }  
}
   }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        E_idTextField = new javax.swing.JTextField();
        E_nameTextfield = new javax.swing.JTextField();
        male_radiobutton = new javax.swing.JRadioButton();
        female_radiobutton = new javax.swing.JRadioButton();
        age_textfield = new javax.swing.JTextField();
        bloodgroup_textfield = new javax.swing.JTextField();
        contact_txtfield = new javax.swing.JTextField();
        qualification_dropdown = new javax.swing.JComboBox();
        jScrollPane1 = new javax.swing.JScrollPane();
        address_txtfield = new javax.swing.JTextArea();
        img_label = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        e_doj = new com.toedter.calendar.JDateChooser();
        imgpath = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        actions_panel = new javax.swing.JPanel();
        new_button = new javax.swing.JButton();
        save_botton = new javax.swing.JButton();
        update_button = new javax.swing.JButton();
        delete_button = new javax.swing.JButton();
        clear_button = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        company_table = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("EMPLOYEES INFORMATION FORM !!!");
        setBackground(new java.awt.Color(102, 102, 102));
        getContentPane().setLayout(null);

        jPanel1.setBackground(new java.awt.Color(0, 0, 51));
        jPanel1.setLayout(null);

        jPanel2.setBackground(new java.awt.Color(204, 255, 255));
        jPanel2.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 153, 153), 2, true));
        jPanel2.setLayout(null);

        jLabel1.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 0, 102));
        jLabel1.setText("EMPLOYEE ID: ");
        jPanel2.add(jLabel1);
        jLabel1.setBounds(20, 20, 110, 20);

        jLabel2.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(0, 0, 102));
        jLabel2.setText("NAME:");
        jPanel2.add(jLabel2);
        jLabel2.setBounds(20, 50, 80, 17);

        jLabel3.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(0, 0, 102));
        jLabel3.setText("GENDER: ");
        jPanel2.add(jLabel3);
        jLabel3.setBounds(20, 80, 70, 17);

        jLabel4.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(0, 0, 102));
        jLabel4.setText("AGE: ");
        jPanel2.add(jLabel4);
        jLabel4.setBounds(20, 110, 50, 20);

        jLabel5.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(0, 0, 102));
        jLabel5.setText("BLOOD GROUP: ");
        jPanel2.add(jLabel5);
        jLabel5.setBounds(20, 150, 120, 17);

        jLabel6.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(0, 0, 102));
        jLabel6.setText("CONTACT NO: ");
        jPanel2.add(jLabel6);
        jLabel6.setBounds(20, 190, 110, 17);

        jLabel7.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(0, 0, 102));
        jLabel7.setText("QUALIFICATION: ");
        jPanel2.add(jLabel7);
        jLabel7.setBounds(20, 230, 130, 17);

        jLabel8.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(0, 0, 102));
        jLabel8.setText("DOJ: ");
        jPanel2.add(jLabel8);
        jLabel8.setBounds(20, 270, 90, 17);

        jLabel9.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(0, 0, 102));
        jLabel9.setText("ADDRESS: ");
        jPanel2.add(jLabel9);
        jLabel9.setBounds(320, 20, 80, 20);

        E_idTextField.setEditable(false);
        E_idTextField.setBackground(new java.awt.Color(255, 255, 204));
        E_idTextField.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        E_idTextField.setForeground(new java.awt.Color(0, 0, 102));
        E_idTextField.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        E_idTextField.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 153, 153), 2, true));
        jPanel2.add(E_idTextField);
        E_idTextField.setBounds(150, 20, 160, 21);

        E_nameTextfield.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        E_nameTextfield.setForeground(new java.awt.Color(0, 0, 102));
        E_nameTextfield.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 153, 153), 2, true));
        jPanel2.add(E_nameTextfield);
        E_nameTextfield.setBounds(150, 50, 160, 21);

        male_radiobutton.setBackground(new java.awt.Color(204, 255, 255));
        male_radiobutton.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        male_radiobutton.setForeground(new java.awt.Color(0, 0, 102));
        male_radiobutton.setText("MALE");
        male_radiobutton.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 153, 153), 2, true));
        male_radiobutton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                male_radiobuttonActionPerformed(evt);
            }
        });
        jPanel2.add(male_radiobutton);
        male_radiobutton.setBounds(150, 80, 80, 21);

        female_radiobutton.setBackground(new java.awt.Color(204, 255, 255));
        female_radiobutton.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        female_radiobutton.setForeground(new java.awt.Color(0, 0, 102));
        female_radiobutton.setText("FEMALE");
        female_radiobutton.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 153, 153), 2, true));
        female_radiobutton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                female_radiobuttonActionPerformed(evt);
            }
        });
        jPanel2.add(female_radiobutton);
        female_radiobutton.setBounds(230, 80, 100, 21);

        age_textfield.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        age_textfield.setForeground(new java.awt.Color(0, 0, 102));
        age_textfield.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 153, 153), 2, true));
        jPanel2.add(age_textfield);
        age_textfield.setBounds(150, 110, 160, 20);

        bloodgroup_textfield.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        bloodgroup_textfield.setForeground(new java.awt.Color(0, 0, 102));
        bloodgroup_textfield.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 153, 153), 2, true));
        jPanel2.add(bloodgroup_textfield);
        bloodgroup_textfield.setBounds(150, 150, 160, 21);

        contact_txtfield.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        contact_txtfield.setForeground(new java.awt.Color(0, 0, 102));
        contact_txtfield.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 153, 153), 2, true));
        jPanel2.add(contact_txtfield);
        contact_txtfield.setBounds(150, 190, 160, 21);

        qualification_dropdown.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        qualification_dropdown.setForeground(new java.awt.Color(0, 0, 102));
        qualification_dropdown.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "SELECT DEGREE", "Phd", "MS", "B.E", "OTHER" }));
        qualification_dropdown.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 153, 153), 2, true));
        jPanel2.add(qualification_dropdown);
        qualification_dropdown.setBounds(150, 230, 160, 25);

        address_txtfield.setColumns(20);
        address_txtfield.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        address_txtfield.setForeground(new java.awt.Color(0, 0, 102));
        address_txtfield.setRows(5);
        address_txtfield.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 153, 153), 2));
        jScrollPane1.setViewportView(address_txtfield);

        jPanel2.add(jScrollPane1);
        jScrollPane1.setBounds(390, 20, 180, 120);

        img_label.setIcon(new javax.swing.ImageIcon(getClass().getResource("/companyform/profile.jpg"))); // NOI18N
        img_label.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 102, 102), 3, true));
        jPanel2.add(img_label);
        img_label.setBounds(580, 20, 230, 270);

        jButton1.setFont(new java.awt.Font("Times New Roman", 3, 18)); // NOI18N
        jButton1.setForeground(new java.awt.Color(0, 0, 102));
        jButton1.setText("UPLOAD IMAGE");
        jButton1.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 153, 153), 2, true));
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel2.add(jButton1);
        jButton1.setBounds(390, 150, 180, 30);

        e_doj.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 153, 153), 2, true));
        e_doj.setForeground(new java.awt.Color(0, 0, 102));
        e_doj.setDateFormatString("yyyy-MM-dd");
        e_doj.setMinSelectableDate(null);
        jPanel2.add(e_doj);
        e_doj.setBounds(150, 270, 160, 24);

        imgpath.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        imgpath.setForeground(new java.awt.Color(0, 0, 102));
        imgpath.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        imgpath.setText("IMAGE PATH");
        imgpath.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 153, 153), 2, true));
        jPanel2.add(imgpath);
        imgpath.setBounds(390, 190, 180, 30);

        jPanel1.add(jPanel2);
        jPanel2.setBounds(20, 30, 820, 300);

        jLabel10.setFont(new java.awt.Font("Times New Roman", 1, 20)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(51, 255, 255));
        jLabel10.setText("PERSONAL INFORMATION !");
        jPanel1.add(jLabel10);
        jLabel10.setBounds(280, 0, 280, 30);

        actions_panel.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 153, 153), 2, true));
        actions_panel.setLayout(null);

        new_button.setBackground(new java.awt.Color(204, 255, 255));
        new_button.setFont(new java.awt.Font("Times New Roman", 3, 18)); // NOI18N
        new_button.setForeground(new java.awt.Color(0, 0, 102));
        new_button.setIcon(new javax.swing.ImageIcon(getClass().getResource("/companyform/new (2).png"))); // NOI18N
        new_button.setText("NEW");
        new_button.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 153, 153), 3));
        new_button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                new_buttonActionPerformed(evt);
            }
        });
        actions_panel.add(new_button);
        new_button.setBounds(0, 0, 160, 60);

        save_botton.setBackground(new java.awt.Color(204, 255, 255));
        save_botton.setFont(new java.awt.Font("Times New Roman", 3, 18)); // NOI18N
        save_botton.setForeground(new java.awt.Color(0, 0, 102));
        save_botton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/companyform/save.png"))); // NOI18N
        save_botton.setText("SAVE");
        save_botton.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 153, 153), 3));
        save_botton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                save_bottonActionPerformed(evt);
            }
        });
        actions_panel.add(save_botton);
        save_botton.setBounds(160, 0, 160, 60);

        update_button.setBackground(new java.awt.Color(204, 255, 255));
        update_button.setFont(new java.awt.Font("Times New Roman", 3, 18)); // NOI18N
        update_button.setForeground(new java.awt.Color(0, 0, 102));
        update_button.setIcon(new javax.swing.ImageIcon(getClass().getResource("/companyform/update.png"))); // NOI18N
        update_button.setText("UPDATE");
        update_button.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 153, 153), 3));
        update_button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                update_buttonActionPerformed(evt);
            }
        });
        actions_panel.add(update_button);
        update_button.setBounds(320, 0, 170, 60);

        delete_button.setBackground(new java.awt.Color(204, 255, 255));
        delete_button.setFont(new java.awt.Font("Times New Roman", 3, 18)); // NOI18N
        delete_button.setForeground(new java.awt.Color(0, 0, 102));
        delete_button.setIcon(new javax.swing.ImageIcon(getClass().getResource("/companyform/delete (3).png"))); // NOI18N
        delete_button.setText("DELETE");
        delete_button.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 153, 153), 3));
        delete_button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                delete_buttonActionPerformed(evt);
            }
        });
        actions_panel.add(delete_button);
        delete_button.setBounds(490, 0, 170, 60);

        clear_button.setBackground(new java.awt.Color(204, 255, 255));
        clear_button.setFont(new java.awt.Font("Times New Roman", 3, 18)); // NOI18N
        clear_button.setForeground(new java.awt.Color(0, 0, 102));
        clear_button.setIcon(new javax.swing.ImageIcon(getClass().getResource("/companyform/clear.png"))); // NOI18N
        clear_button.setText("CLEAR");
        clear_button.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 153, 153), 3));
        clear_button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                clear_buttonActionPerformed(evt);
            }
        });
        actions_panel.add(clear_button);
        clear_button.setBounds(660, 0, 160, 60);

        jPanel1.add(actions_panel);
        actions_panel.setBounds(20, 340, 820, 60);

        company_table.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 153, 153), 2));
        company_table.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        company_table.setForeground(new java.awt.Color(0, 0, 102));
        company_table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        company_table.setSelectionBackground(new java.awt.Color(153, 153, 255));
        jScrollPane2.setViewportView(company_table);

        jPanel1.add(jScrollPane2);
        jScrollPane2.setBounds(20, 410, 820, 260);

        getContentPane().add(jPanel1);
        jPanel1.setBounds(0, 0, 870, 700);

        setSize(new java.awt.Dimension(880, 729));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void male_radiobuttonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_male_radiobuttonActionPerformed
      female_radiobutton.setSelected(false);
      gender=this.male_radiobutton.getText();
     
    }//GEN-LAST:event_male_radiobuttonActionPerformed

    private void new_buttonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_new_buttonActionPerformed
  if(E_nameTextfield.getText().equals("") || age_textfield.getText().equals("") || bloodgroup_textfield.getText().equals("") || contact_txtfield.getText().equals("") || qualification_dropdown.getSelectedIndex()==0  || address_txtfield.getText().equals("") || img_label.getIcon()==null || ((JTextField) e_doj.getDateEditor().getUiComponent()).getText().toString().equals("") || (male_radiobutton.getText().equals("") && female_radiobutton.getText().equals(""))){
          JOptionPane.showMessageDialog(null,"FILL ALL FIELDS !");
       }
  else{
  try{
       validationForInsertion();
  }catch(Exception ex){
  System.out.println(ex.getMessage());
  }
  }
    }//GEN-LAST:event_new_buttonActionPerformed

    private void female_radiobuttonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_female_radiobuttonActionPerformed
     male_radiobutton.setSelected(false);
     gender=this.female_radiobutton.getText();
    }//GEN-LAST:event_female_radiobuttonActionPerformed

    private void clear_buttonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_clear_buttonActionPerformed
this.E_idTextField.setText("");
this.E_nameTextfield.setText("");
this.age_textfield.setText("");
this.bloodgroup_textfield.setText("");
this.contact_txtfield.setText("");
this.qualification_dropdown.setSelectedIndex(0);
this.e_doj.setDate(null);
this.address_txtfield.setText("");
this.img_label.setIcon(null);
imgpath.setText("");
this.male_radiobutton.setSelected(false);
this.female_radiobutton.setSelected(false);
    }//GEN-LAST:event_clear_buttonActionPerformed

    private void update_buttonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_update_buttonActionPerformed
        try {
            updateRow();
        } catch (ParseException ex) {
            System.out.println(ex.getMessage());
        }
    }//GEN-LAST:event_update_buttonActionPerformed

    private void delete_buttonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_delete_buttonActionPerformed
        deleteRow();
    }//GEN-LAST:event_delete_buttonActionPerformed

    private void save_bottonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_save_bottonActionPerformed
       if(E_nameTextfield.getText().equals("") || age_textfield.getText().equals("") || bloodgroup_textfield.getText().equals("") || contact_txtfield.getText().equals("") || qualification_dropdown.getSelectedIndex()==0 || e_doj.equals("") || address_txtfield.getText().equals("") || imgpath.getText().equals("") || ((JTextField) e_doj.getDateEditor().getUiComponent()).getText().toString().equals("")||(male_radiobutton.getText().equals("") && female_radiobutton.getText().equals(""))){
          JOptionPane.showMessageDialog(null,"NULL VALUES CAN NOT BE UPDATED!!!");
       }
       else{
           saveRow();
       }
    }//GEN-LAST:event_save_bottonActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
   JFileChooser file = new JFileChooser();
   file.setCurrentDirectory(new File(System.getProperty("user.home")));
   
   FileNameExtensionFilter filter = new FileNameExtensionFilter("*.Images","jpg","gif","png");
   file.addChoosableFileFilter(filter);
   int result = file.showSaveDialog(null);
    
   if(result == JFileChooser.APPROVE_OPTION){
   File selectedFile = file.getSelectedFile();
   String path = selectedFile.getAbsolutePath();
   img_label.setIcon(ResizeImage(path,null));
   imgPath=path;
   }
   
   else if(result == JFileChooser.CANCEL_OPTION){
   System.out.println("NO FILE SELECT !");
   }
    }//GEN-LAST:event_jButton1ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(MainCompanyFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(MainCompanyFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(MainCompanyFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(MainCompanyFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new MainCompanyFrame().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField E_idTextField;
    private javax.swing.JTextField E_nameTextfield;
    private javax.swing.JPanel actions_panel;
    private javax.swing.JTextArea address_txtfield;
    private javax.swing.JTextField age_textfield;
    private javax.swing.JTextField bloodgroup_textfield;
    private javax.swing.JButton clear_button;
    private javax.swing.JTable company_table;
    private javax.swing.JTextField contact_txtfield;
    private javax.swing.JButton delete_button;
    private com.toedter.calendar.JDateChooser e_doj;
    private javax.swing.JRadioButton female_radiobutton;
    private javax.swing.JLabel img_label;
    private javax.swing.JLabel imgpath;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JRadioButton male_radiobutton;
    private javax.swing.JButton new_button;
    private javax.swing.JComboBox qualification_dropdown;
    private javax.swing.JButton save_botton;
    private javax.swing.JButton update_button;
    // End of variables declaration//GEN-END:variables

}
