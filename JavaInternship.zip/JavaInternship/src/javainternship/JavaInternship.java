package javainternship;
public class JavaInternship {
public static void main(String[] args) {
 new Computer_Shop().show();
    }
   }
