package javainternship;
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
public class Show_items extends javax.swing.JFrame {
         int ID;
         String  item_name;
         int  no_of_items;
          String supplier_name;
           double price;
         Connection  conn = null;
         
    public Show_items() throws ClassNotFoundException, SQLException {
        initComponents();
        Class.forName("oracle.jdbc.driver.OracleDriver");
       conn= DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","BHAGIA SHERI","123456789");
          if(conn!=null){
       System.out.println("Connection Succesfullly!");
               }
          setSize(817,800);
         setVisible(true);
     }
    
        public void showKeyBoard(){
            String  keyboard="KEYBOARD DETAILS: \n******************************************\n ";
          try{
     
      Statement st = conn.createStatement();
      ResultSet rs = st.executeQuery("select * from Computer_Shop where items_name='KEYBOARD'");
     // ResultSet rs = st.executeQuery("SELECT ID, ITEMS_NAME, SUPPLIER_NAME, PRICE, SUM(NOOFITEMS) AS NO_OF_ITEMS FROM COMPUTER_SHOP WHERE ITEMS_NAME='KEYBOARD' GROUP BY ID, ITEMS_NAME, SUPPLIER_NAME, PRICE");
           while(rs.next()){
           
          ID=Integer.parseInt(rs.getString("ID"));
          item_name=rs.getString("ITEMS_NAME");
          no_of_items=Integer.parseInt(rs.getString("NOOFITEMS"));
          supplier_name=rs.getString("SUPPLIER_NAME");
           price=Double.parseDouble(rs.getString("PRICE"));
            
             
          keyboard+="ITEM NO. : "+ID+"\n ITEM NAME: "+item_name+"\n TOTAL NO OF ITEMS: "+no_of_items+"\n SUPPLIER NAME: "+supplier_name+"\n PRICE: "+price+"\n=============================== \n";
   }//end while 
            
           JOptionPane.showMessageDialog(null,keyboard);
        
         }
              catch(Exception  ex){
    JOptionPane.showMessageDialog(null,"SQL Error :"+ex.getMessage());
     }           
     }
        
        public void showMouse(){
            String  mouse="MOUSE DETAILS: \n******************************************\n ";
          try{
     
      Statement st = conn.createStatement();
      ResultSet rs = st.executeQuery("select * from Computer_Shop where items_name='MOUSE'");
           while(rs.next()){
           
          ID=Integer.parseInt(rs.getString("ID"));
          item_name=rs.getString("ITEMS_NAME");
          no_of_items=Integer.parseInt(rs.getString("NOOFITEMS"));
          supplier_name=rs.getString("SUPPLIER_NAME");
          price=Double.parseDouble(rs.getString("PRICE"));
            
             
          mouse+="ITEM NO. : "+ID+"\n ITEM NAME: "+item_name+"\n TOTAL NO OF ITEMS: "+no_of_items+"\n SUPPLIER NAME: "+supplier_name+"\n PRICE: "+price+"\n=============================== \n";
   }//end while 
            
           JOptionPane.showMessageDialog(null,mouse);
         
         }
              catch(Exception  ex){
    JOptionPane.showMessageDialog(null,"SQL Error :"+ex.getMessage());
     }           
      }    
          
        public void showMonitor(){
          try{
     String  monitor="MONITOR DETAILS: \n**************************************\n ";
      Statement st = conn.createStatement();
      ResultSet rs = st.executeQuery("select * from Computer_Shop where items_name='MONITOR'");
           while(rs.next()){
           
          ID=Integer.parseInt(rs.getString("ID"));
          item_name=rs.getString("ITEMS_NAME");
          no_of_items=Integer.parseInt(rs.getString("NOOFITEMS"));
          supplier_name=rs.getString("SUPPLIER_NAME");
           price=Double.parseDouble(rs.getString("PRICE"));
            
             
          monitor+="ITEM NO. : "+ID+"\n ITEM NAME: "+item_name+"\n TOTAL NO OF ITEMS: "+no_of_items+"\n SUPPLIER NAME: "+supplier_name+"\n PRICE: "+price+"\n=============================== \n";
                  
   }//end while 
            
           JOptionPane.showMessageDialog(null,monitor);
          
         }
              catch(Exception  ex){
    JOptionPane.showMessageDialog(null,"SQL Error :"+ex.getMessage());
     }           
      } 
        
         public void showVgaCables(){
             String  vga="VGA CABLES  DETAILS: \n******************************************\n ";
          try{
     
      Statement st = conn.createStatement();
      ResultSet rs = st.executeQuery("select * from Computer_Shop where items_name='VGA CABLES'");
           while(rs.next()){
           
          ID=Integer.parseInt(rs.getString("ID"));
          item_name=rs.getString("ITEMS_NAME");
          no_of_items=Integer.parseInt(rs.getString("NOOFITEMS"));
          supplier_name=rs.getString("SUPPLIER_NAME");
           price=Double.parseDouble(rs.getString("PRICE"));
            
             
          vga+="ITEM NO. : "+ID+"\n ITEM NAME: "+item_name+"\n TOTAL NO OF ITEMS: "+no_of_items+"\n SUPPLIER NAME: "+supplier_name+"\n PRICE: "+price+"\n=============================== \n";
                  
   }//end while 
            
           JOptionPane.showMessageDialog(null,vga);
          
         }
              catch(Exception  ex){
    JOptionPane.showMessageDialog(null,"SQL Error :"+ex.getMessage());
     }           
      } 
         
          public void showGraphicCards(){
              String  graphic_cards="GRAPHIC CARDS DETAILS: \n******************************************\n ";
          try{
     
      Statement st = conn.createStatement();
      ResultSet rs = st.executeQuery("select * from Computer_Shop where items_name='GRAPHIC CARDS'");
           while(rs.next()){
           
          ID=Integer.parseInt(rs.getString("ID"));
          item_name=rs.getString("ITEMS_NAME");
          no_of_items=Integer.parseInt(rs.getString("NOOFITEMS"));
          supplier_name=rs.getString("SUPPLIER_NAME");
           price=Double.parseDouble(rs.getString("PRICE"));
            
             
          graphic_cards+="ITEM NO. : "+ID+"\n ITEM NAME: "+item_name+"\n TOTAL NO OF ITEMS: "+no_of_items+"\n SUPPLIER NAME: "+supplier_name+"\n PRICE: "+price+"\n=============================== \n";
   }//end while 
            
           JOptionPane.showMessageDialog(null,graphic_cards);
          
         }
              catch(Exception  ex){
    JOptionPane.showMessageDialog(null,"SQL Error :"+ex.getMessage());
     }           
      } 
          
           public void showLcd(){
               String  lcd="LCD DETAILS: \n******************************************\n ";
          try{
     
      Statement st = conn.createStatement();
      ResultSet rs = st.executeQuery("select * from Computer_Shop where items_name='LCD'");
           while(rs.next()){
           
          ID=Integer.parseInt(rs.getString("ID"));
          item_name=rs.getString("ITEMS_NAME");
          no_of_items=Integer.parseInt(rs.getString("NOOFITEMS"));
          supplier_name=rs.getString("SUPPLIER_NAME");
           price=Double.parseDouble(rs.getString("PRICE"));
            
             
          lcd+="ITEM NO. : "+ID+"\n ITEM NAME: "+item_name+"\n TOTAL NO OF ITEMS: "+no_of_items+"\n SUPPLIER NAME: "+supplier_name+"\n PRICE: "+price+"\n=============================== \n";
                  
   }//end while 
            
           JOptionPane.showMessageDialog(null,lcd);
           
         }
              catch(Exception  ex){
    JOptionPane.showMessageDialog(null,"SQL Error :"+ex.getMessage());
     }           
      } 
           
            public void showLaptop(){
                String  laptop="LAPTOP DETAILS: \n******************************************\n ";
          try{
     
      Statement st = conn.createStatement();
      ResultSet rs = st.executeQuery("select * from Computer_Shop where items_name='LAPTOPS'");
           while(rs.next()){
           
          ID=Integer.parseInt(rs.getString("ID"));
          item_name=rs.getString("ITEMS_NAME");
          no_of_items=Integer.parseInt(rs.getString("NOOFITEMS"));
          supplier_name=rs.getString("SUPPLIER_NAME");
           price=Double.parseDouble(rs.getString("PRICE"));
            
             
          laptop+="ITEM NO. : "+ID+"\n ITEM NAME: "+item_name+"\n TOTAL NO OF ITEMS: "+no_of_items+"\n SUPPLIER NAME: "+supplier_name+"\n PRICE: "+price+"\n=============================== \n";
                  
   
           }//end while 
            
          JOptionPane.showMessageDialog(null,laptop); 
          
         }
              catch(Exception  ex){
    JOptionPane.showMessageDialog(null,"SQL Error :"+ex.getMessage());
     }           
      } 

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jLabel9 = new javax.swing.JLabel();
        keyboard = new javax.swing.JButton();
        mouse = new javax.swing.JButton();
        monitor = new javax.swing.JButton();
        vga_cables = new javax.swing.JButton();
        graphic_cards = new javax.swing.JButton();
        lcd = new javax.swing.JButton();
        laptop = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("ITEMS DETAILS.");
        setBackground(new java.awt.Color(0, 0, 0));
        getContentPane().setLayout(null);

        jButton2.setBackground(new java.awt.Color(0, 0, 0));
        jButton2.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jButton2.setForeground(new java.awt.Color(255, 255, 255));
        jButton2.setText("BACK");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton2);
        jButton2.setBounds(60, 620, 130, 50);

        jButton3.setBackground(new java.awt.Color(0, 0, 0));
        jButton3.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jButton3.setForeground(new java.awt.Color(255, 255, 255));
        jButton3.setText("EXIT");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton3);
        jButton3.setBounds(560, 620, 140, 50);

        jLabel9.setBackground(new java.awt.Color(153, 153, 153));
        jLabel9.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(0, 255, 255));
        jLabel9.setText("INVENTORY ITEMS LIST:");
        getContentPane().add(jLabel9);
        jLabel9.setBounds(260, 10, 330, 40);

        keyboard.setIcon(new javax.swing.ImageIcon(getClass().getResource("/javainternship/keyboard.jpg"))); // NOI18N
        keyboard.setText("jButton1");
        keyboard.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                keyboardActionPerformed(evt);
            }
        });
        getContentPane().add(keyboard);
        keyboard.setBounds(40, 50, 220, 160);

        mouse.setIcon(new javax.swing.ImageIcon(getClass().getResource("/javainternship/mouse.png"))); // NOI18N
        mouse.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mouseActionPerformed(evt);
            }
        });
        getContentPane().add(mouse);
        mouse.setBounds(280, 50, 260, 160);

        monitor.setIcon(new javax.swing.ImageIcon(getClass().getResource("/javainternship/monitor.jpeg"))); // NOI18N
        monitor.setText("jButton1");
        monitor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                monitorActionPerformed(evt);
            }
        });
        getContentPane().add(monitor);
        monitor.setBounds(550, 50, 220, 160);

        vga_cables.setIcon(new javax.swing.ImageIcon(getClass().getResource("/javainternship/vcg cables.jpeg"))); // NOI18N
        vga_cables.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                vga_cablesActionPerformed(evt);
            }
        });
        getContentPane().add(vga_cables);
        vga_cables.setBounds(140, 230, 250, 150);

        graphic_cards.setIcon(new javax.swing.ImageIcon(getClass().getResource("/javainternship/Graphic cards1.jpg"))); // NOI18N
        graphic_cards.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                graphic_cardsActionPerformed(evt);
            }
        });
        getContentPane().add(graphic_cards);
        graphic_cards.setBounds(90, 410, 330, 160);

        lcd.setIcon(new javax.swing.ImageIcon(getClass().getResource("/javainternship/lcd1.jpeg"))); // NOI18N
        lcd.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                lcdActionPerformed(evt);
            }
        });
        getContentPane().add(lcd);
        lcd.setBounds(440, 400, 260, 190);

        laptop.setIcon(new javax.swing.ImageIcon(getClass().getResource("/javainternship/laptops1.jpeg"))); // NOI18N
        laptop.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                laptopActionPerformed(evt);
            }
        });
        getContentPane().add(laptop);
        laptop.setBounds(420, 230, 230, 150);

        jLabel1.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 255, 255));
        jLabel1.setText("KEYBOARD");
        getContentPane().add(jLabel1);
        jLabel1.setBounds(110, 210, 160, 20);

        jLabel2.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(0, 255, 255));
        jLabel2.setText("MONITOR");
        getContentPane().add(jLabel2);
        jLabel2.setBounds(630, 210, 130, 17);

        jLabel3.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(0, 255, 255));
        jLabel3.setText("MOUSE");
        getContentPane().add(jLabel3);
        jLabel3.setBounds(380, 210, 90, 17);

        jLabel4.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(0, 255, 255));
        jLabel4.setText("VGA CABLES");
        getContentPane().add(jLabel4);
        jLabel4.setBounds(210, 380, 150, 20);

        jLabel5.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(0, 255, 255));
        jLabel5.setText("LAPTOP");
        getContentPane().add(jLabel5);
        jLabel5.setBounds(510, 380, 70, 17);

        jLabel6.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(0, 255, 255));
        jLabel6.setText("GRAPHIC CABLES");
        getContentPane().add(jLabel6);
        jLabel6.setBounds(190, 580, 150, 20);

        jLabel7.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(0, 255, 255));
        jLabel7.setText("LCD");
        getContentPane().add(jLabel7);
        jLabel7.setBounds(550, 590, 110, 17);

        jLabel8.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 0, 51));
        jLabel8.setText("CLICK THE IMAGE FOR THE DETAILS OF SPECIFIC ITEM!!!");
        getContentPane().add(jLabel8);
        jLabel8.setBounds(210, 630, 350, 20);

        jLabel10.setIcon(new javax.swing.ImageIcon(getClass().getResource("/javainternship/img3.jpg"))); // NOI18N
        jLabel10.setText("jLabel10");
        getContentPane().add(jLabel10);
        jLabel10.setBounds(0, 0, 800, 730);

        setSize(new java.awt.Dimension(811, 757));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        // TODO add your handling code here:
        try{
           conn.close();}catch(Exception e){
           System.out.println(e.getMessage());
           }
        System.exit(0);
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        this.setVisible(false);
        new InventoryItems().show();
        
    }//GEN-LAST:event_jButton2ActionPerformed

    private void keyboardActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_keyboardActionPerformed
        showKeyBoard();
    }//GEN-LAST:event_keyboardActionPerformed

    private void mouseActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mouseActionPerformed
    showMouse();
    }//GEN-LAST:event_mouseActionPerformed

    private void monitorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_monitorActionPerformed
     showMonitor();
    }//GEN-LAST:event_monitorActionPerformed

    private void vga_cablesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_vga_cablesActionPerformed
        showVgaCables();
    }//GEN-LAST:event_vga_cablesActionPerformed

    private void graphic_cardsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_graphic_cardsActionPerformed
        showGraphicCards();
    }//GEN-LAST:event_graphic_cardsActionPerformed

    private void lcdActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_lcdActionPerformed
        showLcd();
    }//GEN-LAST:event_lcdActionPerformed

    private void laptopActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_laptopActionPerformed
      showLaptop();
    }//GEN-LAST:event_laptopActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Show_items.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Show_items.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Show_items.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Show_items.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    new Show_items().setVisible(true);
                } catch (ClassNotFoundException ex) {
                    Logger.getLogger(Show_items.class.getName()).log(Level.SEVERE, null, ex);
                } catch (SQLException ex) {
                    Logger.getLogger(Show_items.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton graphic_cards;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JButton keyboard;
    private javax.swing.JButton laptop;
    private javax.swing.JButton lcd;
    private javax.swing.JButton monitor;
    private javax.swing.JButton mouse;
    private javax.swing.JButton vga_cables;
    // End of variables declaration//GEN-END:variables
}
