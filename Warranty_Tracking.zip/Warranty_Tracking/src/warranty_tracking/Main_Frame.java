package warranty_tracking;
import java.sql.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.JOptionPane;
import net.proteanit.sql.DbUtils;
public class Main_Frame extends javax.swing.JFrame {
     Connection conn;
     Statement st;
     ResultSet rs;
       String cu_name = "";
       String prod_name ="";
       String sal_date = "";
       String warr_date ="";
       String rem_m = "";
       String it="";
       Double pric;
       int imei;
       String s_no;
        String search_details;
        
     public Main_Frame() {
        initComponents();
        setSize(960,630);
        this.jPanel1.setSize(960,600);
        this.jPanel2.setSize(960,600);
        this.jTabbedPane1.setSize(960,600);
        setVisible(true);
        this.output_panel.setVisible(false);
        //for connection
        try{
         Class.forName("oracle.jdbc.driver.OracleDriver");
            conn= DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","BHAGIA SHERI","123456789");
            if(conn!=null){
            System.out.println("Connection Succesfullly!");
            }
            }catch(Exception e){
        System.out.println(e.getMessage());
        }
        tableData(); // table show
    }
    
    public void addData(){
         String name=customer_name.getText();
        String pro_name = product_name.getText();
        int imei = Integer.parseInt(imei_no.getText());
        String s_no = serial_no.getText();
        String date= sale_date.getText();
        String warranty_end_date = end_date.getText();
        Double cost = Double.parseDouble(price.getText());
        String item = items.getSelectedItem().toString();
       try{
            st = conn.createStatement();
            int rows= st.executeUpdate("insert into warranty_tracking values('"+name+"','"+pro_name+"','"+imei+"','"+s_no+"',TO_DATE('"+date+"','MM-DD-YYYY'),TO_DATE('"+warranty_end_date+"','MM-DD-YYYY'),'"+cost+"','"+item+"')");
            if(rows>0){
               JOptionPane.showMessageDialog(null,"RECORD SUBMISSION.....SUCCESSFUL  :) ");
            }
            else{
             JOptionPane.showMessageDialog(null,"RECORD SUBMISSION.....UNSUCCESSFUL  :( ");
            }
        }catch(Exception e){
           System.out.println(e.getMessage());
        }   
    }
    public void tableData(){
    try{
          st = conn.createStatement();
          rs = st.executeQuery("select * from warranty_tracking"); 
          warranty_table.setModel(DbUtils.resultSetToTableModel(rs));
    }catch(Exception e){
     System.out.println(e.getMessage());
    }
    }
    
   public void showImei(String search_details){
   System.out.println("showImei method is called");
     try{ 
          Statement stm;
            stm = conn.createStatement();
    ResultSet rs1 = stm.executeQuery("select customer_name, product_name, items, price, imei_no, serial_no, sale_date, warranty_end_date, MONTHS_BETWEEN(warranty_end_date,SYSDATE) from warranty_tracking where imei_no='"+search_details+"'");
    if(rs1!=null){ 
    System.out.println("showImei method, rs1 is not null ");
    System.out.println(rs1);
    }
   else{
     System.out.println("showImei method, rs1 is null");
    }
         while(rs1.next()){
        System.out.println("search by emei methd");
        cu_name=rs1.getString("customer_name");
        prod_name=rs1.getString("product_name");
        sal_date=rs1.getString("sale_date");
        warr_date=rs1.getString("warranty_end_date");
        imei=Integer.parseInt(rs1.getString("imei_no"));
        s_no=rs1.getString("serial_no");
        rem_m=rs1.getString("MONTHS_BETWEEN(warranty_end_date,SYSDATE)");
        it=rs1.getString("items");
        pric=Double.parseDouble(rs1.getString("price"));
       //Printing Values
            System.out.println("name:"+cu_name);
            System.out.println("product: "+prod_name);
            System.out.println("items: "+it);
            System.out.println("price: "+pric);
            System.out.println("sell_date: "+prod_name);
            System.out.println("warrantydate: "+warr_date);
            System.out.println("remaining "+rem_m);
         System.out.println("search_details "+search_details);
         }//end while
         if(search_details.equals(s_no) || (Integer.parseInt(search_details))==(imei)){
         this.output_panel.setVisible(true);  
         customer.setText(""+cu_name);
        product.setText(""+prod_name);
        item.setText(""+it);
        cost.setText(""+pric);
       sal_dat.setText(""+sal_date);
        warr_dat.setText(""+warr_date);
        rem_dat.setText(""+rem_m); 
        }
         else{
      JOptionPane.showMessageDialog(null,"=======NO RECORD EXIST======");
       }
       }catch(Exception e){
     System.out.println(e.getMessage());
     }
   }
   
   public void showSerial(String search_details){
     System.out.println("showSerial methos is called");
       try{
        Statement stm;
        stm = conn.createStatement();
        ResultSet rs1 = stm.executeQuery("select customer_name, product_name, items, price, imei_no, serial_no, sale_date, warranty_end_date, MONTHS_BETWEEN(warranty_end_date,SYSDATE) from warranty_tracking where serial_no =UPPER('"+search_details+"') OR serial_no =LOWER('"+search_details+"') ");
        if(rs1!=null){
       System.out.println("showSerial method, rs1 is not null");  
     }
   else{
   System.out.println("showSerial method, rs1 is null");
    }
         while(rs1.next()){
        
       cu_name=rs1.getString("customer_name");
        prod_name=rs1.getString("product_name");
       it=rs1.getString("items");
       pric=Double.parseDouble(rs1.getString("price"));
       imei=Integer.parseInt(rs1.getString("imei_no"));
        s_no=rs1.getString("serial_no");
       sal_date=rs1.getString("sale_date");
        warr_date=rs1.getString("warranty_end_date");
        rem_m=rs1.getString("MONTHS_BETWEEN(warranty_end_date,SYSDATE)");
// fro printing values
            System.out.println("name:"+cu_name);
            System.out.println("product: "+prod_name);
            System.out.println("items: "+it);
            System.out.println("price: "+pric);
            System.out.println("sell_date: "+sal_date);
            System.out.println("warrantydate: "+warr_date);
            System.out.println("remaining "+rem_m);
            System.out.println("price: "+pric);
         }//end while
          if(search_details.equalsIgnoreCase(s_no) || search_details.equals(imei)){
         this.output_panel.setVisible(true);  
         customer.setText(""+cu_name);
        product.setText(""+prod_name);
        item.setText(""+it);
        cost.setText(""+pric);
       sal_dat.setText(""+sal_date);
        warr_dat.setText(""+warr_date);
        rem_dat.setText(""+rem_m); 
        }
         else{
      JOptionPane.showMessageDialog(null,"=======NO RECORD EXIST======");
       }
       }catch(Exception e){
       System.out.println(e.getMessage());
       }
   }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jTabbedPane1 = new javax.swing.JTabbedPane();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        items = new javax.swing.JComboBox();
        price = new javax.swing.JTextField();
        product_name = new javax.swing.JTextField();
        customer_name = new javax.swing.JTextField();
        end_date = new javax.swing.JTextField();
        serial_no = new javax.swing.JTextField();
        sale_date = new javax.swing.JTextField();
        jPanel3 = new javax.swing.JPanel();
        jLabel15 = new javax.swing.JLabel();
        save = new javax.swing.JButton();
        imei_no = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        warranty_table = new javax.swing.JTable();
        jLabel7 = new javax.swing.JLabel();
        search = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();
        output_panel = new javax.swing.JPanel();
        customer = new javax.swing.JLabel();
        product = new javax.swing.JLabel();
        item = new javax.swing.JLabel();
        cost = new javax.swing.JLabel();
        sal_dat = new javax.swing.JLabel();
        warr_dat = new javax.swing.JLabel();
        rem_dat = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(null);

        jTabbedPane1.setBackground(new java.awt.Color(0, 0, 0));
        jTabbedPane1.setBorder(javax.swing.BorderFactory.createCompoundBorder());
        jTabbedPane1.setForeground(new java.awt.Color(0, 0, 204));

        jPanel1.setLayout(null);

        jLabel1.setBackground(new java.awt.Color(0, 0, 0));
        jLabel1.setFont(new java.awt.Font("Times New Roman", 3, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 0, 255));
        jLabel1.setText("CUSTOMER NAME: ");
        jPanel1.add(jLabel1);
        jLabel1.setBounds(120, 130, 230, 22);

        jLabel2.setBackground(new java.awt.Color(0, 0, 0));
        jLabel2.setFont(new java.awt.Font("Times New Roman", 3, 18)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(0, 0, 255));
        jLabel2.setText("PRODUCT NAME:");
        jPanel1.add(jLabel2);
        jLabel2.setBounds(120, 170, 220, 22);

        jLabel3.setBackground(new java.awt.Color(0, 0, 0));
        jLabel3.setFont(new java.awt.Font("Times New Roman", 3, 18)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(0, 0, 255));
        jLabel3.setText("SERIAL NO:");
        jPanel1.add(jLabel3);
        jLabel3.setBounds(120, 330, 190, 22);

        jLabel4.setBackground(new java.awt.Color(0, 0, 0));
        jLabel4.setFont(new java.awt.Font("Times New Roman", 3, 18)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(0, 0, 255));
        jLabel4.setText("ITEM SALE DATE:");
        jPanel1.add(jLabel4);
        jLabel4.setBounds(120, 370, 230, 22);

        jLabel5.setBackground(new java.awt.Color(0, 0, 0));
        jLabel5.setFont(new java.awt.Font("Times New Roman", 3, 18)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(0, 0, 255));
        jLabel5.setText("WARRANTY END DATE:");
        jPanel1.add(jLabel5);
        jLabel5.setBounds(120, 410, 230, 22);

        jLabel17.setBackground(new java.awt.Color(0, 0, 0));
        jLabel17.setFont(new java.awt.Font("Times New Roman", 3, 18)); // NOI18N
        jLabel17.setForeground(new java.awt.Color(0, 0, 255));
        jLabel17.setText("ITEM:");
        jPanel1.add(jLabel17);
        jLabel17.setBounds(120, 210, 230, 22);

        jLabel18.setBackground(new java.awt.Color(0, 0, 0));
        jLabel18.setFont(new java.awt.Font("Times New Roman", 3, 18)); // NOI18N
        jLabel18.setForeground(new java.awt.Color(0, 0, 255));
        jLabel18.setText("PRICE:");
        jPanel1.add(jLabel18);
        jLabel18.setBounds(120, 250, 220, 22);

        items.setBackground(new java.awt.Color(0, 0, 0));
        items.setFont(new java.awt.Font("Times New Roman", 3, 18)); // NOI18N
        items.setForeground(new java.awt.Color(0, 0, 153));
        items.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "COMPUTER", "MOBILE" }));
        jPanel1.add(items);
        items.setBounds(590, 200, 220, 30);

        price.setFont(new java.awt.Font("Times New Roman", 3, 18)); // NOI18N
        price.setForeground(new java.awt.Color(0, 0, 204));
        jPanel1.add(price);
        price.setBounds(590, 240, 220, 28);

        product_name.setFont(new java.awt.Font("Times New Roman", 3, 18)); // NOI18N
        product_name.setForeground(new java.awt.Color(0, 0, 204));
        jPanel1.add(product_name);
        product_name.setBounds(590, 160, 220, 28);

        customer_name.setFont(new java.awt.Font("Times New Roman", 3, 18)); // NOI18N
        customer_name.setForeground(new java.awt.Color(0, 0, 204));
        jPanel1.add(customer_name);
        customer_name.setBounds(590, 120, 220, 28);

        end_date.setFont(new java.awt.Font("Times New Roman", 3, 18)); // NOI18N
        end_date.setForeground(new java.awt.Color(0, 0, 204));
        jPanel1.add(end_date);
        end_date.setBounds(590, 420, 220, 28);

        serial_no.setFont(new java.awt.Font("Times New Roman", 3, 18)); // NOI18N
        serial_no.setForeground(new java.awt.Color(0, 0, 204));
        jPanel1.add(serial_no);
        serial_no.setBounds(590, 330, 220, 28);

        sale_date.setFont(new java.awt.Font("Times New Roman", 3, 18)); // NOI18N
        sale_date.setForeground(new java.awt.Color(0, 0, 204));
        jPanel1.add(sale_date);
        sale_date.setBounds(590, 380, 220, 28);

        jPanel3.setBackground(new java.awt.Color(0, 0, 255));
        jPanel3.setLayout(null);

        jLabel15.setFont(new java.awt.Font("Broadway", 3, 24)); // NOI18N
        jLabel15.setText("W A R R A N T Y   T R A C K I N G  A P P L I C A T I O N ");
        jPanel3.add(jLabel15);
        jLabel15.setBounds(110, 20, 720, 50);

        jPanel1.add(jPanel3);
        jPanel3.setBounds(0, 0, 1170, 100);

        save.setBackground(new java.awt.Color(0, 0, 255));
        save.setFont(new java.awt.Font("Broadway", 3, 24)); // NOI18N
        save.setText("SAVE");
        save.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                saveActionPerformed(evt);
            }
        });
        jPanel1.add(save);
        save.setBounds(370, 470, 140, 60);

        imei_no.setFont(new java.awt.Font("Times New Roman", 3, 18)); // NOI18N
        imei_no.setForeground(new java.awt.Color(0, 0, 204));
        jPanel1.add(imei_no);
        imei_no.setBounds(590, 280, 220, 28);

        jLabel6.setBackground(new java.awt.Color(0, 0, 0));
        jLabel6.setFont(new java.awt.Font("Times New Roman", 3, 18)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(0, 0, 255));
        jLabel6.setText("IMEI NO:");
        jPanel1.add(jLabel6);
        jLabel6.setBounds(120, 290, 210, 22);

        jLabel16.setIcon(new javax.swing.ImageIcon(getClass().getResource("/warranty_tracking/back_tab1.jpg"))); // NOI18N
        jPanel1.add(jLabel16);
        jLabel16.setBounds(0, 100, 1170, 480);

        jTabbedPane1.addTab("ADD DETAILS", jPanel1);

        jPanel2.setBackground(new java.awt.Color(153, 153, 255));
        jPanel2.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jPanel2.setLayout(null);

        warranty_table.setFont(new java.awt.Font("Times New Roman", 3, 14)); // NOI18N
        warranty_table.setForeground(new java.awt.Color(0, 0, 204));
        warranty_table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(warranty_table);

        jPanel2.add(jScrollPane1);
        jScrollPane1.setBounds(20, 290, 900, 270);

        jLabel7.setFont(new java.awt.Font("Broadway", 3, 14)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(0, 0, 204));
        jLabel7.setText("SEARCH:");
        jPanel2.add(jLabel7);
        jLabel7.setBounds(230, 40, 90, 30);

        search.setFont(new java.awt.Font("Broadway", 3, 14)); // NOI18N
        search.setForeground(new java.awt.Color(0, 0, 204));
        search.setText("  search here");
        search.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                searchFocusGained(evt);
            }
        });
        jPanel2.add(search);
        search.setBounds(310, 40, 210, 40);

        jButton1.setBackground(new java.awt.Color(0, 0, 204));
        jButton1.setFont(new java.awt.Font("Broadway", 3, 14)); // NOI18N
        jButton1.setText("SEARCH");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel2.add(jButton1);
        jButton1.setBounds(520, 40, 120, 40);

        output_panel.setBackground(new java.awt.Color(0, 0, 0));
        output_panel.setLayout(null);

        customer.setBackground(new java.awt.Color(0, 0, 0));
        customer.setFont(new java.awt.Font("Times New Roman", 3, 14)); // NOI18N
        customer.setForeground(new java.awt.Color(255, 255, 255));
        customer.setText("jLabel21");
        output_panel.add(customer);
        customer.setBounds(370, 10, 190, 17);

        product.setBackground(new java.awt.Color(0, 0, 0));
        product.setFont(new java.awt.Font("Times New Roman", 3, 14)); // NOI18N
        product.setForeground(new java.awt.Color(255, 255, 255));
        product.setText("jLabel22");
        output_panel.add(product);
        product.setBounds(370, 30, 170, 17);

        item.setBackground(new java.awt.Color(0, 0, 0));
        item.setFont(new java.awt.Font("Times New Roman", 3, 14)); // NOI18N
        item.setForeground(new java.awt.Color(255, 255, 255));
        item.setText("jLabel23");
        output_panel.add(item);
        item.setBounds(370, 50, 160, 17);

        cost.setBackground(new java.awt.Color(0, 0, 0));
        cost.setFont(new java.awt.Font("Times New Roman", 3, 14)); // NOI18N
        cost.setForeground(new java.awt.Color(255, 255, 255));
        cost.setText("jLabel24");
        output_panel.add(cost);
        cost.setBounds(370, 70, 130, 17);

        sal_dat.setBackground(new java.awt.Color(0, 0, 0));
        sal_dat.setFont(new java.awt.Font("Times New Roman", 3, 14)); // NOI18N
        sal_dat.setForeground(new java.awt.Color(255, 255, 255));
        sal_dat.setText("jLabel25");
        output_panel.add(sal_dat);
        sal_dat.setBounds(370, 90, 210, 17);

        warr_dat.setBackground(new java.awt.Color(0, 0, 0));
        warr_dat.setFont(new java.awt.Font("Times New Roman", 3, 14)); // NOI18N
        warr_dat.setForeground(new java.awt.Color(255, 255, 255));
        warr_dat.setText("jLabel26");
        output_panel.add(warr_dat);
        warr_dat.setBounds(370, 110, 200, 17);

        rem_dat.setBackground(new java.awt.Color(0, 0, 0));
        rem_dat.setFont(new java.awt.Font("Times New Roman", 3, 14)); // NOI18N
        rem_dat.setForeground(new java.awt.Color(255, 255, 255));
        rem_dat.setText("jLabel27");
        output_panel.add(rem_dat);
        rem_dat.setBounds(370, 130, 210, 17);

        jLabel8.setBackground(new java.awt.Color(0, 0, 0));
        jLabel8.setFont(new java.awt.Font("Times New Roman", 3, 14)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setText("REMAINING WARRANTY  MONTHS:");
        output_panel.add(jLabel8);
        jLabel8.setBounds(60, 130, 270, 20);

        jLabel9.setBackground(new java.awt.Color(0, 0, 0));
        jLabel9.setFont(new java.awt.Font("Times New Roman", 3, 14)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(255, 255, 255));
        jLabel9.setText("CUSTOMER NAME:");
        output_panel.add(jLabel9);
        jLabel9.setBounds(60, 10, 210, 20);

        jLabel10.setBackground(new java.awt.Color(0, 0, 0));
        jLabel10.setFont(new java.awt.Font("Times New Roman", 3, 14)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(255, 255, 255));
        jLabel10.setText("PRODUCT NAME: ");
        output_panel.add(jLabel10);
        jLabel10.setBounds(60, 30, 210, 20);

        jLabel11.setBackground(new java.awt.Color(0, 0, 0));
        jLabel11.setFont(new java.awt.Font("Times New Roman", 3, 14)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(255, 255, 255));
        jLabel11.setText("SALE DATE:");
        output_panel.add(jLabel11);
        jLabel11.setBounds(60, 90, 220, 20);

        jLabel12.setBackground(new java.awt.Color(0, 0, 0));
        jLabel12.setFont(new java.awt.Font("Times New Roman", 3, 14)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(255, 255, 255));
        jLabel12.setText("WARRANTY END DATE: ");
        output_panel.add(jLabel12);
        jLabel12.setBounds(60, 110, 230, 20);

        jLabel19.setBackground(new java.awt.Color(0, 0, 0));
        jLabel19.setFont(new java.awt.Font("Times New Roman", 3, 14)); // NOI18N
        jLabel19.setForeground(new java.awt.Color(255, 255, 255));
        jLabel19.setText("ITEMS:");
        output_panel.add(jLabel19);
        jLabel19.setBounds(60, 50, 210, 20);

        jLabel20.setBackground(new java.awt.Color(0, 0, 0));
        jLabel20.setFont(new java.awt.Font("Times New Roman", 3, 14)); // NOI18N
        jLabel20.setForeground(new java.awt.Color(255, 255, 255));
        jLabel20.setText("PRICE:");
        output_panel.add(jLabel20);
        jLabel20.setBounds(60, 70, 220, 20);

        jPanel2.add(output_panel);
        output_panel.setBounds(160, 90, 590, 170);

        jLabel13.setBackground(new java.awt.Color(0, 0, 153));
        jLabel13.setFont(new java.awt.Font("Broadway", 3, 18)); // NOI18N
        jLabel13.setText("SEARCH ENGINE:");
        jPanel2.add(jLabel13);
        jLabel13.setBounds(330, 10, 210, 30);

        jLabel14.setBackground(new java.awt.Color(0, 0, 204));
        jLabel14.setFont(new java.awt.Font("Broadway", 3, 18)); // NOI18N
        jLabel14.setText("TABULAR FORM: ");
        jPanel2.add(jLabel14);
        jLabel14.setBounds(20, 260, 230, 30);

        jTabbedPane1.addTab("SEARCH / SHOW", jPanel2);

        getContentPane().add(jTabbedPane1);
        jTabbedPane1.setBounds(0, 0, 950, 590);

        setSize(new java.awt.Dimension(956, 627));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void saveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_saveActionPerformed
        // TODO add your handling code here:
       addData();
      tableData();
      customer_name.setText("");
      product_name.setText("");
      items.setSelectedIndex(0);
      price.setText("");
      imei_no.setText("");
      serial_no.setText("");
      sale_date.setText("");
      end_date.setText("");
    }//GEN-LAST:event_saveActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
     search_details  = search.getText().toString();
     System.out.println(search_details);
      
     
      if(search_details.matches("[1-9]*") ){
          try{
          System.out.println("Search by imei");
          rs = st.executeQuery("select customer_name, product_name, items, price, sale_date, warranty_end_date, MONTHS_BETWEEN(warranty_end_date,SYSDATE) from warranty_tracking where imei_no='"+search_details +"'"); 
          warranty_table.setModel(DbUtils.resultSetToTableModel(rs));
    }catch(Exception e){
     System.out.println(e.getMessage());
    }
  showImei(search_details);
   } else{
           System.out.println("Search by serial_no");
          try{
          rs = st.executeQuery("select customer_name, product_name, items, price, sale_date, warranty_end_date, MONTHS_BETWEEN(warranty_end_date,SYSDATE) from warranty_tracking where serial_no=UPPER('"+search_details+"') OR serial_no =LOWER('"+search_details+"')"); 
          warranty_table.setModel(DbUtils.resultSetToTableModel(rs));
    }catch(Exception e){
     System.out.println(e.getMessage());
    }
    showSerial(search_details);
    }
      search.setText("");

    }//GEN-LAST:event_jButton1ActionPerformed

    private void searchFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_searchFocusGained
    this.output_panel.setVisible(false);
    }//GEN-LAST:event_searchFocusGained

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Main_Frame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Main_Frame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Main_Frame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Main_Frame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Main_Frame().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel cost;
    private javax.swing.JLabel customer;
    private javax.swing.JTextField customer_name;
    private javax.swing.JTextField end_date;
    private javax.swing.JTextField imei_no;
    private javax.swing.JLabel item;
    private javax.swing.JComboBox items;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JPanel output_panel;
    private javax.swing.JTextField price;
    private javax.swing.JLabel product;
    private javax.swing.JTextField product_name;
    private javax.swing.JLabel rem_dat;
    private javax.swing.JLabel sal_dat;
    private javax.swing.JTextField sale_date;
    private javax.swing.JButton save;
    private javax.swing.JTextField search;
    private javax.swing.JTextField serial_no;
    private javax.swing.JLabel warr_dat;
    private javax.swing.JTable warranty_table;
    // End of variables declaration//GEN-END:variables
}
