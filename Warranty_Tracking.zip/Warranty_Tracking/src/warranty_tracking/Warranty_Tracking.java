package warranty_tracking;
public class Warranty_Tracking {
public static void main(String[] args) {
new background_frame().show();
    }
    
}
