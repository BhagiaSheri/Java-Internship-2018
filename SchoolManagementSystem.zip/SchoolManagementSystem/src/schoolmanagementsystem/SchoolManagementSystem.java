package schoolmanagementsystem;
public class SchoolManagementSystem {
public static void main(String[] args) {
  School_SplashFrame sf=  new School_SplashFrame();
 sf.setVisible(true);
 try{
 for(int loading =0;loading<=100; loading++){
  Thread.sleep(50);
  sf.jProgressBar1.setValue(loading);
  if(loading==100){
  sf.setVisible(false);
  new FrontFrame().show();
  }
  }
  }catch(Exception ex){
System.out.println(ex.getMessage());
 }  
    }
    
}
