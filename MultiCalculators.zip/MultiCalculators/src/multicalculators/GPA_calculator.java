/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package multicalculators;

import java.util.ArrayList;
import javax.swing.*;

/**
 *
 * @author Hp
 */
public class GPA_calculator extends javax.swing.JInternalFrame {
//    ArrayList<JTextField> txt;
//    ArrayList<JComboBox> cb;
    static int btn_id=1;
    int creditSum;
    double quality_points, qp1, qp2, qp3, qp4, qp5, qp6, qp7, qp8, qp9;
    String g1, g2, g3, g4, g5, g6, g7, g8, g9;
    double gpa;
    /**
     * Creates new form GPA_calculator
     */
    public GPA_calculator() {
        initComponents();
        setSize(720,510);
        
        jLabel1.setVisible(false);
        resultlabel.setVisible(false);
        
        coursetxt5.setVisible(false);
        coursetxt6.setVisible(false);
        coursetxt7.setVisible(false);
        coursetxt8.setVisible(false);
        coursetxt9.setVisible(false);
        gradecombobox5.setVisible(false);
        gradecombobox6.setVisible(false);
        gradecombobox7.setVisible(false);
        gradecombobox8.setVisible(false);
        gradecombobox9.setVisible(false);
        crdtxt5.setVisible(false);
        crdtxt6.setVisible(false);
        crdtxt7.setVisible(false);
        crdtxt8.setVisible(false);
        crdtxt9.setVisible(false);
        
       // anc_btn.setBounds(90, 40, 180, 30);
//      txt = new ArrayList<JTextField>();
//      txt.add(crdtxt);
//      txt.add(crdtxt1);
//      txt.add(crdtxt3);
//      txt.add(crdtxt4);
//      cb = new ArrayList<JComboBox>();
//      cb.add(gradecombobox);
//      cb.add(gradecombobox1);
//      cb.add(gradecombobox3);
//      cb.add(gradecombobox4);
      }
    
    public void gpaCalculator(){
    
   creditSum =Integer.parseInt(crdtxt.getText())+Integer.parseInt(crdtxt1.getText())+Integer.parseInt(crdtxt3.getText())
                        +Integer.parseInt(crdtxt4.getText())+Integer.parseInt(crdtxt5.getText())+Integer.parseInt(crdtxt6.getText())
                        +Integer.parseInt(crdtxt7.getText())+Integer.parseInt(crdtxt8.getText())+Integer.parseInt(crdtxt9.getText()); 
        
  g1 = gradecombobox.getSelectedItem().toString();
  g2 = gradecombobox1.getSelectedItem().toString();
  g3 = gradecombobox3.getSelectedItem().toString();
  g4 = gradecombobox4.getSelectedItem().toString();
  g5 = gradecombobox5.getSelectedItem().toString();
  g6 = gradecombobox6.getSelectedItem().toString();
  g7 = gradecombobox7.getSelectedItem().toString();
  g8 = gradecombobox8.getSelectedItem().toString();
  g9 = gradecombobox9.getSelectedItem().toString(); 
  
  if(g1.equals("A+") ){
  qp1 = Integer.parseInt(crdtxt.getText())*4.0;
  }
  else if(g1.equals("A") ){
  qp1 = Integer.parseInt(crdtxt.getText())*3.7;
  }
  else if(g1.equals("B+") ){
  qp1 = Integer.parseInt(crdtxt.getText())*3.0;
  }
  else if(g1.equals("B") ){
  qp1 = Integer.parseInt(crdtxt.getText())*2.7;
  }
  else if(g1.equals("C+") ){
  qp1 = Integer.parseInt(crdtxt.getText())*2.0;
  }
  else if(g1.equals("C") ){
  qp1 = Integer.parseInt(crdtxt.getText())*1.7;
  }
  else if(g1.equals("D+") ){
  qp1 = Integer.parseInt(crdtxt.getText())*1.0;
  }
  else if(g1.equals("D") ){
  qp1 = Integer.parseInt(crdtxt.getText())*0.7;
  }
  else if(g1.equals("F") ){
  qp1 = Integer.parseInt(crdtxt.getText())*0.0;
  }
  else{
  qp1 =0;
  }
  
    if(g2.equals("A+") ){
  qp2 = Integer.parseInt(crdtxt1.getText())*4.0;
  }
  else if(g2.equals("A") ){
  qp2 = Integer.parseInt(crdtxt1.getText())*3.7;
  }
  else if(g2.equals("B+") ){
  qp2 = Integer.parseInt(crdtxt1.getText())*3.0;
  }
  else if(g2.equals("B") ){
  qp2 = Integer.parseInt(crdtxt1.getText())*2.7;
  }
  else if(g2.equals("C+") ){
  qp2 = Integer.parseInt(crdtxt1.getText())*2.0;
  }
  else if(g2.equals("C") ){
  qp2 = Integer.parseInt(crdtxt1.getText())*1.7;
  }
  else if(g2.equals("D+") ){
  qp2 = Integer.parseInt(crdtxt1.getText())*1.0;
  }
  else if(g2.equals("D") ){
  qp2 = Integer.parseInt(crdtxt1.getText())*0.7;
  }
  else if(g2.equals("F") ){
  qp2 = Integer.parseInt(crdtxt1.getText())*0.0;
  }
  else{
  qp2 =0;
  }
    
    if(g3.equals("A+") ){
  qp3 = Integer.parseInt(crdtxt3.getText())*4.0;
  }
  else if(g3.equals("A") ){
  qp3 = Integer.parseInt(crdtxt3.getText())*3.7;
  }
  else if(g3.equals("B+") ){
  qp3 = Integer.parseInt(crdtxt3.getText())*3.0;
  }
  else if(g3.equals("B") ){
  qp3 = Integer.parseInt(crdtxt3.getText())*2.7;
  }
  else if(g3.equals("C+") ){
  qp3 = Integer.parseInt(crdtxt3.getText())*2.0;
  }
  else if(g3.equals("C") ){
  qp3 = Integer.parseInt(crdtxt3.getText())*1.7;
  }
  else if(g3.equals("D+") ){
  qp3 = Integer.parseInt(crdtxt3.getText())*1.0;
  }
  else if(g3.equals("D") ){
  qp3 = Integer.parseInt(crdtxt3.getText())*0.7;
  }
  else if(g3.equals("F") ){
  qp3 = Integer.parseInt(crdtxt3.getText())*0.0;
  }
  else{
  qp3 =0;
  }
   
       if(g4.equals("A+") ){
  qp4 = Integer.parseInt(crdtxt4.getText())*4.0;
  }
  else if(g4.equals("A") ){
  qp4 = Integer.parseInt(crdtxt4.getText())*3.7;
  }
  else if(g4.equals("B+") ){
  qp4 = Integer.parseInt(crdtxt4.getText())*3.0;
  }
  else if(g4.equals("B") ){
  qp4 = Integer.parseInt(crdtxt4.getText())*2.7;
  }
  else if(g4.equals("C+") ){
  qp4 = Integer.parseInt(crdtxt4.getText())*2.0;
  }
  else if(g4.equals("C") ){
  qp4 = Integer.parseInt(crdtxt4.getText())*1.7;
  }
  else if(g4.equals("D+") ){
  qp4 = Integer.parseInt(crdtxt4.getText())*1.0;
  }
  else if(g5.equals("D") ){
  qp4 = Integer.parseInt(crdtxt4.getText())*0.7;
  }
  else if(g4.equals("F") ){
  qp4 = Integer.parseInt(crdtxt4.getText())*0.0;
  }
  else{
  qp4 =0;
  }
       if(g5.equals("A+") ){
  qp5 = Integer.parseInt(crdtxt5.getText())*4.0;
  }
  else if(g5.equals("A") ){
  qp5 = Integer.parseInt(crdtxt5.getText())*3.7;
  }
  else if(g5.equals("B+") ){
  qp5 = Integer.parseInt(crdtxt5.getText())*3.0;
  }
  else if(g5.equals("B") ){
  qp5 = Integer.parseInt(crdtxt5.getText())*2.7;
  }
  else if(g5.equals("C+") ){
  qp5 = Integer.parseInt(crdtxt5.getText())*2.0;
  }
  else if(g5.equals("C") ){
  qp5 = Integer.parseInt(crdtxt5.getText())*1.7;
  }
  else if(g5.equals("D+") ){
  qp5 = Integer.parseInt(crdtxt5.getText())*1.0;
  }
  else if(g5.equals("D") ){
  qp5 = Integer.parseInt(crdtxt5.getText())*0.7;
  }
  else if(g5.equals("F") ){
  qp5 = Integer.parseInt(crdtxt5.getText())*0.0;
  }
  else{
  qp5 =0;
  }
   
         if(g6.equals("A+") ){
  qp6 = Integer.parseInt(crdtxt6.getText())*4.0;
  }
  else if(g6.equals("A") ){
  qp6 = Integer.parseInt(crdtxt6.getText())*3.7;
  }
  else if(g6.equals("B+") ){
  qp6 = Integer.parseInt(crdtxt6.getText())*3.0;
  }
  else if(g6.equals("B") ){
  qp6 = Integer.parseInt(crdtxt6.getText())*2.7;
  }
  else if(g6.equals("C+") ){
  qp6 = Integer.parseInt(crdtxt6.getText())*2.0;
  }
  else if(g6.equals("C") ){
  qp6 = Integer.parseInt(crdtxt6.getText())*1.7;
  }
  else if(g6.equals("D+") ){
  qp6 = Integer.parseInt(crdtxt6.getText())*1.0;
  }
  else if(g6.equals("D") ){
  qp6 = Integer.parseInt(crdtxt6.getText())*0.7;
  }
  else if(g6.equals("F") ){
  qp6 = Integer.parseInt(crdtxt6.getText())*0.0;
  }
  else{
  qp6 =0;
  }
         
         if(g7.equals("A+") ){
  qp7 = Integer.parseInt(crdtxt7.getText())*4.0;
  }
  else if(g7.equals("A") ){
  qp7 = Integer.parseInt(crdtxt7.getText())*3.7;
  }
  else if(g7.equals("B+") ){
  qp7 = Integer.parseInt(crdtxt7.getText())*3.0;
  }
  else if(g7.equals("B") ){
  qp7 = Integer.parseInt(crdtxt7.getText())*2.7;
  }
  else if(g7.equals("C+") ){
  qp7 = Integer.parseInt(crdtxt7.getText())*2.0;
  }
  else if(g7.equals("C") ){
  qp7 = Integer.parseInt(crdtxt7.getText())*1.7;
  }
  else if(g7.equals("D+") ){
  qp7 = Integer.parseInt(crdtxt7.getText())*1.0;
  }
  else if(g7.equals("D") ){
  qp7 = Integer.parseInt(crdtxt7.getText())*0.7;
  }
  else if(g7.equals("F") ){
  qp7 = Integer.parseInt(crdtxt7.getText())*0.0;
  }
  else{
  qp7 =0;
  }
       if(g8.equals("A+") ){
  qp8 = Integer.parseInt(crdtxt8.getText())*4.0;
  }
  else if(g8.equals("A") ){
  qp8 = Integer.parseInt(crdtxt8.getText())*3.7;
  }
  else if(g8.equals("B+") ){
  qp8 = Integer.parseInt(crdtxt8.getText())*3.0;
  }
  else if(g8.equals("B") ){
  qp8 = Integer.parseInt(crdtxt8.getText())*2.7;
  }
  else if(g8.equals("C+") ){
  qp8 = Integer.parseInt(crdtxt8.getText())*2.0;
  }
  else if(g8.equals("C") ){
  qp8 = Integer.parseInt(crdtxt8.getText())*1.7;
  }
  else if(g8.equals("D+") ){
  qp8 = Integer.parseInt(crdtxt8.getText())*1.0;
  }
  else if(g8.equals("D") ){
  qp8 = Integer.parseInt(crdtxt8.getText())*0.7;
  }
  else if(g8.equals("F") ){
 qp8 = Integer.parseInt(crdtxt8.getText())*0.0;
  }
  else{
  qp8 =0;
  }
   
         if(g9.equals("A+") ){
  qp9 = Integer.parseInt(crdtxt9.getText())*4.0;
  }
  else if(g9.equals("A") ){
  qp6 = Integer.parseInt(crdtxt9.getText())*3.7;
  }
  else if(g9.equals("B+") ){
  qp9 = Integer.parseInt(crdtxt9.getText())*3.0;
  }
  else if(g9.equals("B") ){
  qp9 = Integer.parseInt(crdtxt9.getText())*2.7;
  }
  else if(g9.equals("C+") ){
  qp9 = Integer.parseInt(crdtxt9.getText())*2.0;
  }
  else if(g9.equals("C") ){
  qp9 = Integer.parseInt(crdtxt9.getText())*1.7;
  }
  else if(g9.equals("D+") ){
  qp9 = Integer.parseInt(crdtxt9.getText())*1.0;
  }
  else if(g9.equals("D") ){
  qp9 = Integer.parseInt(crdtxt9.getText())*0.7;
  }
  else if(g9.equals("F") ){
  qp9 = Integer.parseInt(crdtxt9.getText())*0.0;
  }
  else{
  qp9 =0;
  }
         
 quality_points = qp1+qp2+qp3+qp4+qp5+qp6+qp7+qp8+qp9;
 gpa =quality_points/creditSum;
 if(Double.toString(gpa).length()==3){
 gpa_rlabel.setText(Double.toString(gpa).substring(0, 3)+"0 GPA");
 }
 else{
 gpa_rlabel.setText(Double.toString(gpa).substring(0, 4)+" GPA");
 }
 qp1=0; qp2=0;qp3=0;qp4=0;qp5=0;qp6=0;qp7=0;qp8=0;qp9=0; 
 quality_points =0;
  gpa=0;
    }
    

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        gpa_mainpanel = new javax.swing.JPanel();
        semesterPanel = new javax.swing.JPanel();
        gpalabel = new javax.swing.JLabel();
        courselabel = new javax.swing.JLabel();
        gradelabel = new javax.swing.JLabel();
        crdlabel = new javax.swing.JLabel();
        coursetxt = new javax.swing.JTextField();
        crdtxt = new javax.swing.JTextField();
        gradecombobox = new javax.swing.JComboBox();
        coursetxt1 = new javax.swing.JTextField();
        gradecombobox1 = new javax.swing.JComboBox();
        crdtxt1 = new javax.swing.JTextField();
        coursetxt3 = new javax.swing.JTextField();
        gradecombobox3 = new javax.swing.JComboBox();
        crdtxt3 = new javax.swing.JTextField();
        coursetxt4 = new javax.swing.JTextField();
        gradecombobox4 = new javax.swing.JComboBox();
        crdtxt4 = new javax.swing.JTextField();
        anc_btn = new javax.swing.JButton();
        gpa_rlabel = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        resultlabel = new javax.swing.JLabel();
        coursetxt5 = new javax.swing.JTextField();
        gradecombobox5 = new javax.swing.JComboBox();
        crdtxt5 = new javax.swing.JTextField();
        crdtxt6 = new javax.swing.JTextField();
        gradecombobox6 = new javax.swing.JComboBox();
        coursetxt6 = new javax.swing.JTextField();
        coursetxt7 = new javax.swing.JTextField();
        coursetxt8 = new javax.swing.JTextField();
        coursetxt9 = new javax.swing.JTextField();
        gradecombobox9 = new javax.swing.JComboBox();
        crdtxt9 = new javax.swing.JTextField();
        crdtxt8 = new javax.swing.JTextField();
        gradecombobox8 = new javax.swing.JComboBox();
        gradecombobox7 = new javax.swing.JComboBox();
        crdtxt7 = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();

        setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255), 3));
        setFrameIcon(null);
        getContentPane().setLayout(null);

        gpa_mainpanel.setBackground(new java.awt.Color(204, 255, 255));
        gpa_mainpanel.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255), 3));
        gpa_mainpanel.setLayout(null);

        semesterPanel.setBackground(new java.awt.Color(0, 51, 153));
        semesterPanel.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255), 3));
        semesterPanel.setForeground(new java.awt.Color(255, 255, 255));
        semesterPanel.setLayout(null);

        gpalabel.setFont(new java.awt.Font("Berlin Sans FB Demi", 3, 36)); // NOI18N
        gpalabel.setText("GPA CALCULATOR");
        semesterPanel.add(gpalabel);
        gpalabel.setBounds(210, 10, 350, 40);

        gpa_mainpanel.add(semesterPanel);
        semesterPanel.setBounds(0, 0, 720, 60);

        courselabel.setFont(new java.awt.Font("Berlin Sans FB Demi", 3, 18)); // NOI18N
        courselabel.setForeground(new java.awt.Color(0, 0, 153));
        courselabel.setText("COURSES:");
        gpa_mainpanel.add(courselabel);
        courselabel.setBounds(20, 60, 100, 30);

        gradelabel.setFont(new java.awt.Font("Berlin Sans FB Demi", 3, 18)); // NOI18N
        gradelabel.setForeground(new java.awt.Color(0, 0, 153));
        gradelabel.setText("GRADES:");
        gpa_mainpanel.add(gradelabel);
        gradelabel.setBounds(140, 60, 90, 30);

        crdlabel.setFont(new java.awt.Font("Berlin Sans FB Demi", 3, 18)); // NOI18N
        crdlabel.setForeground(new java.awt.Color(0, 0, 153));
        crdlabel.setText("CREDITS HOURS: ");
        gpa_mainpanel.add(crdlabel);
        crdlabel.setBounds(270, 60, 140, 30);

        coursetxt.setFont(new java.awt.Font("Berlin Sans FB Demi", 3, 14)); // NOI18N
        gpa_mainpanel.add(coursetxt);
        coursetxt.setBounds(20, 100, 80, 22);

        crdtxt.setFont(new java.awt.Font("Berlin Sans FB Demi", 3, 14)); // NOI18N
        crdtxt.setText("0");
        gpa_mainpanel.add(crdtxt);
        crdtxt.setBounds(270, 100, 120, 22);

        gradecombobox.setBackground(new java.awt.Color(204, 255, 255));
        gradecombobox.setFont(new java.awt.Font("Berlin Sans FB Demi", 3, 14)); // NOI18N
        gradecombobox.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "-", "A+", "A", "B+", "B", "C+", "C", "D+", "D", "F" }));
        gpa_mainpanel.add(gradecombobox);
        gradecombobox.setBounds(140, 100, 80, 22);

        coursetxt1.setFont(new java.awt.Font("Berlin Sans FB Demi", 3, 14)); // NOI18N
        gpa_mainpanel.add(coursetxt1);
        coursetxt1.setBounds(20, 130, 80, 22);

        gradecombobox1.setBackground(new java.awt.Color(204, 255, 255));
        gradecombobox1.setFont(new java.awt.Font("Berlin Sans FB Demi", 3, 14)); // NOI18N
        gradecombobox1.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "-", "A+", "A", "B+", "B", "C+", "C", "D+", "D", "F" }));
        gradecombobox1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                gradecombobox1ActionPerformed(evt);
            }
        });
        gpa_mainpanel.add(gradecombobox1);
        gradecombobox1.setBounds(140, 130, 80, 22);

        crdtxt1.setFont(new java.awt.Font("Berlin Sans FB Demi", 3, 14)); // NOI18N
        crdtxt1.setText("0");
        gpa_mainpanel.add(crdtxt1);
        crdtxt1.setBounds(270, 130, 120, 22);

        coursetxt3.setFont(new java.awt.Font("Berlin Sans FB Demi", 3, 14)); // NOI18N
        gpa_mainpanel.add(coursetxt3);
        coursetxt3.setBounds(20, 160, 80, 22);

        gradecombobox3.setBackground(new java.awt.Color(204, 255, 255));
        gradecombobox3.setFont(new java.awt.Font("Berlin Sans FB Demi", 3, 14)); // NOI18N
        gradecombobox3.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "-", "A+", "A", "B+", "B", "C+", "C", "D+", "D", "F" }));
        gpa_mainpanel.add(gradecombobox3);
        gradecombobox3.setBounds(140, 160, 80, 22);

        crdtxt3.setFont(new java.awt.Font("Berlin Sans FB Demi", 3, 14)); // NOI18N
        crdtxt3.setText("0");
        gpa_mainpanel.add(crdtxt3);
        crdtxt3.setBounds(270, 160, 120, 22);

        coursetxt4.setFont(new java.awt.Font("Berlin Sans FB Demi", 3, 14)); // NOI18N
        gpa_mainpanel.add(coursetxt4);
        coursetxt4.setBounds(20, 190, 80, 22);

        gradecombobox4.setBackground(new java.awt.Color(204, 255, 255));
        gradecombobox4.setFont(new java.awt.Font("Berlin Sans FB Demi", 3, 14)); // NOI18N
        gradecombobox4.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "-", "A+", "A", "B+", "B", "C+", "C", "D+", "D", "F" }));
        gpa_mainpanel.add(gradecombobox4);
        gradecombobox4.setBounds(140, 190, 80, 22);

        crdtxt4.setFont(new java.awt.Font("Berlin Sans FB Demi", 3, 14)); // NOI18N
        crdtxt4.setText("0");
        gpa_mainpanel.add(crdtxt4);
        crdtxt4.setBounds(270, 190, 120, 22);

        anc_btn.setBackground(new java.awt.Color(0, 0, 0));
        anc_btn.setFont(new java.awt.Font("Berlin Sans FB Demi", 3, 18)); // NOI18N
        anc_btn.setForeground(new java.awt.Color(204, 255, 255));
        anc_btn.setText("ADD ANOTHER COURSE");
        anc_btn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                anc_btnActionPerformed(evt);
            }
        });
        gpa_mainpanel.add(anc_btn);
        anc_btn.setBounds(90, 370, 230, 30);

        gpa_rlabel.setFont(new java.awt.Font("Berlin Sans FB Demi", 3, 24)); // NOI18N
        gpa_rlabel.setForeground(new java.awt.Color(0, 0, 102));
        gpa_mainpanel.add(gpa_rlabel);
        gpa_rlabel.setBounds(480, 190, 150, 90);

        jButton1.setBackground(new java.awt.Color(0, 0, 0));
        jButton1.setFont(new java.awt.Font("Berlin Sans FB Demi", 3, 18)); // NOI18N
        jButton1.setForeground(new java.awt.Color(204, 255, 255));
        jButton1.setText("CALCULATE");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        gpa_mainpanel.add(jButton1);
        jButton1.setBounds(480, 370, 150, 40);

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/multicalculators/ci.png"))); // NOI18N
        gpa_mainpanel.add(jLabel1);
        jLabel1.setBounds(430, 110, 260, 260);

        resultlabel.setFont(new java.awt.Font("Berlin Sans FB Demi", 3, 28)); // NOI18N
        resultlabel.setText("RESULT");
        gpa_mainpanel.add(resultlabel);
        resultlabel.setBounds(500, 70, 120, 50);

        coursetxt5.setFont(new java.awt.Font("Berlin Sans FB Demi", 3, 14)); // NOI18N
        gpa_mainpanel.add(coursetxt5);
        coursetxt5.setBounds(20, 220, 80, 22);

        gradecombobox5.setBackground(new java.awt.Color(204, 255, 255));
        gradecombobox5.setFont(new java.awt.Font("Berlin Sans FB Demi", 3, 14)); // NOI18N
        gradecombobox5.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "-", "A+", "A", "B+", "B", "C+", "C", "D+", "D", "F" }));
        gpa_mainpanel.add(gradecombobox5);
        gradecombobox5.setBounds(140, 220, 80, 22);

        crdtxt5.setFont(new java.awt.Font("Berlin Sans FB Demi", 3, 14)); // NOI18N
        crdtxt5.setText("0");
        gpa_mainpanel.add(crdtxt5);
        crdtxt5.setBounds(270, 220, 120, 22);

        crdtxt6.setFont(new java.awt.Font("Berlin Sans FB Demi", 3, 14)); // NOI18N
        crdtxt6.setText("0");
        gpa_mainpanel.add(crdtxt6);
        crdtxt6.setBounds(270, 250, 120, 22);

        gradecombobox6.setBackground(new java.awt.Color(204, 255, 255));
        gradecombobox6.setFont(new java.awt.Font("Berlin Sans FB Demi", 3, 14)); // NOI18N
        gradecombobox6.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "-", "A+", "A", "B+", "B", "C+", "C", "D+", "D", "F" }));
        gpa_mainpanel.add(gradecombobox6);
        gradecombobox6.setBounds(140, 250, 80, 22);

        coursetxt6.setFont(new java.awt.Font("Berlin Sans FB Demi", 3, 14)); // NOI18N
        gpa_mainpanel.add(coursetxt6);
        coursetxt6.setBounds(20, 250, 80, 22);

        coursetxt7.setFont(new java.awt.Font("Berlin Sans FB Demi", 3, 14)); // NOI18N
        gpa_mainpanel.add(coursetxt7);
        coursetxt7.setBounds(20, 280, 80, 22);

        coursetxt8.setFont(new java.awt.Font("Berlin Sans FB Demi", 3, 14)); // NOI18N
        gpa_mainpanel.add(coursetxt8);
        coursetxt8.setBounds(20, 310, 80, 22);

        coursetxt9.setFont(new java.awt.Font("Berlin Sans FB Demi", 3, 14)); // NOI18N
        gpa_mainpanel.add(coursetxt9);
        coursetxt9.setBounds(20, 340, 80, 22);

        gradecombobox9.setBackground(new java.awt.Color(204, 255, 255));
        gradecombobox9.setFont(new java.awt.Font("Berlin Sans FB Demi", 3, 14)); // NOI18N
        gradecombobox9.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "-", "A+", "A", "B+", "B", "C+", "C", "D+", "D", "F" }));
        gpa_mainpanel.add(gradecombobox9);
        gradecombobox9.setBounds(140, 340, 80, 22);

        crdtxt9.setFont(new java.awt.Font("Berlin Sans FB Demi", 3, 14)); // NOI18N
        crdtxt9.setText("0");
        gpa_mainpanel.add(crdtxt9);
        crdtxt9.setBounds(270, 340, 120, 22);

        crdtxt8.setFont(new java.awt.Font("Berlin Sans FB Demi", 3, 14)); // NOI18N
        crdtxt8.setText("0");
        gpa_mainpanel.add(crdtxt8);
        crdtxt8.setBounds(270, 310, 120, 22);

        gradecombobox8.setBackground(new java.awt.Color(204, 255, 255));
        gradecombobox8.setFont(new java.awt.Font("Berlin Sans FB Demi", 3, 14)); // NOI18N
        gradecombobox8.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "-", "A+", "A", "B+", "B", "C+", "C", "D+", "D", "F" }));
        gpa_mainpanel.add(gradecombobox8);
        gradecombobox8.setBounds(140, 310, 80, 22);

        gradecombobox7.setBackground(new java.awt.Color(204, 255, 255));
        gradecombobox7.setFont(new java.awt.Font("Berlin Sans FB Demi", 3, 14)); // NOI18N
        gradecombobox7.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "-", "A+", "A", "B+", "B", "C+", "C", "D+", "D", "F" }));
        gpa_mainpanel.add(gradecombobox7);
        gradecombobox7.setBounds(140, 280, 80, 22);

        crdtxt7.setFont(new java.awt.Font("Berlin Sans FB Demi", 3, 14)); // NOI18N
        crdtxt7.setText("0");
        gpa_mainpanel.add(crdtxt7);
        crdtxt7.setBounds(270, 280, 120, 22);

        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/multicalculators/happy.gif"))); // NOI18N
        gpa_mainpanel.add(jLabel3);
        jLabel3.setBounds(250, 60, 470, 390);

        getContentPane().add(gpa_mainpanel);
        gpa_mainpanel.setBounds(0, 0, 720, 450);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void anc_btnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_anc_btnActionPerformed
         btn_id++;
        if(btn_id==2){
        coursetxt5.setVisible(true);
         gradecombobox5.setVisible(true);
          crdtxt5.setVisible(true);
          btn_id++;
        }
        if(btn_id==4){
         coursetxt6.setVisible(true);
         gradecombobox6.setVisible(true);
          crdtxt6.setVisible(true);
          btn_id++;
        }
       if(btn_id==6){
        coursetxt7.setVisible(true);
         gradecombobox7.setVisible(true);
          crdtxt7.setVisible(true);
          btn_id++;
        }
       if(btn_id==8){
        coursetxt8.setVisible(true);
         gradecombobox8.setVisible(true);
          crdtxt8.setVisible(true);
          btn_id++;
        }
        if(btn_id==10){
        coursetxt9.setVisible(true);
         gradecombobox9.setVisible(true);
          crdtxt9.setVisible(true);
          btn_id++;
        }



//    generateTxtfields gt = new  generateTxtfields();
//    adder.add(gt);
//    gt.show();
//    adder.validate();
//    txt.add(new JTextField());
//    cb.add(new JComboBox());
//    gpa_mainpanel.validate();
      
       
    }//GEN-LAST:event_anc_btnActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        jLabel3.setVisible(false);
        jLabel1.setVisible(true);
        resultlabel.setVisible(true);
        gpaCalculator();
    }//GEN-LAST:event_jButton1ActionPerformed

    private void gradecombobox1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_gradecombobox1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_gradecombobox1ActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton anc_btn;
    private javax.swing.JLabel courselabel;
    private javax.swing.JTextField coursetxt;
    private javax.swing.JTextField coursetxt1;
    private javax.swing.JTextField coursetxt3;
    private javax.swing.JTextField coursetxt4;
    private javax.swing.JTextField coursetxt5;
    private javax.swing.JTextField coursetxt6;
    private javax.swing.JTextField coursetxt7;
    private javax.swing.JTextField coursetxt8;
    private javax.swing.JTextField coursetxt9;
    private javax.swing.JLabel crdlabel;
    private javax.swing.JTextField crdtxt;
    private javax.swing.JTextField crdtxt1;
    private javax.swing.JTextField crdtxt3;
    private javax.swing.JTextField crdtxt4;
    private javax.swing.JTextField crdtxt5;
    private javax.swing.JTextField crdtxt6;
    private javax.swing.JTextField crdtxt7;
    private javax.swing.JTextField crdtxt8;
    private javax.swing.JTextField crdtxt9;
    private javax.swing.JPanel gpa_mainpanel;
    private javax.swing.JLabel gpa_rlabel;
    private javax.swing.JLabel gpalabel;
    private javax.swing.JComboBox gradecombobox;
    private javax.swing.JComboBox gradecombobox1;
    private javax.swing.JComboBox gradecombobox3;
    private javax.swing.JComboBox gradecombobox4;
    private javax.swing.JComboBox gradecombobox5;
    private javax.swing.JComboBox gradecombobox6;
    private javax.swing.JComboBox gradecombobox7;
    private javax.swing.JComboBox gradecombobox8;
    private javax.swing.JComboBox gradecombobox9;
    private javax.swing.JLabel gradelabel;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel3;
    public javax.swing.JLabel resultlabel;
    private javax.swing.JPanel semesterPanel;
    // End of variables declaration//GEN-END:variables
}
