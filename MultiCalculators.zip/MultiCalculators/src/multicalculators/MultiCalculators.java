package multicalculators;
public class MultiCalculators {
public static void main(String[] args) {
  CalculatorSplashScreen gs=  new CalculatorSplashScreen();
 gs.setVisible(true);
 try{
 for(int loading =0;loading<=100; loading++){
  Thread.sleep(50);
  gs.load1.setText(Integer.toString(loading)+"%");
  gs.jProgressBar1.setValue(loading);
  if(loading==100){
  gs.setVisible(false);
  new MainFrame().show();
  }
  }
  }catch(Exception ex){
System.out.println(ex.getMessage());
 }
    }
    }
