package multicalculators;
public class CalculatorSplashScreen extends javax.swing.JFrame {
    public CalculatorSplashScreen() {
        initComponents();
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jTextField1 = new javax.swing.JTextField();
        load1 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        background_gif = new javax.swing.JLabel();
        loading = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jProgressBar1 = new javax.swing.JProgressBar();

        jTextField1.setText("jTextField1");

        load1.setBackground(new java.awt.Color(0, 0, 0));
        load1.setFont(new java.awt.Font("Times New Roman", 3, 18)); // NOI18N
        load1.setForeground(new java.awt.Color(255, 51, 153));

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        getContentPane().setLayout(null);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 51, 153), 5));
        jPanel1.setLayout(null);

        background_gif.setIcon(new javax.swing.ImageIcon(getClass().getResource("/multicalculators/age.gif"))); // NOI18N
        jPanel1.add(background_gif);
        background_gif.setBounds(0, 40, 300, 630);

        loading.setBackground(new java.awt.Color(255, 255, 255));
        loading.setIcon(new javax.swing.ImageIcon(getClass().getResource("/multicalculators/timegif.gif"))); // NOI18N
        jPanel1.add(loading);
        loading.setBounds(300, 40, 230, 320);

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/multicalculators/gpaimg.gif"))); // NOI18N
        jPanel1.add(jLabel1);
        jLabel1.setBounds(640, 230, 280, 430);

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/multicalculators/allgif.gif"))); // NOI18N
        jLabel2.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 153, 153), 2, true));
        jPanel1.add(jLabel2);
        jLabel2.setBounds(370, 380, 260, 250);

        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/multicalculators/calculator.jpg"))); // NOI18N
        jPanel1.add(jLabel3);
        jLabel3.setBounds(770, 40, 160, 150);

        getContentPane().add(jPanel1);
        jPanel1.setBounds(0, 40, 990, 670);

        jProgressBar1.setForeground(new java.awt.Color(153, 153, 255));
        getContentPane().add(jProgressBar1);
        jProgressBar1.setBounds(0, 0, 990, 40);

        setSize(new java.awt.Dimension(990, 710));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(CalculatorSplashScreen.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(CalculatorSplashScreen.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(CalculatorSplashScreen.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(CalculatorSplashScreen.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new CalculatorSplashScreen().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel background_gif;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPanel jPanel1;
    public javax.swing.JProgressBar jProgressBar1;
    private javax.swing.JTextField jTextField1;
    public javax.swing.JLabel load1;
    private javax.swing.JLabel loading;
    // End of variables declaration//GEN-END:variables
}
