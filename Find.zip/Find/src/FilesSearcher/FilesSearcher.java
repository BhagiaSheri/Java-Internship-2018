package FilesSearcher;

import java.awt.Color;
import javax.swing.border.Border;

public class FilesSearcher{
    
public static void main(String[] args){

Searcher_Splash_Screen s=  new Searcher_Splash_Screen();
 s.setVisible(true);
 s.searchLabel.setVisible(false);
 try{
 for(int loading =0;loading<=100; loading++){
 s.jProgressBar1.setValue(loading);
  Thread.sleep(60);
  if(loading>=70){
s.backImgLabel.setVisible(false);
s.searchLabel.setVisible(true);
s.SplashScreenPanel.setBackground(Color.WHITE);
}
  if(loading==100){
  s.setVisible(false);
 new Search_Frame().show();
  }
  }
  }catch(Exception ex){
System.out.println(ex.getMessage());
 }
}
}
    
