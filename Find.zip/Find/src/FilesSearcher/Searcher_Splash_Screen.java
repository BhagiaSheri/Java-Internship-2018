package FilesSearcher;
public class Searcher_Splash_Screen extends javax.swing.JFrame {
    public Searcher_Splash_Screen() {
        initComponents();
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        SplashScreenPanel = new javax.swing.JPanel();
        searchLabel = new javax.swing.JLabel();
        jProgressBar1 = new javax.swing.JProgressBar();
        backImgLabel = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        setUndecorated(true);
        getContentPane().setLayout(null);

        SplashScreenPanel.setBackground(new java.awt.Color(153, 153, 153));
        SplashScreenPanel.setBorder(javax.swing.BorderFactory.createEtchedBorder(new java.awt.Color(102, 102, 102), new java.awt.Color(102, 102, 102)));
        SplashScreenPanel.setForeground(new java.awt.Color(255, 255, 255));
        SplashScreenPanel.setLayout(null);

        searchLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/FilesSearcher/searchimg.gif"))); // NOI18N
        SplashScreenPanel.add(searchLabel);
        searchLabel.setBounds(230, 180, 290, 300);

        jProgressBar1.setForeground(new java.awt.Color(0, 153, 0));
        SplashScreenPanel.add(jProgressBar1);
        jProgressBar1.setBounds(0, 0, 800, 40);

        backImgLabel.setBackground(new java.awt.Color(153, 153, 153));
        backImgLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/FilesSearcher/backSearch.gif"))); // NOI18N
        SplashScreenPanel.add(backImgLabel);
        backImgLabel.setBounds(10, 40, 790, 530);

        getContentPane().add(SplashScreenPanel);
        SplashScreenPanel.setBounds(0, 0, 800, 630);

        setSize(new java.awt.Dimension(801, 633));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Searcher_Splash_Screen.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Searcher_Splash_Screen.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Searcher_Splash_Screen.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Searcher_Splash_Screen.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Searcher_Splash_Screen().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    public javax.swing.JPanel SplashScreenPanel;
    public javax.swing.JLabel backImgLabel;
    public javax.swing.JProgressBar jProgressBar1;
    public javax.swing.JLabel searchLabel;
    // End of variables declaration//GEN-END:variables
}
